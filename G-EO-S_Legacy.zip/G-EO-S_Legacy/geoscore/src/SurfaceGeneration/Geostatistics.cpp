/*
 * Geostatistics.cpp
 *
 *  Created on: Jun 7, 2012
 *      Author: johnson346
 */

#include "Geostatistics.h"

Geostatistics::Geostatistics()
{
  // TODO Auto-generated constructor stub

}

Geostatistics::~Geostatistics()
{
  // TODO Auto-generated destructor stub
}

