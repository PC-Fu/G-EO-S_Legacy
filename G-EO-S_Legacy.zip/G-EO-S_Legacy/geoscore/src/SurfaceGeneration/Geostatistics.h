/*
 * Geostatistics.h
 *
 *  Created on: Jun 7, 2012
 *      Author: johnson346
 */

#ifndef GEOSTATISTICS_H_
#define GEOSTATISTICS_H_

class Geostatistics
{
public:
  Geostatistics();
  virtual ~Geostatistics();


};

#endif /* GEOSTATISTICS_H_ */
