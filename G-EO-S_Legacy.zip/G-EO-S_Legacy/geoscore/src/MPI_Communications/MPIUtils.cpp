/*
 * MPIUtils.cpp
 *
 *  Created on: Apr 20, 2014
 *      Author: rrsettgast
 */

#include "MPIUtils.h"

namespace MPIUtils
{

}
