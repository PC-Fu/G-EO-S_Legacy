/*
 * MPIUtils.h
 *
 *  Created on: Apr 20, 2014
 *      Author: rrsettgast
 */

#ifndef MPIUTILS_H_
#define MPIUTILS_H_

namespace MPIUtils
{
  SendRecieveBuffer( )
}

#endif /* MPIUTILS_H_ */
