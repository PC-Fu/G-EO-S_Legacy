/*
 * Communication.cpp
 *
 *  Created on: Aug 24, 2012
 *      Author: johnson346
 */

#include "Communication.h"

Communication::Communication()
{
  // TODO Auto-generated constructor stub

}

Communication::~Communication()
{
  // TODO Auto-generated destructor stub
}

