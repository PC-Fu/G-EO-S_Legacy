#!/usr/bin/perl
my $narg = $#ARGV + 1;

die "usage: $0 <Abaqus file> <absolute directory path of SILO files> <session file> <shear direction> <normal direction> <opt:scale>\n" if($narg != 5 && $narg != 6);

my $fname = shift;
my $dpath = shift;
#e.g., /Users/scottjohnson/Documents/workspace/gpac/test/full_tests/AdvectionSim
my $sname = shift;
my $shear_dir = shift;
my $normal_dir = shift;
my $scale = 1.0;
if($narg == 6)
{
    $scale = shift;
}
#die "$scale\n";

#get query region
my @x0 = (1e100,1e100,1e100);
my @x1 = (-1e100,-1e100,-1e100);
my $on = 0;
die "cannot open $fname\n" if(!open(IN,"<$fname"));
while(<IN>)
{
    if(/^\s*\*/)
    {
	if(/^\s*\*NODE/)
	{
	    $on = 1;
	}
	else
	{
	    $on = 0;
	}
    }
    elsif($on)
    {
	my @arr = &SplitMe($_);
	#die "$#arr $arr[0] $arr[1] $arr[2] $arr[3]\n";
	for(my $i = 1; $i < 4; $i++)
	{
	    if($arr[$i] < $x0[$i-1])
	    {
		$x0[$i-1] = $arr[$i];
	    }
	    if($arr[$i] > $x1[$i-1])
	    {
		$x1[$i-1] = $arr[$i];
	    }
	}
    }
}
close IN;

#die "$x0[0] $x0[1] $x0[2] $x1[0] $x1[1] $x1[2]\n";

my @dx = ($x1[0],$x1[1],$x1[2]);
my @xmean = ($x1[0],$x1[1],$x1[2]);
my @dirs = (0,0,0);
$dirs[$shear_dir] = 1;
$dirs[$normal_dir] = 2;
for(my $i = 0; $i < 3; $i++)
{
    $dx[$i] -= $x0[$i];
    $xmean[$i] += $x0[$i];
    $xmean[$i] *= 0.5;
    if($dirs[$i] == 1)
    {
	$x0[$i] += 0.99 * $dx[$i];
	$x1[$i] += $dx[$i];
    }
    else
    {
	$x0[$i] = $xmean[$i] - $dx[$i];
	$x1[$i] = $xmean[$i] + $dx[$i];
    }
    $x0[$i] *= $scale;
    $x1[$i] *= $scale;
}

&PrintSessionFile($sname,$dpath,\@x0,\@x1);
&CreatePythonScript ($sname,$dpath);

sub CreatePythonScript
{
    my $db = shift;
    my $dpath = shift;

    print "import sys
RestoreSession(\"$dpath/$db\",0)
nplots = TimeSliderGetNStates();
start=0
end = nplots
for i in range(start, end):
    SetTimeSliderState(i)
    Query(\"Variable Sum\")
    print \"\%g\" \% GetQueryOutputValue()
sys.exit(\"\")
";
}

sub SplitMe
{
    my $line = shift;
    chomp($line);
    $line =~s/^\s+//;
    my @arr = split(/\,\s*/,$line);
    return @arr;
}

sub PrintSessionFile
{
    my $fname = shift;
    my $dpath = shift;
    my $x0p = shift;
    my $x1p = shift;
    my @x0 = @$x0p;
    my @x1 = @$x1p;    

    die "cannot open $fname\n" if(!open(OUT,">$fname"));
print OUT q{<?xml version="1.0"?>
<Object name="VisIt">
    <Field name="Version" type="string">2.4.0</Field>
    <Object name="VIEWER">
        <Object name="DEFAULT_VALUES">
            <Object name="GlobalAttributes">
                <Field name="autoUpdateFlag" type="bool">false</Field>
                <Field name="replacePlots" type="bool">false</Field>
                <Field name="applyOperator" type="bool">true</Field>
                <Field name="windowLayout" type="int">1</Field>
                <Field name="makeDefaultConfirm" type="bool">true</Field>
                <Field name="cloneWindowOnFirstRef" type="bool">true</Field>
                <Field name="automaticallyAddOperator" type="bool">false</Field>
                <Field name="tryHarderCyclesTimes" type="bool">false</Field>
                <Field name="treatAllDBsAsTimeVarying" type="bool">false</Field>
                <Field name="createMeshQualityExpressions" type="bool">true</Field>
                <Field name="createTimeDerivativeExpressions" type="bool">true</Field>
                <Field name="createVectorMagnitudeExpressions" type="bool">true</Field>
                <Field name="newPlotsInheritSILRestriction" type="bool">true</Field>
                <Field name="userDirForSessionFiles" type="bool">false</Field>
                <Field name="saveCrashRecoveryFile" type="bool">true</Field>
                <Field name="applySelection" type="bool">true</Field>
            </Object>
            <Object name="SaveWindowAttributes">
                <Field name="outputToCurrentDirectory" type="bool">true</Field>
                <Field name="outputDirectory" type="string">.</Field>
                <Field name="fileName" type="string">visit</Field>
                <Field name="family" type="bool">true</Field>
                <Field name="format" type="string">PNG</Field>
                <Field name="width" type="int">1024</Field>
                <Field name="height" type="int">1024</Field>
                <Field name="screenCapture" type="bool">false</Field>
                <Field name="saveTiled" type="bool">false</Field>
                <Field name="quality" type="int">80</Field>
                <Field name="progressive" type="bool">false</Field>
                <Field name="binary" type="bool">false</Field>
                <Field name="lastRealFilename" type="string"></Field>
                <Field name="stereo" type="bool">false</Field>
                <Field name="compression" type="string">PackBits</Field>
                <Field name="forceMerge" type="bool">false</Field>
                <Field name="resConstraint" type="string">ScreenProportions</Field>
                <Field name="advancedMultiWindowSave" type="bool">false</Field>
                <Object name="subWindowAtts">
                    <Object name="SaveSubWindowsAttributes">
                        <Object name="win1">
                            <Object name="SaveSubWindowAttributes">
                                <Field name="position" type="intArray" length="2">0 0 </Field>
                                <Field name="size" type="intArray" length="2">128 128 </Field>
                                <Field name="layer" type="int">0</Field>
                                <Field name="transparency" type="double">0</Field>
                                <Field name="omitWindow" type="bool">false</Field>
                            </Object>
                        </Object>
                        <Object name="win2">
                            <Object name="SaveSubWindowAttributes">
                                <Field name="position" type="intArray" length="2">0 0 </Field>
                                <Field name="size" type="intArray" length="2">128 128 </Field>
                                <Field name="layer" type="int">0</Field>
                                <Field name="transparency" type="double">0</Field>
                                <Field name="omitWindow" type="bool">false</Field>
                            </Object>
                        </Object>
                        <Object name="win3">
                            <Object name="SaveSubWindowAttributes">
                                <Field name="position" type="intArray" length="2">0 0 </Field>
                                <Field name="size" type="intArray" length="2">128 128 </Field>
                                <Field name="layer" type="int">0</Field>
                                <Field name="transparency" type="double">0</Field>
                                <Field name="omitWindow" type="bool">false</Field>
                            </Object>
                        </Object>
                        <Object name="win4">
                            <Object name="SaveSubWindowAttributes">
                                <Field name="position" type="intArray" length="2">0 0 </Field>
                                <Field name="size" type="intArray" length="2">128 128 </Field>
                                <Field name="layer" type="int">0</Field>
                                <Field name="transparency" type="double">0</Field>
                                <Field name="omitWindow" type="bool">false</Field>
                            </Object>
                        </Object>
                        <Object name="win5">
                            <Object name="SaveSubWindowAttributes">
                                <Field name="position" type="intArray" length="2">0 0 </Field>
                                <Field name="size" type="intArray" length="2">128 128 </Field>
                                <Field name="layer" type="int">0</Field>
                                <Field name="transparency" type="double">0</Field>
                                <Field name="omitWindow" type="bool">false</Field>
                            </Object>
                        </Object>
                        <Object name="win6">
                            <Object name="SaveSubWindowAttributes">
                                <Field name="position" type="intArray" length="2">0 0 </Field>
                                <Field name="size" type="intArray" length="2">128 128 </Field>
                                <Field name="layer" type="int">0</Field>
                                <Field name="transparency" type="double">0</Field>
                                <Field name="omitWindow" type="bool">false</Field>
                            </Object>
                        </Object>
                        <Object name="win7">
                            <Object name="SaveSubWindowAttributes">
                                <Field name="position" type="intArray" length="2">0 0 </Field>
                                <Field name="size" type="intArray" length="2">128 128 </Field>
                                <Field name="layer" type="int">0</Field>
                                <Field name="transparency" type="double">0</Field>
                                <Field name="omitWindow" type="bool">false</Field>
                            </Object>
                        </Object>
                        <Object name="win8">
                            <Object name="SaveSubWindowAttributes">
                                <Field name="position" type="intArray" length="2">0 0 </Field>
                                <Field name="size" type="intArray" length="2">128 128 </Field>
                                <Field name="layer" type="int">0</Field>
                                <Field name="transparency" type="double">0</Field>
                                <Field name="omitWindow" type="bool">false</Field>
                            </Object>
                        </Object>
                        <Object name="win9">
                            <Object name="SaveSubWindowAttributes">
                                <Field name="position" type="intArray" length="2">0 0 </Field>
                                <Field name="size" type="intArray" length="2">128 128 </Field>
                                <Field name="layer" type="int">0</Field>
                                <Field name="transparency" type="double">0</Field>
                                <Field name="omitWindow" type="bool">false</Field>
                            </Object>
                        </Object>
                        <Object name="win10">
                            <Object name="SaveSubWindowAttributes">
                                <Field name="position" type="intArray" length="2">0 0 </Field>
                                <Field name="size" type="intArray" length="2">128 128 </Field>
                                <Field name="layer" type="int">0</Field>
                                <Field name="transparency" type="double">0</Field>
                                <Field name="omitWindow" type="bool">false</Field>
                            </Object>
                        </Object>
                        <Object name="win11">
                            <Object name="SaveSubWindowAttributes">
                                <Field name="position" type="intArray" length="2">0 0 </Field>
                                <Field name="size" type="intArray" length="2">128 128 </Field>
                                <Field name="layer" type="int">0</Field>
                                <Field name="transparency" type="double">0</Field>
                                <Field name="omitWindow" type="bool">false</Field>
                            </Object>
                        </Object>
                        <Object name="win12">
                            <Object name="SaveSubWindowAttributes">
                                <Field name="position" type="intArray" length="2">0 0 </Field>
                                <Field name="size" type="intArray" length="2">128 128 </Field>
                                <Field name="layer" type="int">0</Field>
                                <Field name="transparency" type="double">0</Field>
                                <Field name="omitWindow" type="bool">false</Field>
                            </Object>
                        </Object>
                        <Object name="win13">
                            <Object name="SaveSubWindowAttributes">
                                <Field name="position" type="intArray" length="2">0 0 </Field>
                                <Field name="size" type="intArray" length="2">128 128 </Field>
                                <Field name="layer" type="int">0</Field>
                                <Field name="transparency" type="double">0</Field>
                                <Field name="omitWindow" type="bool">false</Field>
                            </Object>
                        </Object>
                        <Object name="win14">
                            <Object name="SaveSubWindowAttributes">
                                <Field name="position" type="intArray" length="2">0 0 </Field>
                                <Field name="size" type="intArray" length="2">128 128 </Field>
                                <Field name="layer" type="int">0</Field>
                                <Field name="transparency" type="double">0</Field>
                                <Field name="omitWindow" type="bool">false</Field>
                            </Object>
                        </Object>
                        <Object name="win15">
                            <Object name="SaveSubWindowAttributes">
                                <Field name="position" type="intArray" length="2">0 0 </Field>
                                <Field name="size" type="intArray" length="2">128 128 </Field>
                                <Field name="layer" type="int">0</Field>
                                <Field name="transparency" type="double">0</Field>
                                <Field name="omitWindow" type="bool">false</Field>
                            </Object>
                        </Object>
                        <Object name="win16">
                            <Object name="SaveSubWindowAttributes">
                                <Field name="position" type="intArray" length="2">0 0 </Field>
                                <Field name="size" type="intArray" length="2">128 128 </Field>
                                <Field name="layer" type="int">0</Field>
                                <Field name="transparency" type="double">0</Field>
                                <Field name="omitWindow" type="bool">false</Field>
                            </Object>
                        </Object>
                    </Object>
                </Object>
            </Object>
            <Object name="ColorTableAttributes">
                <Field name="activeContinuous" type="string">hot</Field>
                <Field name="activeDiscrete" type="string">levels</Field>
                <Object name="table00">
                    <Field name="ctName" type="string">amino_rasmol</Field>
                    <Field name="equal" type="bool">true</Field>
                    <Field name="smooth" type="bool">false</Field>
                    <Field name="discrete" type="bool">true</Field>
                    <Field name="colorsHaveOpacity" type="bool">true</Field>
                    <Field name="controlPts" type="floatVector">0 189 159 109 255 0.009 199 199 199 255 0.019 255 105 180 255 0.028 230 230 0 255 0.037 230 9 9 255 0.046 230 9 9 255 0.056 49 49 170 255 0.065 235 235 235 255 0.074 130 130 210 255 0.083 15 130 15 255 0.093 19 90 255 255 0.102 15 130 15 255 0.111 230 230 0 255 0.12 0 220 220 255 0.13 220 149 130 255 0.139 0 220 220 255 0.148 19 90 255 255 0.157 249 149 0 255 0.167 249 149 0 255 0.176 15 130 15 255 0.185 180 90 180 255 0.194 49 49 170 255 0.204 255 105 180 255 </Field>
                </Object>
                <Object name="table01">
                    <Field name="ctName" type="string">amino_shapely</Field>
                    <Field name="equal" type="bool">true</Field>
                    <Field name="smooth" type="bool">false</Field>
                    <Field name="discrete" type="bool">true</Field>
                    <Field name="colorsHaveOpacity" type="bool">true</Field>
                    <Field name="controlPts" type="floatVector">0 255 0 255 255 0.009 139 255 139 255 0.019 255 0 255 255 0.028 255 255 111 255 0.037 159 0 66 255 0.046 102 0 0 255 0.056 82 75 82 255 0.065 255 255 255 255 0.074 111 111 255 255 0.083 0 75 0 255 0.093 70 70 184 255 0.102 69 94 69 255 0.111 184 159 66 255 0.12 255 123 111 255 0.13 82 82 82 255 0.139 255 75 75 255 0.148 0 0 123 255 0.157 255 111 66 255 0.167 184 75 0 255 0.176 255 139 255 255 0.185 79 70 0 255 0.194 139 111 75 255 0.204 255 0 255 255 </Field>
                </Object>
                <Object name="table02">
                    <Field name="ctName" type="string">bluehot</Field>
                    <Field name="colorsHaveOpacity" type="bool">true</Field>
                    <Field name="controlPts" type="floatVector">0 0 0 0 255 0.333 0 0 127 255 0.666 0 127 255 255 1 255 255 255 255 </Field>
                </Object>
                <Object name="table03">
                    <Field name="ctName" type="string">caleblack</Field>
                    <Field name="colorsHaveOpacity" type="bool">true</Field>
                    <Field name="controlPts" type="floatVector">0 0 0 0 255 0.17 0 0 255 255 0.34 0 255 255 255 0.5 0 255 0 255 0.67 255 255 0 255 0.84 255 0 0 255 1 255 0 255 255 </Field>
                </Object>
                <Object name="table04">
                    <Field name="ctName" type="string">calewhite</Field>
                    <Field name="colorsHaveOpacity" type="bool">true</Field>
                    <Field name="controlPts" type="floatVector">0 255 255 255 255 0.17 0 0 255 255 0.34 0 255 255 255 0.5 0 255 0 255 0.67 255 255 0 255 0.84 255 0 0 255 1 255 0 255 255 </Field>
                </Object>
                <Object name="table05">
                    <Field name="ctName" type="string">contoured</Field>
                    <Field name="equal" type="bool">true</Field>
                    <Field name="smooth" type="bool">false</Field>
                    <Field name="colorsHaveOpacity" type="bool">true</Field>
                    <Field name="controlPts" type="floatVector">0 0 0 255 255 0.333 0 255 0 255 0.666 255 255 0 255 1 255 0 0 255 </Field>
                </Object>
                <Object name="table06">
                    <Field name="ctName" type="string">cpk_jmol</Field>
                    <Field name="equal" type="bool">true</Field>
                    <Field name="smooth" type="bool">false</Field>
                    <Field name="discrete" type="bool">true</Field>
                    <Field name="colorsHaveOpacity" type="bool">true</Field>
                    <Field name="controlPts" type="floatVector">0 31 31 31 255 0.009 255 255 255 255 0.018 217 255 255 255 0.028 204 128 255 255 0.037 194 255 0 255 0.046 255 181 181 255 0.055 144 144 144 255 0.064 47 80 248 255 0.073 255 13 13 255 0.083 144 223 80 255 0.092 179 226 245 255 0.101 171 92 241 255 0.11 137 255 0 255 0.119 190 166 166 255 0.128 239 199 159 255 0.138 255 128 0 255 0.147 255 255 47 255 0.156 31 239 31 255 0.165 128 209 226 255 0.174 143 64 211 255 0.183 60 255 0 255 0.193 230 230 230 255 0.202 190 194 198 255 0.211 166 166 171 255 0.22 137 153 198 255 0.229 156 121 198 255 0.239 223 102 51 255 0.248 239 144 159 255 0.257 80 208 80 255 0.266 199 128 51 255 0.275 124 128 175 255 0.284 194 143 143 255 0.294 102 143 143 255 0.303 188 128 226 255 0.312 255 160 0 255 0.321 166 41 41 255 0.33 92 184 209 255 0.339 111 45 175 255 0.349 0 255 0 255 0.358 147 255 255 255 0.367 147 223 223 255 0.376 115 194 200 255 0.385 83 181 181 255 0.394 58 158 158 255 0.404 35 143 143 255 0.413 9 124 139 255 0.422 0 105 133 255 0.431 192 192 192 255 0.44 255 217 143 255 0.45 166 117 115 255 0.459 102 128 128 255 0.468 158 98 181 255 0.477 211 121 0 255 0.486 147 0 147 255 0.495 66 158 175 255 0.505 86 22 143 255 0.514 0 200 0 255 0.523 111 211 255 255 0.532 255 255 198 255 0.541 217 255 198 255 0.55 198 255 198 255 0.56 162 255 198 255 0.569 143 255 198 255 0.578 96 255 198 255 0.587 69 255 198 255 0.596 47 255 198 255 0.606 31 255 198 255 0.615 0 255 156 255 0.624 0 230 117 255 0.633 0 211 82 255 0.642 0 190 56 255 0.651 0 171 35 255 0.661 77 194 255 255 0.67 77 166 255 255 0.679 32 147 213 255 0.688 37 124 171 255 0.697 37 102 149 255 0.706 22 83 134 255 0.716 208 208 223 255 0.725 255 209 34 255 0.734 184 184 208 255 0.743 166 83 77 255 0.752 86 88 96 255 0.761 158 79 181 255 0.771 171 92 0 255 0.78 117 79 69 255 0.789 66 130 149 255 0.798 66 0 102 255 0.807 0 124 0 255 0.817 111 171 249 255 0.826 0 185 255 255 0.835 0 160 255 255 0.844 0 143 255 255 0.853 0 128 255 255 0.862 0 107 255 255 0.872 83 92 241 255 0.881 120 92 226 255 0.89 137 79 226 255 0.899 160 54 211 255 0.908 179 31 211 255 0.917 179 31 185 255 0.927 179 13 166 255 0.936 188 13 134 255 0.945 198 0 102 255 0.954 204 0 88 255 0.963 209 0 79 255 0.972 217 0 69 255 0.982 223 0 56 255 0.991 230 0 45 255 1 235 0 37 255 </Field>
                </Object>
                <Object name="table07">
                    <Field name="ctName" type="string">cpk_rasmol</Field>
                    <Field name="equal" type="bool">true</Field>
                    <Field name="smooth" type="bool">false</Field>
                    <Field name="discrete" type="bool">true</Field>
                    <Field name="colorsHaveOpacity" type="bool">true</Field>
                    <Field name="controlPts" type="floatVector">0 31 31 31 255 0.009 255 255 255 255 0.018 255 192 202 255 0.028 177 33 33 255 0.037 255 19 146 255 0.046 0 255 0 255 0.055 199 199 199 255 0.064 143 143 255 255 0.073 239 0 0 255 0.083 218 164 31 255 0.092 255 19 146 255 0.101 0 0 255 255 0.11 33 138 33 255 0.119 128 128 144 255 0.128 218 164 31 255 0.138 255 164 0 255 0.147 255 199 49 255 0.156 0 255 0 255 0.165 255 19 146 255 0.174 255 19 146 255 0.183 128 128 144 255 0.193 255 19 146 255 0.202 128 128 144 255 0.211 255 19 146 255 0.22 128 128 144 255 0.229 128 128 144 255 0.239 255 164 0 255 0.248 255 19 146 255 0.257 164 42 42 255 0.266 164 42 42 255 0.275 164 42 42 255 0.284 255 19 146 255 0.294 255 19 146 255 0.303 255 19 146 255 0.312 255 19 146 255 0.321 164 42 42 255 0.33 255 19 146 255 0.339 255 19 146 255 0.349 255 19 146 255 0.358 255 19 146 255 0.367 255 19 146 255 0.376 255 19 146 255 0.385 255 19 146 255 0.394 255 19 146 255 0.404 255 19 146 255 0.413 255 19 146 255 0.422 255 19 146 255 0.431 128 128 144 255 0.44 255 19 146 255 0.45 255 19 146 255 0.459 255 19 146 255 0.468 255 19 146 255 0.477 255 19 146 255 0.486 159 31 239 255 0.495 255 19 146 255 0.505 255 19 146 255 0.514 255 164 0 255 0.523 255 19 146 255 0.532 255 19 146 255 0.541 255 19 146 255 0.55 255 19 146 255 0.56 255 19 146 255 0.569 255 19 146 255 0.578 255 19 146 255 0.587 255 19 146 255 0.596 255 19 146 255 0.606 255 19 146 255 0.615 255 19 146 255 0.624 255 19 146 255 0.633 255 19 146 255 0.642 255 19 146 255 0.651 255 19 146 255 0.661 255 19 146 255 0.67 255 19 146 255 0.679 255 19 146 255 0.688 255 19 146 255 0.697 255 19 146 255 0.706 255 19 146 255 0.716 255 19 146 255 0.725 218 164 31 255 0.734 255 19 146 255 0.743 255 19 146 255 0.752 255 19 146 255 0.761 255 19 146 255 0.771 255 19 146 255 0.78 255 19 146 255 0.789 255 19 146 255 0.798 255 19 146 255 0.807 255 19 146 255 0.817 255 19 146 255 0.826 255 19 146 255 0.835 255 19 146 255 0.844 255 19 146 255 0.853 255 19 146 255 0.862 255 19 146 255 0.872 255 19 146 255 0.881 255 19 146 255 0.89 255 19 146 255 0.899 255 19 146 255 0.908 255 19 146 255 0.917 255 19 146 255 0.927 255 19 146 255 0.936 255 19 146 255 0.945 255 19 146 255 0.954 255 19 146 255 0.963 255 19 146 255 0.972 255 19 146 255 0.982 255 19 146 255 0.991 255 19 146 255 1 255 19 146 255 </Field>
                </Object>
                <Object name="table08">
                    <Field name="ctName" type="string">difference</Field>
                    <Field name="colorsHaveOpacity" type="bool">true</Field>
                    <Field name="controlPts" type="floatVector">0 0 0 255 255 0.5 255 255 255 255 1 255 0 0 255 </Field>
                </Object>
                <Object name="table09">
                    <Field name="ctName" type="string">gray</Field>
                    <Field name="colorsHaveOpacity" type="bool">true</Field>
                    <Field name="controlPts" type="floatVector">0 0 0 0 255 1 255 255 255 255 </Field>
                </Object>
                <Object name="table10">
                    <Field name="ctName" type="string">hot</Field>
                    <Field name="colorsHaveOpacity" type="bool">true</Field>
                    <Field name="controlPts" type="floatVector">0 0 0 255 255 0.25 0 255 255 255 0.5 0 255 0 255 0.75 255 255 0 255 1 255 0 0 255 </Field>
                </Object>
                <Object name="table11">
                    <Field name="ctName" type="string">hot_and_cold</Field>
                    <Field name="colorsHaveOpacity" type="bool">true</Field>
                    <Field name="controlPts" type="floatVector">0 0 255 255 255 0.45 0 0 255 255 0.5 0 0 127 255 0.55 255 0 0 255 1 255 255 0 255 </Field>
                </Object>
                <Object name="table12">
                    <Field name="ctName" type="string">hot_desaturated</Field>
                    <Field name="colorsHaveOpacity" type="bool">true</Field>
                    <Field name="controlPts" type="floatVector">0 71 71 219 255 0.143 0 0 91 255 0.285 0 255 255 255 0.429 0 127 0 255 0.571 255 255 0 255 0.714 255 96 0 255 0.857 107 0 0 255 1 224 76 76 255 </Field>
                </Object>
                <Object name="table13">
                    <Field name="ctName" type="string">levels</Field>
                    <Field name="equal" type="bool">true</Field>
                    <Field name="smooth" type="bool">false</Field>
                    <Field name="discrete" type="bool">true</Field>
                    <Field name="colorsHaveOpacity" type="bool">true</Field>
                    <Field name="controlPts" type="floatVector">0 255 0 0 255 0.034 0 255 0 255 0.069 0 0 255 255 0.103 0 255 255 255 0.138 255 0 255 255 0.172 255 255 0 255 0.207 255 135 0 255 0.241 255 0 135 255 0.276 168 168 168 255 0.31 255 68 68 255 0.345 99 255 99 255 0.379 99 99 255 255 0.414 40 165 165 255 0.448 255 99 255 255 0.483 255 255 99 255 0.517 255 170 99 255 0.552 170 79 255 255 0.586 150 0 0 255 0.621 0 150 0 255 0.655 0 0 150 255 0.69 0 109 109 255 0.724 150 0 150 255 0.759 150 150 0 255 0.793 150 84 0 255 0.828 160 0 79 255 0.862 255 104 28 255 0.897 0 170 81 255 0.931 68 255 124 255 0.966 0 130 255 255 1 130 0 255 255 </Field>
                </Object>
                <Object name="table14">
                    <Field name="ctName" type="string">orangehot</Field>
                    <Field name="colorsHaveOpacity" type="bool">true</Field>
                    <Field name="controlPts" type="floatVector">0 0 0 0 255 0.333 127 0 0 255 0.666 255 127 0 255 1 255 255 255 255 </Field>
                </Object>
                <Object name="table15">
                    <Field name="ctName" type="string">rainbow</Field>
                    <Field name="colorsHaveOpacity" type="bool">true</Field>
                    <Field name="controlPts" type="floatVector">0 255 0 255 255 0.2 0 0 255 255 0.4 0 255 255 255 0.6 0 255 0 255 0.8 255 255 0 255 1 255 0 0 255 </Field>
                </Object>
                <Object name="table16">
                    <Field name="ctName" type="string">xray</Field>
                    <Field name="colorsHaveOpacity" type="bool">true</Field>
                    <Field name="controlPts" type="floatVector">0 255 255 255 255 1 0 0 0 255 </Field>
                </Object>
                <Field name="Ntables" type="int">17</Field>
            </Object>
            <Object name="ExpressionList">
                <Object name="Expression">
                    <Field name="name" type="string">operators/ConnectedComponents/cp_mesh</Field>
                    <Field name="definition" type="string">"cell_constant(cp_mesh, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">ScalarMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">ConnectedComponents</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/ConnectedComponents/edge_mesh</Field>
                    <Field name="definition" type="string">"cell_constant(edge_mesh, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">ScalarMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">ConnectedComponents</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/ConnectedComponents/external_face_mesh</Field>
                    <Field name="definition" type="string">"cell_constant(external_face_mesh, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">ScalarMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">ConnectedComponents</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/ConnectedComponents/face_mesh</Field>
                    <Field name="definition" type="string">"cell_constant(face_mesh, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">ScalarMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">ConnectedComponents</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/ConnectedComponents/volume_mesh</Field>
                    <Field name="definition" type="string">"cell_constant(volume_mesh, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">ScalarMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">ConnectedComponents</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/DataBinning/1D/cp_mesh</Field>
                    <Field name="definition" type="string">"cell_constant(cp_mesh, 0)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">DataBinning</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/DataBinning/2D/cp_mesh</Field>
                    <Field name="definition" type="string">"cell_constant(cp_mesh, 0)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">ScalarMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">DataBinning</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/DataBinning/3D/cp_mesh</Field>
                    <Field name="definition" type="string">"cell_constant(cp_mesh, 0)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">ScalarMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">DataBinning</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/DataBinning/1D/edge_mesh</Field>
                    <Field name="definition" type="string">"cell_constant(edge_mesh, 0)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">DataBinning</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/DataBinning/2D/edge_mesh</Field>
                    <Field name="definition" type="string">"cell_constant(edge_mesh, 0)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">ScalarMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">DataBinning</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/DataBinning/3D/edge_mesh</Field>
                    <Field name="definition" type="string">"cell_constant(edge_mesh, 0)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">ScalarMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">DataBinning</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/DataBinning/1D/external_face_mesh</Field>
                    <Field name="definition" type="string">"cell_constant(external_face_mesh, 0)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">DataBinning</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/DataBinning/2D/external_face_mesh</Field>
                    <Field name="definition" type="string">"cell_constant(external_face_mesh, 0)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">ScalarMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">DataBinning</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/DataBinning/3D/external_face_mesh</Field>
                    <Field name="definition" type="string">"cell_constant(external_face_mesh, 0)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">ScalarMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">DataBinning</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/DataBinning/1D/face_mesh</Field>
                    <Field name="definition" type="string">"cell_constant(face_mesh, 0)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">DataBinning</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/DataBinning/2D/face_mesh</Field>
                    <Field name="definition" type="string">"cell_constant(face_mesh, 0)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">ScalarMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">DataBinning</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/DataBinning/3D/face_mesh</Field>
                    <Field name="definition" type="string">"cell_constant(face_mesh, 0)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">ScalarMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">DataBinning</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/DataBinning/1D/volume_mesh</Field>
                    <Field name="definition" type="string">"cell_constant(volume_mesh, 0)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">DataBinning</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/DataBinning/2D/volume_mesh</Field>
                    <Field name="definition" type="string">"cell_constant(volume_mesh, 0)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">ScalarMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">DataBinning</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/DataBinning/3D/volume_mesh</Field>
                    <Field name="definition" type="string">"cell_constant(volume_mesh, 0)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">ScalarMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">DataBinning</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Flux/cp_mesh</Field>
                    <Field name="definition" type="string">"cell_constant(cp_mesh, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">ScalarMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Flux</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Flux/edge_mesh</Field>
                    <Field name="definition" type="string">"cell_constant(edge_mesh, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">ScalarMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Flux</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Flux/external_face_mesh</Field>
                    <Field name="definition" type="string">"cell_constant(external_face_mesh, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">ScalarMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Flux</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Flux/face_mesh</Field>
                    <Field name="definition" type="string">"cell_constant(face_mesh, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">ScalarMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Flux</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Flux/volume_mesh</Field>
                    <Field name="definition" type="string">"cell_constant(volume_mesh, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">ScalarMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Flux</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/CommonPlaneFields/active</Field>
                    <Field name="definition" type="string">"cell_constant(\<CommonPlaneFields/active\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/CommonPlaneFields/area</Field>
                    <Field name="definition" type="string">"cell_constant(\<CommonPlaneFields/area\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/CommonPlaneFields/face1</Field>
                    <Field name="definition" type="string">"cell_constant(\<CommonPlaneFields/face1\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/CommonPlaneFields/face2</Field>
                    <Field name="definition" type="string">"cell_constant(\<CommonPlaneFields/face2\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/CommonPlaneFields/isDomainBoundary</Field>
                    <Field name="definition" type="string">"cell_constant(\<CommonPlaneFields/isDomainBoundary\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/CommonPlaneFields/isExternal</Field>
                    <Field name="definition" type="string">"cell_constant(\<CommonPlaneFields/isExternal\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/CommonPlaneFields/isGhost</Field>
                    <Field name="definition" type="string">"cell_constant(\<CommonPlaneFields/isGhost\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/CommonPlaneFields/normalApproach</Field>
                    <Field name="definition" type="string">"cell_constant(\<CommonPlaneFields/normalApproach\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/CommonPlaneFields/normalApproachMax</Field>
                    <Field name="definition" type="string">"cell_constant(\<CommonPlaneFields/normalApproachMax\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/CommonPlaneFields/ownership</Field>
                    <Field name="definition" type="string">"cell_constant(\<CommonPlaneFields/ownership\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/CommonPlaneFields/slip</Field>
                    <Field name="definition" type="string">"cell_constant(\<CommonPlaneFields/slip\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/CommonPlaneFields/stressNormal</Field>
                    <Field name="definition" type="string">"cell_constant(\<CommonPlaneFields/stressNormal\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/EdgeFields/FlowFaceCount</Field>
                    <Field name="definition" type="string">"cell_constant(\<EdgeFields/FlowFaceCount\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/EdgeFields/GlobalNumbers</Field>
                    <Field name="definition" type="string">"cell_constant(\<EdgeFields/GlobalNumbers\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/EdgeFields/Permeability</Field>
                    <Field name="definition" type="string">"cell_constant(\<EdgeFields/Permeability\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/EdgeFields/VolumetricFlux</Field>
                    <Field name="definition" type="string">"cell_constant(\<EdgeFields/VolumetricFlux\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/EdgeFields/isDomainBoundary</Field>
                    <Field name="definition" type="string">"cell_constant(\<EdgeFields/isDomainBoundary\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/EdgeFields/isExternal</Field>
                    <Field name="definition" type="string">"cell_constant(\<EdgeFields/isExternal\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/EdgeFields/isGhost</Field>
                    <Field name="definition" type="string">"cell_constant(\<EdgeFields/isGhost\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/EdgeFields/ownership</Field>
                    <Field name="definition" type="string">"cell_constant(\<EdgeFields/ownership\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/ExternalFaceFields/GlobalNumbers</Field>
                    <Field name="definition" type="string">"cell_constant(\<ExternalFaceFields/GlobalNumbers\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/ExternalFaceFields/aperture</Field>
                    <Field name="definition" type="string">"cell_constant(\<ExternalFaceFields/aperture\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/ExternalFaceFields/area</Field>
                    <Field name="definition" type="string">"cell_constant(\<ExternalFaceFields/area\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/ExternalFaceFields/boundingRadius</Field>
                    <Field name="definition" type="string">"cell_constant(\<ExternalFaceFields/boundingRadius\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/ExternalFaceFields/boundingRadiusLastSort</Field>
                    <Field name="definition" type="string">"cell_constant(\<ExternalFaceFields/boundingRadiusLastSort\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/ExternalFaceFields/frictionSlope</Field>
                    <Field name="definition" type="string">"cell_constant(\<ExternalFaceFields/frictionSlope\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/ExternalFaceFields/isDomainBoundary</Field>
                    <Field name="definition" type="string">"cell_constant(\<ExternalFaceFields/isDomainBoundary\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/ExternalFaceFields/isExternal</Field>
                    <Field name="definition" type="string">"cell_constant(\<ExternalFaceFields/isExternal\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/ExternalFaceFields/isGhost</Field>
                    <Field name="definition" type="string">"cell_constant(\<ExternalFaceFields/isGhost\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/ExternalFaceFields/normalApproach</Field>
                    <Field name="definition" type="string">"cell_constant(\<ExternalFaceFields/normalApproach\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/ExternalFaceFields/normalApproachMax</Field>
                    <Field name="definition" type="string">"cell_constant(\<ExternalFaceFields/normalApproachMax\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/ExternalFaceFields/ownership</Field>
                    <Field name="definition" type="string">"cell_constant(\<ExternalFaceFields/ownership\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/ExternalFaceFields/stressNormal</Field>
                    <Field name="definition" type="string">"cell_constant(\<ExternalFaceFields/stressNormal\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/FaceFields/Aperture</Field>
                    <Field name="definition" type="string">"cell_constant(\<FaceFields/Aperture\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/FaceFields/Density</Field>
                    <Field name="definition" type="string">"cell_constant(\<FaceFields/Density\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/FaceFields/Floor</Field>
                    <Field name="definition" type="string">"cell_constant(\<FaceFields/Floor\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/FaceFields/FlowSurface</Field>
                    <Field name="definition" type="string">"cell_constant(\<FaceFields/FlowSurface\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/FaceFields/GlobalNumbers</Field>
                    <Field name="definition" type="string">"cell_constant(\<FaceFields/GlobalNumbers\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/FaceFields/Mass</Field>
                    <Field name="definition" type="string">"cell_constant(\<FaceFields/Mass\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/FaceFields/Pressure</Field>
                    <Field name="definition" type="string">"cell_constant(\<FaceFields/Pressure\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/FaceFields/TwoDSSPPFS_1_GlobalDof</Field>
                    <Field name="definition" type="string">"cell_constant(\<FaceFields/TwoDSSPPFS_1_GlobalDof\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/FaceFields/ZshiftFloor</Field>
                    <Field name="definition" type="string">"cell_constant(\<FaceFields/ZshiftFloor\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/FaceFields/ZshiftRoof</Field>
                    <Field name="definition" type="string">"cell_constant(\<FaceFields/ZshiftRoof\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/FaceFields/externalFaceIndex</Field>
                    <Field name="definition" type="string">"cell_constant(\<FaceFields/externalFaceIndex\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/FaceFields/isDomainBoundary</Field>
                    <Field name="definition" type="string">"cell_constant(\<FaceFields/isDomainBoundary\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/FaceFields/isExternal</Field>
                    <Field name="definition" type="string">"cell_constant(\<FaceFields/isExternal\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/FaceFields/isGhost</Field>
                    <Field name="definition" type="string">"cell_constant(\<FaceFields/isGhost\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/FaceFields/ownership</Field>
                    <Field name="definition" type="string">"cell_constant(\<FaceFields/ownership\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/FaceFields/ruptureState</Field>
                    <Field name="definition" type="string">"cell_constant(\<FaceFields/ruptureState\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/FaceFields/verticalAperture</Field>
                    <Field name="definition" type="string">"cell_constant(\<FaceFields/verticalAperture\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/Fracture_Floor/Density</Field>
                    <Field name="definition" type="string">"cell_constant(\<Fracture_Floor/Density\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/Fracture_Floor/GlobalNumbers</Field>
                    <Field name="definition" type="string">"cell_constant(\<Fracture_Floor/GlobalNumbers\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/Fracture_Floor/Mass</Field>
                    <Field name="definition" type="string">"cell_constant(\<Fracture_Floor/Mass\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/Fracture_Floor/Pressure</Field>
                    <Field name="definition" type="string">"cell_constant(\<Fracture_Floor/Pressure\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/Fracture_Floor/Volume</Field>
                    <Field name="definition" type="string">"cell_constant(\<Fracture_Floor/Volume\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/Fracture_Floor/isDomainBoundary</Field>
                    <Field name="definition" type="string">"cell_constant(\<Fracture_Floor/isDomainBoundary\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/Fracture_Floor/isExternal</Field>
                    <Field name="definition" type="string">"cell_constant(\<Fracture_Floor/isExternal\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/Fracture_Floor/isGhost</Field>
                    <Field name="definition" type="string">"cell_constant(\<Fracture_Floor/isGhost\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/Fracture_Floor/ownership</Field>
                    <Field name="definition" type="string">"cell_constant(\<Fracture_Floor/ownership\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/Fracture_Floor/sigma_x</Field>
                    <Field name="definition" type="string">"cell_constant(\<Fracture_Floor/sigma_x\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/Fracture_Floor/sigma_y</Field>
                    <Field name="definition" type="string">"cell_constant(\<Fracture_Floor/sigma_y\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/Fracture_Floor/sigma_z</Field>
                    <Field name="definition" type="string">"cell_constant(\<Fracture_Floor/sigma_z\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/Fracture_Roof/Density</Field>
                    <Field name="definition" type="string">"cell_constant(\<Fracture_Roof/Density\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/Fracture_Roof/GlobalNumbers</Field>
                    <Field name="definition" type="string">"cell_constant(\<Fracture_Roof/GlobalNumbers\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/Fracture_Roof/Mass</Field>
                    <Field name="definition" type="string">"cell_constant(\<Fracture_Roof/Mass\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/Fracture_Roof/Pressure</Field>
                    <Field name="definition" type="string">"cell_constant(\<Fracture_Roof/Pressure\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/Fracture_Roof/Volume</Field>
                    <Field name="definition" type="string">"cell_constant(\<Fracture_Roof/Volume\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/Fracture_Roof/isDomainBoundary</Field>
                    <Field name="definition" type="string">"cell_constant(\<Fracture_Roof/isDomainBoundary\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/Fracture_Roof/isExternal</Field>
                    <Field name="definition" type="string">"cell_constant(\<Fracture_Roof/isExternal\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/Fracture_Roof/isGhost</Field>
                    <Field name="definition" type="string">"cell_constant(\<Fracture_Roof/isGhost\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/Fracture_Roof/ownership</Field>
                    <Field name="definition" type="string">"cell_constant(\<Fracture_Roof/ownership\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/Fracture_Roof/sigma_x</Field>
                    <Field name="definition" type="string">"cell_constant(\<Fracture_Roof/sigma_x\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/Fracture_Roof/sigma_y</Field>
                    <Field name="definition" type="string">"cell_constant(\<Fracture_Roof/sigma_y\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/Fracture_Roof/sigma_z</Field>
                    <Field name="definition" type="string">"cell_constant(\<Fracture_Roof/sigma_z\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/NodalFields/Floor</Field>
                    <Field name="definition" type="string">"cell_constant(\<NodalFields/Floor\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/NodalFields/GlobalNumbers</Field>
                    <Field name="definition" type="string">"cell_constant(\<NodalFields/GlobalNumbers\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/NodalFields/IMS_0_GlobalDof</Field>
                    <Field name="definition" type="string">"cell_constant(\<NodalFields/IMS_0_GlobalDof\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/NodalFields/Mass</Field>
                    <Field name="definition" type="string">"cell_constant(\<NodalFields/Mass\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/NodalFields/ZshiftFloor</Field>
                    <Field name="definition" type="string">"cell_constant(\<NodalFields/ZshiftFloor\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/NodalFields/ZshiftRoof</Field>
                    <Field name="definition" type="string">"cell_constant(\<NodalFields/ZshiftRoof\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/NodalFields/inContact</Field>
                    <Field name="definition" type="string">"cell_constant(\<NodalFields/inContact\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/NodalFields/isDomainBoundary</Field>
                    <Field name="definition" type="string">"cell_constant(\<NodalFields/isDomainBoundary\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/NodalFields/isExternal</Field>
                    <Field name="definition" type="string">"cell_constant(\<NodalFields/isExternal\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/NodalFields/isGhost</Field>
                    <Field name="definition" type="string">"cell_constant(\<NodalFields/isGhost\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/NodalFields/numberOfRupturedFaces</Field>
                    <Field name="definition" type="string">"cell_constant(\<NodalFields/numberOfRupturedFaces\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/NodalFields/ownership</Field>
                    <Field name="definition" type="string">"cell_constant(\<NodalFields/ownership\>, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/cp_mesh/aspect_gamma</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/cp_mesh/aspect_gamma, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/cp_mesh/aspect</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/cp_mesh/aspect, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/cp_mesh/condition</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/cp_mesh/condition, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/cp_mesh/diagonal_ratio</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/cp_mesh/diagonal_ratio, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/cp_mesh/min_diagonal</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/cp_mesh/min_diagonal, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/cp_mesh/max_diagonal</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/cp_mesh/max_diagonal, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/cp_mesh/dimension</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/cp_mesh/dimension, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/cp_mesh/jacobian</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/cp_mesh/jacobian, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/cp_mesh/max_edge_length</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/cp_mesh/max_edge_length, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/cp_mesh/max_side_volume</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/cp_mesh/max_side_volume, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/cp_mesh/min_edge_length</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/cp_mesh/min_edge_length, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/cp_mesh/min_side_volume</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/cp_mesh/min_side_volume, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/cp_mesh/oddy</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/cp_mesh/oddy, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/cp_mesh/relative_size</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/cp_mesh/relative_size, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/cp_mesh/scaled_jacobian</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/cp_mesh/scaled_jacobian, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/cp_mesh/shape</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/cp_mesh/shape, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/cp_mesh/shape_and_size</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/cp_mesh/shape_and_size, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/cp_mesh/shear</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/cp_mesh/shear, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/cp_mesh/skew</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/cp_mesh/skew, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/cp_mesh/stretch</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/cp_mesh/stretch, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/cp_mesh/taper</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/cp_mesh/taper, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/cp_mesh/volume</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/cp_mesh/volume, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/cp_mesh/face_planarity</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/cp_mesh/face_planarity, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/cp_mesh/relative_face_planarity</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/cp_mesh/relative_face_planarity, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/edge_mesh/aspect_gamma</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/edge_mesh/aspect_gamma, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/edge_mesh/aspect</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/edge_mesh/aspect, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/edge_mesh/condition</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/edge_mesh/condition, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/edge_mesh/diagonal_ratio</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/edge_mesh/diagonal_ratio, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/edge_mesh/min_diagonal</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/edge_mesh/min_diagonal, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/edge_mesh/max_diagonal</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/edge_mesh/max_diagonal, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/edge_mesh/dimension</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/edge_mesh/dimension, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/edge_mesh/jacobian</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/edge_mesh/jacobian, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/edge_mesh/max_edge_length</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/edge_mesh/max_edge_length, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/edge_mesh/max_side_volume</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/edge_mesh/max_side_volume, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/edge_mesh/min_edge_length</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/edge_mesh/min_edge_length, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/edge_mesh/min_side_volume</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/edge_mesh/min_side_volume, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/edge_mesh/oddy</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/edge_mesh/oddy, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/edge_mesh/relative_size</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/edge_mesh/relative_size, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/edge_mesh/scaled_jacobian</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/edge_mesh/scaled_jacobian, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/edge_mesh/shape</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/edge_mesh/shape, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/edge_mesh/shape_and_size</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/edge_mesh/shape_and_size, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/edge_mesh/shear</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/edge_mesh/shear, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/edge_mesh/skew</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/edge_mesh/skew, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/edge_mesh/stretch</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/edge_mesh/stretch, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/edge_mesh/taper</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/edge_mesh/taper, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/edge_mesh/volume</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/edge_mesh/volume, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/edge_mesh/face_planarity</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/edge_mesh/face_planarity, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/edge_mesh/relative_face_planarity</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/edge_mesh/relative_face_planarity, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/external_face_mesh/aspect_gamma</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/external_face_mesh/aspect_gamma, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/external_face_mesh/aspect</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/external_face_mesh/aspect, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/external_face_mesh/condition</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/external_face_mesh/condition, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/external_face_mesh/diagonal_ratio</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/external_face_mesh/diagonal_ratio, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/external_face_mesh/min_diagonal</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/external_face_mesh/min_diagonal, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/external_face_mesh/max_diagonal</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/external_face_mesh/max_diagonal, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/external_face_mesh/dimension</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/external_face_mesh/dimension, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/external_face_mesh/jacobian</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/external_face_mesh/jacobian, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/external_face_mesh/max_edge_length</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/external_face_mesh/max_edge_length, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/external_face_mesh/max_side_volume</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/external_face_mesh/max_side_volume, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/external_face_mesh/min_edge_length</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/external_face_mesh/min_edge_length, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/external_face_mesh/min_side_volume</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/external_face_mesh/min_side_volume, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/external_face_mesh/oddy</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/external_face_mesh/oddy, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/external_face_mesh/relative_size</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/external_face_mesh/relative_size, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/external_face_mesh/scaled_jacobian</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/external_face_mesh/scaled_jacobian, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/external_face_mesh/shape</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/external_face_mesh/shape, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/external_face_mesh/shape_and_size</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/external_face_mesh/shape_and_size, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/external_face_mesh/shear</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/external_face_mesh/shear, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/external_face_mesh/skew</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/external_face_mesh/skew, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/external_face_mesh/stretch</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/external_face_mesh/stretch, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/external_face_mesh/taper</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/external_face_mesh/taper, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/external_face_mesh/volume</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/external_face_mesh/volume, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/external_face_mesh/face_planarity</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/external_face_mesh/face_planarity, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/external_face_mesh/relative_face_planarity</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/external_face_mesh/relative_face_planarity, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/face_mesh/aspect_gamma</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/face_mesh/aspect_gamma, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/face_mesh/aspect</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/face_mesh/aspect, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/face_mesh/condition</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/face_mesh/condition, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/face_mesh/diagonal_ratio</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/face_mesh/diagonal_ratio, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/face_mesh/min_diagonal</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/face_mesh/min_diagonal, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/face_mesh/max_diagonal</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/face_mesh/max_diagonal, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/face_mesh/dimension</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/face_mesh/dimension, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/face_mesh/jacobian</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/face_mesh/jacobian, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/face_mesh/max_edge_length</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/face_mesh/max_edge_length, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/face_mesh/max_side_volume</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/face_mesh/max_side_volume, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/face_mesh/min_edge_length</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/face_mesh/min_edge_length, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/face_mesh/min_side_volume</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/face_mesh/min_side_volume, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/face_mesh/oddy</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/face_mesh/oddy, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/face_mesh/relative_size</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/face_mesh/relative_size, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/face_mesh/scaled_jacobian</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/face_mesh/scaled_jacobian, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/face_mesh/shape</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/face_mesh/shape, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/face_mesh/shape_and_size</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/face_mesh/shape_and_size, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/face_mesh/shear</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/face_mesh/shear, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/face_mesh/skew</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/face_mesh/skew, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/face_mesh/stretch</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/face_mesh/stretch, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/face_mesh/taper</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/face_mesh/taper, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/face_mesh/volume</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/face_mesh/volume, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/face_mesh/face_planarity</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/face_mesh/face_planarity, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/face_mesh/relative_face_planarity</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/face_mesh/relative_face_planarity, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/volume_mesh/aspect_gamma</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/volume_mesh/aspect_gamma, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/volume_mesh/aspect</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/volume_mesh/aspect, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/volume_mesh/condition</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/volume_mesh/condition, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/volume_mesh/diagonal_ratio</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/volume_mesh/diagonal_ratio, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/volume_mesh/min_diagonal</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/volume_mesh/min_diagonal, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/volume_mesh/max_diagonal</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/volume_mesh/max_diagonal, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/volume_mesh/dimension</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/volume_mesh/dimension, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/volume_mesh/jacobian</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/volume_mesh/jacobian, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/volume_mesh/max_edge_length</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/volume_mesh/max_edge_length, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/volume_mesh/max_side_volume</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/volume_mesh/max_side_volume, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/volume_mesh/min_edge_length</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/volume_mesh/min_edge_length, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/volume_mesh/min_side_volume</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/volume_mesh/min_side_volume, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/volume_mesh/oddy</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/volume_mesh/oddy, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/volume_mesh/relative_size</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/volume_mesh/relative_size, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/volume_mesh/scaled_jacobian</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/volume_mesh/scaled_jacobian, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/volume_mesh/shape</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/volume_mesh/shape, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/volume_mesh/shape_and_size</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/volume_mesh/shape_and_size, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/volume_mesh/shear</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/volume_mesh/shear, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/volume_mesh/skew</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/volume_mesh/skew, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/volume_mesh/stretch</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/volume_mesh/stretch, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/volume_mesh/taper</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/volume_mesh/taper, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/volume_mesh/volume</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/volume_mesh/volume, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/volume_mesh/face_planarity</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/volume_mesh/face_planarity, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/mesh_quality/volume_mesh/relative_face_planarity</Field>
                    <Field name="definition" type="string">"cell_constant(mesh_quality/volume_mesh/relative_face_planarity, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/conn_based/cp_mesh_time</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/conn_based/cp_mesh_time, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/conn_based/cp_mesh_lasttime</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/conn_based/cp_mesh_lasttime, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/pos_based/cp_mesh_time</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/pos_based/cp_mesh_time, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/pos_based/cp_mesh_lasttime</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/pos_based/cp_mesh_lasttime, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/conn_based/CommonPlaneFields/active</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/conn_based/CommonPlaneFields/active, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/pos_based/CommonPlaneFields/active</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/pos_based/CommonPlaneFields/active, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/conn_based/CommonPlaneFields/area</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/conn_based/CommonPlaneFields/area, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/pos_based/CommonPlaneFields/area</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/pos_based/CommonPlaneFields/area, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/conn_based/CommonPlaneFields/face1</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/conn_based/CommonPlaneFields/face1, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/pos_based/CommonPlaneFields/face1</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/pos_based/CommonPlaneFields/face1, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/conn_based/CommonPlaneFields/face2</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/conn_based/CommonPlaneFields/face2, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/pos_based/CommonPlaneFields/face2</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/pos_based/CommonPlaneFields/face2, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/conn_based/CommonPlaneFields/isDomainBoundary</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/conn_based/CommonPlaneFields/isDomainBoundary, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/pos_based/CommonPlaneFields/isDomainBoundary</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/pos_based/CommonPlaneFields/isDomainBoundary, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/conn_based/CommonPlaneFields/isExternal</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/conn_based/CommonPlaneFields/isExternal, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/pos_based/CommonPlaneFields/isExternal</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/pos_based/CommonPlaneFields/isExternal, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/conn_based/CommonPlaneFields/isGhost</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/conn_based/CommonPlaneFields/isGhost, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/pos_based/CommonPlaneFields/isGhost</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/pos_based/CommonPlaneFields/isGhost, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/conn_based/CommonPlaneFields/normalApproach</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/conn_based/CommonPlaneFields/normalApproach, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/pos_based/CommonPlaneFields/normalApproach</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/pos_based/CommonPlaneFields/normalApproach, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/conn_based/CommonPlaneFields/normalApproachMax</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/conn_based/CommonPlaneFields/normalApproachMax, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/pos_based/CommonPlaneFields/normalApproachMax</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/pos_based/CommonPlaneFields/normalApproachMax, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/conn_based/CommonPlaneFields/ownership</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/conn_based/CommonPlaneFields/ownership, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/pos_based/CommonPlaneFields/ownership</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/pos_based/CommonPlaneFields/ownership, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/conn_based/CommonPlaneFields/slip</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/conn_based/CommonPlaneFields/slip, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/pos_based/CommonPlaneFields/slip</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/pos_based/CommonPlaneFields/slip, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/conn_based/CommonPlaneFields/stressNormal</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/conn_based/CommonPlaneFields/stressNormal, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/pos_based/CommonPlaneFields/stressNormal</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/pos_based/CommonPlaneFields/stressNormal, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/edge_mesh/conn_based/edge_mesh_time</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/edge_mesh/conn_based/edge_mesh_time, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/edge_mesh/conn_based/edge_mesh_lasttime</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/edge_mesh/conn_based/edge_mesh_lasttime, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/edge_mesh/pos_based/edge_mesh_time</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/edge_mesh/pos_based/edge_mesh_time, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/edge_mesh/pos_based/edge_mesh_lasttime</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/edge_mesh/pos_based/edge_mesh_lasttime, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/edge_mesh/conn_based/EdgeFields/FlowFaceCount</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/edge_mesh/conn_based/EdgeFields/FlowFaceCount, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/edge_mesh/pos_based/EdgeFields/FlowFaceCount</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/edge_mesh/pos_based/EdgeFields/FlowFaceCount, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/edge_mesh/conn_based/EdgeFields/GlobalNumbers</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/edge_mesh/conn_based/EdgeFields/GlobalNumbers, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/edge_mesh/pos_based/EdgeFields/GlobalNumbers</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/edge_mesh/pos_based/EdgeFields/GlobalNumbers, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/edge_mesh/conn_based/EdgeFields/Permeability</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/edge_mesh/conn_based/EdgeFields/Permeability, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/edge_mesh/pos_based/EdgeFields/Permeability</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/edge_mesh/pos_based/EdgeFields/Permeability, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/edge_mesh/conn_based/EdgeFields/VolumetricFlux</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/edge_mesh/conn_based/EdgeFields/VolumetricFlux, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/edge_mesh/pos_based/EdgeFields/VolumetricFlux</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/edge_mesh/pos_based/EdgeFields/VolumetricFlux, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/edge_mesh/conn_based/EdgeFields/isDomainBoundary</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/edge_mesh/conn_based/EdgeFields/isDomainBoundary, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/edge_mesh/pos_based/EdgeFields/isDomainBoundary</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/edge_mesh/pos_based/EdgeFields/isDomainBoundary, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/edge_mesh/conn_based/EdgeFields/isExternal</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/edge_mesh/conn_based/EdgeFields/isExternal, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/edge_mesh/pos_based/EdgeFields/isExternal</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/edge_mesh/pos_based/EdgeFields/isExternal, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/edge_mesh/conn_based/EdgeFields/isGhost</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/edge_mesh/conn_based/EdgeFields/isGhost, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/edge_mesh/pos_based/EdgeFields/isGhost</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/edge_mesh/pos_based/EdgeFields/isGhost, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/edge_mesh/conn_based/EdgeFields/ownership</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/edge_mesh/conn_based/EdgeFields/ownership, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/edge_mesh/pos_based/EdgeFields/ownership</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/edge_mesh/pos_based/EdgeFields/ownership, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/conn_based/external_face_mesh_time</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/conn_based/external_face_mesh_time, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/conn_based/external_face_mesh_lasttime</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/conn_based/external_face_mesh_lasttime, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/pos_based/external_face_mesh_time</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/pos_based/external_face_mesh_time, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/pos_based/external_face_mesh_lasttime</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/pos_based/external_face_mesh_lasttime, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/conn_based/ExternalFaceFields/GlobalNumbers</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/conn_based/ExternalFaceFields/GlobalNumbers, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/pos_based/ExternalFaceFields/GlobalNumbers</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/pos_based/ExternalFaceFields/GlobalNumbers, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/conn_based/ExternalFaceFields/aperture</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/conn_based/ExternalFaceFields/aperture, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/pos_based/ExternalFaceFields/aperture</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/pos_based/ExternalFaceFields/aperture, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/conn_based/ExternalFaceFields/area</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/conn_based/ExternalFaceFields/area, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/pos_based/ExternalFaceFields/area</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/pos_based/ExternalFaceFields/area, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/conn_based/ExternalFaceFields/boundingRadius</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/conn_based/ExternalFaceFields/boundingRadius, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/pos_based/ExternalFaceFields/boundingRadius</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/pos_based/ExternalFaceFields/boundingRadius, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/conn_based/ExternalFaceFields/boundingRadiusLastSort</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/conn_based/ExternalFaceFields/boundingRadiusLastSort, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/pos_based/ExternalFaceFields/boundingRadiusLastSort</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/pos_based/ExternalFaceFields/boundingRadiusLastSort, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/conn_based/ExternalFaceFields/frictionSlope</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/conn_based/ExternalFaceFields/frictionSlope, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/pos_based/ExternalFaceFields/frictionSlope</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/pos_based/ExternalFaceFields/frictionSlope, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/conn_based/ExternalFaceFields/isDomainBoundary</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/conn_based/ExternalFaceFields/isDomainBoundary, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/pos_based/ExternalFaceFields/isDomainBoundary</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/pos_based/ExternalFaceFields/isDomainBoundary, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/conn_based/ExternalFaceFields/isExternal</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/conn_based/ExternalFaceFields/isExternal, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/pos_based/ExternalFaceFields/isExternal</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/pos_based/ExternalFaceFields/isExternal, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/conn_based/ExternalFaceFields/isGhost</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/conn_based/ExternalFaceFields/isGhost, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/pos_based/ExternalFaceFields/isGhost</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/pos_based/ExternalFaceFields/isGhost, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/conn_based/ExternalFaceFields/normalApproach</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/conn_based/ExternalFaceFields/normalApproach, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/pos_based/ExternalFaceFields/normalApproach</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/pos_based/ExternalFaceFields/normalApproach, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/conn_based/ExternalFaceFields/normalApproachMax</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/conn_based/ExternalFaceFields/normalApproachMax, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/pos_based/ExternalFaceFields/normalApproachMax</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/pos_based/ExternalFaceFields/normalApproachMax, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/conn_based/ExternalFaceFields/ownership</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/conn_based/ExternalFaceFields/ownership, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/pos_based/ExternalFaceFields/ownership</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/pos_based/ExternalFaceFields/ownership, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/conn_based/ExternalFaceFields/stressNormal</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/conn_based/ExternalFaceFields/stressNormal, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/pos_based/ExternalFaceFields/stressNormal</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/pos_based/ExternalFaceFields/stressNormal, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/conn_based/face_mesh_time</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/conn_based/face_mesh_time, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/conn_based/face_mesh_lasttime</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/conn_based/face_mesh_lasttime, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/pos_based/face_mesh_time</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/pos_based/face_mesh_time, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/pos_based/face_mesh_lasttime</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/pos_based/face_mesh_lasttime, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/conn_based/FaceFields/Aperture</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/conn_based/FaceFields/Aperture, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/pos_based/FaceFields/Aperture</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/pos_based/FaceFields/Aperture, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/conn_based/FaceFields/Density</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/conn_based/FaceFields/Density, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/pos_based/FaceFields/Density</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/pos_based/FaceFields/Density, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/conn_based/FaceFields/Floor</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/conn_based/FaceFields/Floor, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/pos_based/FaceFields/Floor</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/pos_based/FaceFields/Floor, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/conn_based/FaceFields/FlowSurface</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/conn_based/FaceFields/FlowSurface, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/pos_based/FaceFields/FlowSurface</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/pos_based/FaceFields/FlowSurface, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/conn_based/FaceFields/GlobalNumbers</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/conn_based/FaceFields/GlobalNumbers, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/pos_based/FaceFields/GlobalNumbers</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/pos_based/FaceFields/GlobalNumbers, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/conn_based/FaceFields/Mass</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/conn_based/FaceFields/Mass, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/pos_based/FaceFields/Mass</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/pos_based/FaceFields/Mass, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/conn_based/FaceFields/Pressure</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/conn_based/FaceFields/Pressure, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/pos_based/FaceFields/Pressure</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/pos_based/FaceFields/Pressure, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/conn_based/FaceFields/TwoDSSPPFS_1_GlobalDof</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/conn_based/FaceFields/TwoDSSPPFS_1_GlobalDof, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/pos_based/FaceFields/TwoDSSPPFS_1_GlobalDof</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/pos_based/FaceFields/TwoDSSPPFS_1_GlobalDof, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/conn_based/FaceFields/ZshiftFloor</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/conn_based/FaceFields/ZshiftFloor, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/pos_based/FaceFields/ZshiftFloor</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/pos_based/FaceFields/ZshiftFloor, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/conn_based/FaceFields/ZshiftRoof</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/conn_based/FaceFields/ZshiftRoof, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/pos_based/FaceFields/ZshiftRoof</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/pos_based/FaceFields/ZshiftRoof, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/conn_based/FaceFields/externalFaceIndex</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/conn_based/FaceFields/externalFaceIndex, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/pos_based/FaceFields/externalFaceIndex</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/pos_based/FaceFields/externalFaceIndex, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/conn_based/FaceFields/isDomainBoundary</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/conn_based/FaceFields/isDomainBoundary, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/pos_based/FaceFields/isDomainBoundary</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/pos_based/FaceFields/isDomainBoundary, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/conn_based/FaceFields/isExternal</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/conn_based/FaceFields/isExternal, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/pos_based/FaceFields/isExternal</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/pos_based/FaceFields/isExternal, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/conn_based/FaceFields/isGhost</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/conn_based/FaceFields/isGhost, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/pos_based/FaceFields/isGhost</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/pos_based/FaceFields/isGhost, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/conn_based/FaceFields/ownership</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/conn_based/FaceFields/ownership, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/pos_based/FaceFields/ownership</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/pos_based/FaceFields/ownership, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/conn_based/FaceFields/ruptureState</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/conn_based/FaceFields/ruptureState, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/pos_based/FaceFields/ruptureState</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/pos_based/FaceFields/ruptureState, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/conn_based/FaceFields/verticalAperture</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/conn_based/FaceFields/verticalAperture, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/pos_based/FaceFields/verticalAperture</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/pos_based/FaceFields/verticalAperture, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/volume_mesh_time</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/volume_mesh_time, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/volume_mesh_lasttime</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/volume_mesh_lasttime, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/volume_mesh_time</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/volume_mesh_time, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/volume_mesh_lasttime</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/volume_mesh_lasttime, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/Fracture_Floor/Density</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/Fracture_Floor/Density, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/Fracture_Floor/Density</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/Fracture_Floor/Density, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/Fracture_Floor/GlobalNumbers</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/Fracture_Floor/GlobalNumbers, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/Fracture_Floor/GlobalNumbers</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/Fracture_Floor/GlobalNumbers, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/Fracture_Floor/Mass</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/Fracture_Floor/Mass, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/Fracture_Floor/Mass</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/Fracture_Floor/Mass, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/Fracture_Floor/Pressure</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/Fracture_Floor/Pressure, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/Fracture_Floor/Pressure</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/Fracture_Floor/Pressure, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/Fracture_Floor/Volume</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/Fracture_Floor/Volume, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/Fracture_Floor/Volume</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/Fracture_Floor/Volume, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/Fracture_Floor/isDomainBoundary</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/Fracture_Floor/isDomainBoundary, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/Fracture_Floor/isDomainBoundary</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/Fracture_Floor/isDomainBoundary, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/Fracture_Floor/isExternal</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/Fracture_Floor/isExternal, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/Fracture_Floor/isExternal</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/Fracture_Floor/isExternal, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/Fracture_Floor/isGhost</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/Fracture_Floor/isGhost, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/Fracture_Floor/isGhost</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/Fracture_Floor/isGhost, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/Fracture_Floor/ownership</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/Fracture_Floor/ownership, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/Fracture_Floor/ownership</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/Fracture_Floor/ownership, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/Fracture_Floor/sigma_x</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/Fracture_Floor/sigma_x, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/Fracture_Floor/sigma_x</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/Fracture_Floor/sigma_x, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/Fracture_Floor/sigma_y</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/Fracture_Floor/sigma_y, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/Fracture_Floor/sigma_y</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/Fracture_Floor/sigma_y, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/Fracture_Floor/sigma_z</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/Fracture_Floor/sigma_z, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/Fracture_Floor/sigma_z</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/Fracture_Floor/sigma_z, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/Fracture_Roof/Density</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/Fracture_Roof/Density, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/Fracture_Roof/Density</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/Fracture_Roof/Density, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/Fracture_Roof/GlobalNumbers</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/Fracture_Roof/GlobalNumbers, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/Fracture_Roof/GlobalNumbers</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/Fracture_Roof/GlobalNumbers, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/Fracture_Roof/Mass</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/Fracture_Roof/Mass, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/Fracture_Roof/Mass</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/Fracture_Roof/Mass, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/Fracture_Roof/Pressure</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/Fracture_Roof/Pressure, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/Fracture_Roof/Pressure</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/Fracture_Roof/Pressure, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/Fracture_Roof/Volume</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/Fracture_Roof/Volume, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/Fracture_Roof/Volume</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/Fracture_Roof/Volume, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/Fracture_Roof/isDomainBoundary</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/Fracture_Roof/isDomainBoundary, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/Fracture_Roof/isDomainBoundary</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/Fracture_Roof/isDomainBoundary, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/Fracture_Roof/isExternal</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/Fracture_Roof/isExternal, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/Fracture_Roof/isExternal</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/Fracture_Roof/isExternal, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/Fracture_Roof/isGhost</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/Fracture_Roof/isGhost, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/Fracture_Roof/isGhost</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/Fracture_Roof/isGhost, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/Fracture_Roof/ownership</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/Fracture_Roof/ownership, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/Fracture_Roof/ownership</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/Fracture_Roof/ownership, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/Fracture_Roof/sigma_x</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/Fracture_Roof/sigma_x, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/Fracture_Roof/sigma_x</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/Fracture_Roof/sigma_x, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/Fracture_Roof/sigma_y</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/Fracture_Roof/sigma_y, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/Fracture_Roof/sigma_y</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/Fracture_Roof/sigma_y, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/Fracture_Roof/sigma_z</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/Fracture_Roof/sigma_z, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/Fracture_Roof/sigma_z</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/Fracture_Roof/sigma_z, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/NodalFields/Floor</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/NodalFields/Floor, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/NodalFields/Floor</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/NodalFields/Floor, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/NodalFields/GlobalNumbers</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/NodalFields/GlobalNumbers, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/NodalFields/GlobalNumbers</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/NodalFields/GlobalNumbers, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/NodalFields/IMS_0_GlobalDof</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/NodalFields/IMS_0_GlobalDof, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/NodalFields/IMS_0_GlobalDof</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/NodalFields/IMS_0_GlobalDof, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/NodalFields/Mass</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/NodalFields/Mass, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/NodalFields/Mass</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/NodalFields/Mass, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/NodalFields/ZshiftFloor</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/NodalFields/ZshiftFloor, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/NodalFields/ZshiftFloor</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/NodalFields/ZshiftFloor, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/NodalFields/ZshiftRoof</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/NodalFields/ZshiftRoof, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/NodalFields/ZshiftRoof</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/NodalFields/ZshiftRoof, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/NodalFields/inContact</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/NodalFields/inContact, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/NodalFields/inContact</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/NodalFields/inContact, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/NodalFields/isDomainBoundary</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/NodalFields/isDomainBoundary, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/NodalFields/isDomainBoundary</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/NodalFields/isDomainBoundary, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/NodalFields/isExternal</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/NodalFields/isExternal, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/NodalFields/isExternal</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/NodalFields/isExternal, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/NodalFields/isGhost</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/NodalFields/isGhost, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/NodalFields/isGhost</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/NodalFields/isGhost, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/NodalFields/numberOfRupturedFaces</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/NodalFields/numberOfRupturedFaces, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/NodalFields/numberOfRupturedFaces</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/NodalFields/numberOfRupturedFaces, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/NodalFields/ownership</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/NodalFields/ownership, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/NodalFields/ownership</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/NodalFields/ownership, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/CommonPlaneFields/applicationPoint_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(CommonPlaneFields/applicationPoint_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/CommonPlaneFields/face1ParentSoln_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(CommonPlaneFields/face1ParentSoln_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/CommonPlaneFields/face2ParentSoln_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(CommonPlaneFields/face2ParentSoln_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/CommonPlaneFields/normal_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(CommonPlaneFields/normal_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/CommonPlaneFields/stressTangential_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(CommonPlaneFields/stressTangential_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/CommonPlaneFields/velocity_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(CommonPlaneFields/velocity_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/ExternalFaceFields/faceCenter_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(ExternalFaceFields/faceCenter_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/ExternalFaceFields/faceCenterLastSort_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(ExternalFaceFields/faceCenterLastSort_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/ExternalFaceFields/faceNormal_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(ExternalFaceFields/faceNormal_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/ExternalFaceFields/faceVelocity_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(ExternalFaceFields/faceVelocity_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/ExternalFaceFields/stressTangential_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(ExternalFaceFields/stressTangential_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/FaceFields/FaceCenter_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(FaceFields/FaceCenter_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/FaceFields/FluidVelocity_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(FaceFields/FluidVelocity_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/FaceFields/maxTraction_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(FaceFields/maxTraction_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/Fracture_Floor/DeviatorStress_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(Fracture_Floor/DeviatorStress_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/Fracture_Roof/DeviatorStress_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(Fracture_Roof/DeviatorStress_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/NodalFields/Acceleration_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(NodalFields/Acceleration_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/NodalFields/Displacement_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(NodalFields/Displacement_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/NodalFields/Force_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(NodalFields/Force_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/NodalFields/ReferencePosition_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(NodalFields/ReferencePosition_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/NodalFields/Velocity_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(NodalFields/Velocity_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/NodalFields/contactForce_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(NodalFields/contactForce_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/conn_based/CommonPlaneFields/applicationPoint_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/conn_based/CommonPlaneFields/applicationPoint_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/pos_based/CommonPlaneFields/applicationPoint_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/pos_based/CommonPlaneFields/applicationPoint_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/conn_based/CommonPlaneFields/face1ParentSoln_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/conn_based/CommonPlaneFields/face1ParentSoln_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/pos_based/CommonPlaneFields/face1ParentSoln_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/pos_based/CommonPlaneFields/face1ParentSoln_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/conn_based/CommonPlaneFields/face2ParentSoln_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/conn_based/CommonPlaneFields/face2ParentSoln_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/pos_based/CommonPlaneFields/face2ParentSoln_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/pos_based/CommonPlaneFields/face2ParentSoln_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/conn_based/CommonPlaneFields/normal_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/conn_based/CommonPlaneFields/normal_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/pos_based/CommonPlaneFields/normal_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/pos_based/CommonPlaneFields/normal_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/conn_based/CommonPlaneFields/stressTangential_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/conn_based/CommonPlaneFields/stressTangential_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/pos_based/CommonPlaneFields/stressTangential_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/pos_based/CommonPlaneFields/stressTangential_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/conn_based/CommonPlaneFields/velocity_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/conn_based/CommonPlaneFields/velocity_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/cp_mesh/pos_based/CommonPlaneFields/velocity_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/cp_mesh/pos_based/CommonPlaneFields/velocity_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/conn_based/ExternalFaceFields/faceCenter_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/conn_based/ExternalFaceFields/faceCenter_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/pos_based/ExternalFaceFields/faceCenter_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/pos_based/ExternalFaceFields/faceCenter_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/conn_based/ExternalFaceFields/faceCenterLastSort_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/conn_based/ExternalFaceFields/faceCenterLastSort_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/pos_based/ExternalFaceFields/faceCenterLastSort_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/pos_based/ExternalFaceFields/faceCenterLastSort_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/conn_based/ExternalFaceFields/faceNormal_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/conn_based/ExternalFaceFields/faceNormal_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/pos_based/ExternalFaceFields/faceNormal_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/pos_based/ExternalFaceFields/faceNormal_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/conn_based/ExternalFaceFields/faceVelocity_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/conn_based/ExternalFaceFields/faceVelocity_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/pos_based/ExternalFaceFields/faceVelocity_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/pos_based/ExternalFaceFields/faceVelocity_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/conn_based/ExternalFaceFields/stressTangential_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/conn_based/ExternalFaceFields/stressTangential_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/external_face_mesh/pos_based/ExternalFaceFields/stressTangential_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/external_face_mesh/pos_based/ExternalFaceFields/stressTangential_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/conn_based/FaceFields/FaceCenter_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/conn_based/FaceFields/FaceCenter_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/pos_based/FaceFields/FaceCenter_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/pos_based/FaceFields/FaceCenter_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/conn_based/FaceFields/FluidVelocity_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/conn_based/FaceFields/FluidVelocity_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/pos_based/FaceFields/FluidVelocity_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/pos_based/FaceFields/FluidVelocity_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/conn_based/FaceFields/maxTraction_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/conn_based/FaceFields/maxTraction_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/face_mesh/pos_based/FaceFields/maxTraction_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/face_mesh/pos_based/FaceFields/maxTraction_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/Fracture_Floor/DeviatorStress_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/Fracture_Floor/DeviatorStress_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/Fracture_Floor/DeviatorStress_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/Fracture_Floor/DeviatorStress_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/Fracture_Roof/DeviatorStress_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/Fracture_Roof/DeviatorStress_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/Fracture_Roof/DeviatorStress_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/Fracture_Roof/DeviatorStress_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/NodalFields/Acceleration_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/NodalFields/Acceleration_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/NodalFields/Acceleration_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/NodalFields/Acceleration_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/NodalFields/Displacement_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/NodalFields/Displacement_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/NodalFields/Displacement_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/NodalFields/Displacement_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/NodalFields/Force_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/NodalFields/Force_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/NodalFields/Force_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/NodalFields/Force_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/NodalFields/ReferencePosition_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/NodalFields/ReferencePosition_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/NodalFields/ReferencePosition_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/NodalFields/ReferencePosition_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/NodalFields/Velocity_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/NodalFields/Velocity_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/NodalFields/Velocity_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/NodalFields/Velocity_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/conn_based/NodalFields/contactForce_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/conn_based/NodalFields/contactForce_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/Lineout/time_derivative/volume_mesh/pos_based/NodalFields/contactForce_magnitude</Field>
                    <Field name="definition" type="string">"cell_constant(time_derivative/volume_mesh/pos_based/NodalFields/contactForce_magnitude, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">CurveMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">Lineout</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/SurfaceNormal/cp_mesh</Field>
                    <Field name="definition" type="string">"cell_constant(cp_mesh, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">VectorMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">SurfaceNormal</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/SurfaceNormal/edge_mesh</Field>
                    <Field name="definition" type="string">"cell_constant(edge_mesh, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">VectorMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">SurfaceNormal</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/SurfaceNormal/external_face_mesh</Field>
                    <Field name="definition" type="string">"cell_constant(external_face_mesh, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">VectorMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">SurfaceNormal</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/SurfaceNormal/face_mesh</Field>
                    <Field name="definition" type="string">"cell_constant(face_mesh, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">VectorMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">SurfaceNormal</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
                <Object name="Expression">
                    <Field name="name" type="string">operators/SurfaceNormal/volume_mesh</Field>
                    <Field name="definition" type="string">"cell_constant(volume_mesh, 0.)"</Field>
                    <Field name="hidden" type="bool">false</Field>
                    <Field name="type" type="string">VectorMeshVar</Field>
                    <Field name="fromDB" type="bool">false</Field>
                    <Field name="fromOperator" type="bool">true</Field>
                    <Field name="operatorName" type="string">SurfaceNormal</Field>
                    <Field name="meshName" type="string"></Field>
                    <Field name="dbName" type="string">__none__</Field>
                    <Field name="autoExpression" type="bool">false</Field>
                </Object>
            </Object>
            <Object name="AnimationAttributes">
                <Field name="animationMode" type="string">StopMode</Field>
                <Field name="pipelineCachingMode" type="bool">false</Field>
                <Field name="frameIncrement" type="int">1</Field>
                <Field name="timeout" type="int">1</Field>
                <Field name="playbackMode" type="string">Looping</Field>
            </Object>
            <Object name="AnnotationAttributes">
                <Object name="axes2D">
                    <Object name="Axes2D">
                        <Field name="visible" type="bool">true</Field>
                        <Field name="autoSetTicks" type="bool">true</Field>
                        <Field name="autoSetScaling" type="bool">true</Field>
                        <Field name="lineWidth" type="int">0</Field>
                        <Field name="tickLocation" type="string">Outside</Field>
                        <Field name="tickAxes" type="string">BottomLeft</Field>
                        <Object name="xAxis">
                            <Object name="AxisAttributes">
                                <Object name="title">
                                    <Object name="AxisTitles">
                                        <Field name="visible" type="bool">true</Field>
                                        <Object name="font">
                                            <Object name="FontAttributes">
                                                <Field name="font" type="string">Courier</Field>
                                                <Field name="scale" type="double">1</Field>
                                                <Field name="useForegroundColor" type="bool">true</Field>
                                                <Object name="color">
                                                    <Object name="ColorAttribute">
                                                        <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                                                    </Object>
                                                </Object>
                                                <Field name="bold" type="bool">true</Field>
                                                <Field name="italic" type="bool">true</Field>
                                            </Object>
                                        </Object>
                                        <Field name="userTitle" type="bool">false</Field>
                                        <Field name="userUnits" type="bool">false</Field>
                                        <Field name="title" type="string">X-Axis</Field>
                                        <Field name="units" type="string"></Field>
                                    </Object>
                                </Object>
                                <Object name="label">
                                    <Object name="AxisLabels">
                                        <Field name="visible" type="bool">true</Field>
                                        <Object name="font">
                                            <Object name="FontAttributes">
                                                <Field name="font" type="string">Courier</Field>
                                                <Field name="scale" type="double">1</Field>
                                                <Field name="useForegroundColor" type="bool">true</Field>
                                                <Object name="color">
                                                    <Object name="ColorAttribute">
                                                        <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                                                    </Object>
                                                </Object>
                                                <Field name="bold" type="bool">true</Field>
                                                <Field name="italic" type="bool">true</Field>
                                            </Object>
                                        </Object>
                                        <Field name="scaling" type="int">0</Field>
                                    </Object>
                                </Object>
                                <Object name="tickMarks">
                                    <Object name="AxisTickMarks">
                                        <Field name="visible" type="bool">true</Field>
                                        <Field name="majorMinimum" type="double">0</Field>
                                        <Field name="majorMaximum" type="double">1</Field>
                                        <Field name="minorSpacing" type="double">0.02</Field>
                                        <Field name="majorSpacing" type="double">0.2</Field>
                                    </Object>
                                </Object>
                                <Field name="grid" type="bool">false</Field>
                            </Object>
                        </Object>
                        <Object name="yAxis">
                            <Object name="AxisAttributes">
                                <Object name="title">
                                    <Object name="AxisTitles">
                                        <Field name="visible" type="bool">true</Field>
                                        <Object name="font">
                                            <Object name="FontAttributes">
                                                <Field name="font" type="string">Courier</Field>
                                                <Field name="scale" type="double">1</Field>
                                                <Field name="useForegroundColor" type="bool">true</Field>
                                                <Object name="color">
                                                    <Object name="ColorAttribute">
                                                        <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                                                    </Object>
                                                </Object>
                                                <Field name="bold" type="bool">true</Field>
                                                <Field name="italic" type="bool">true</Field>
                                            </Object>
                                        </Object>
                                        <Field name="userTitle" type="bool">false</Field>
                                        <Field name="userUnits" type="bool">false</Field>
                                        <Field name="title" type="string">Y-Axis</Field>
                                        <Field name="units" type="string"></Field>
                                    </Object>
                                </Object>
                                <Object name="label">
                                    <Object name="AxisLabels">
                                        <Field name="visible" type="bool">true</Field>
                                        <Object name="font">
                                            <Object name="FontAttributes">
                                                <Field name="font" type="string">Courier</Field>
                                                <Field name="scale" type="double">1</Field>
                                                <Field name="useForegroundColor" type="bool">true</Field>
                                                <Object name="color">
                                                    <Object name="ColorAttribute">
                                                        <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                                                    </Object>
                                                </Object>
                                                <Field name="bold" type="bool">true</Field>
                                                <Field name="italic" type="bool">true</Field>
                                            </Object>
                                        </Object>
                                        <Field name="scaling" type="int">0</Field>
                                    </Object>
                                </Object>
                                <Object name="tickMarks">
                                    <Object name="AxisTickMarks">
                                        <Field name="visible" type="bool">true</Field>
                                        <Field name="majorMinimum" type="double">0</Field>
                                        <Field name="majorMaximum" type="double">1</Field>
                                        <Field name="minorSpacing" type="double">0.02</Field>
                                        <Field name="majorSpacing" type="double">0.2</Field>
                                    </Object>
                                </Object>
                                <Field name="grid" type="bool">false</Field>
                            </Object>
                        </Object>
                    </Object>
                </Object>
                <Object name="axes3D">
                    <Object name="Axes3D">
                        <Field name="visible" type="bool">true</Field>
                        <Field name="autoSetTicks" type="bool">true</Field>
                        <Field name="autoSetScaling" type="bool">true</Field>
                        <Field name="lineWidth" type="int">0</Field>
                        <Field name="tickLocation" type="string">Inside</Field>
                        <Field name="axesType" type="string">ClosestTriad</Field>
                        <Field name="triadFlag" type="bool">true</Field>
                        <Field name="bboxFlag" type="bool">true</Field>
                        <Object name="xAxis">
                            <Object name="AxisAttributes">
                                <Object name="title">
                                    <Object name="AxisTitles">
                                        <Field name="visible" type="bool">true</Field>
                                        <Object name="font">
                                            <Object name="FontAttributes">
                                                <Field name="font" type="string">Arial</Field>
                                                <Field name="scale" type="double">1</Field>
                                                <Field name="useForegroundColor" type="bool">true</Field>
                                                <Object name="color">
                                                    <Object name="ColorAttribute">
                                                        <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                                                    </Object>
                                                </Object>
                                                <Field name="bold" type="bool">false</Field>
                                                <Field name="italic" type="bool">false</Field>
                                            </Object>
                                        </Object>
                                        <Field name="userTitle" type="bool">false</Field>
                                        <Field name="userUnits" type="bool">false</Field>
                                        <Field name="title" type="string">X-Axis</Field>
                                        <Field name="units" type="string"></Field>
                                    </Object>
                                </Object>
                                <Object name="label">
                                    <Object name="AxisLabels">
                                        <Field name="visible" type="bool">true</Field>
                                        <Object name="font">
                                            <Object name="FontAttributes">
                                                <Field name="font" type="string">Arial</Field>
                                                <Field name="scale" type="double">1</Field>
                                                <Field name="useForegroundColor" type="bool">true</Field>
                                                <Object name="color">
                                                    <Object name="ColorAttribute">
                                                        <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                                                    </Object>
                                                </Object>
                                                <Field name="bold" type="bool">false</Field>
                                                <Field name="italic" type="bool">false</Field>
                                            </Object>
                                        </Object>
                                        <Field name="scaling" type="int">0</Field>
                                    </Object>
                                </Object>
                                <Object name="tickMarks">
                                    <Object name="AxisTickMarks">
                                        <Field name="visible" type="bool">true</Field>
                                        <Field name="majorMinimum" type="double">0</Field>
                                        <Field name="majorMaximum" type="double">1</Field>
                                        <Field name="minorSpacing" type="double">0.02</Field>
                                        <Field name="majorSpacing" type="double">0.2</Field>
                                    </Object>
                                </Object>
                                <Field name="grid" type="bool">false</Field>
                            </Object>
                        </Object>
                        <Object name="yAxis">
                            <Object name="AxisAttributes">
                                <Object name="title">
                                    <Object name="AxisTitles">
                                        <Field name="visible" type="bool">true</Field>
                                        <Object name="font">
                                            <Object name="FontAttributes">
                                                <Field name="font" type="string">Arial</Field>
                                                <Field name="scale" type="double">1</Field>
                                                <Field name="useForegroundColor" type="bool">true</Field>
                                                <Object name="color">
                                                    <Object name="ColorAttribute">
                                                        <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                                                    </Object>
                                                </Object>
                                                <Field name="bold" type="bool">false</Field>
                                                <Field name="italic" type="bool">false</Field>
                                            </Object>
                                        </Object>
                                        <Field name="userTitle" type="bool">false</Field>
                                        <Field name="userUnits" type="bool">false</Field>
                                        <Field name="title" type="string">Y-Axis</Field>
                                        <Field name="units" type="string"></Field>
                                    </Object>
                                </Object>
                                <Object name="label">
                                    <Object name="AxisLabels">
                                        <Field name="visible" type="bool">true</Field>
                                        <Object name="font">
                                            <Object name="FontAttributes">
                                                <Field name="font" type="string">Arial</Field>
                                                <Field name="scale" type="double">1</Field>
                                                <Field name="useForegroundColor" type="bool">true</Field>
                                                <Object name="color">
                                                    <Object name="ColorAttribute">
                                                        <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                                                    </Object>
                                                </Object>
                                                <Field name="bold" type="bool">false</Field>
                                                <Field name="italic" type="bool">false</Field>
                                            </Object>
                                        </Object>
                                        <Field name="scaling" type="int">0</Field>
                                    </Object>
                                </Object>
                                <Object name="tickMarks">
                                    <Object name="AxisTickMarks">
                                        <Field name="visible" type="bool">true</Field>
                                        <Field name="majorMinimum" type="double">0</Field>
                                        <Field name="majorMaximum" type="double">1</Field>
                                        <Field name="minorSpacing" type="double">0.02</Field>
                                        <Field name="majorSpacing" type="double">0.2</Field>
                                    </Object>
                                </Object>
                                <Field name="grid" type="bool">false</Field>
                            </Object>
                        </Object>
                        <Object name="zAxis">
                            <Object name="AxisAttributes">
                                <Object name="title">
                                    <Object name="AxisTitles">
                                        <Field name="visible" type="bool">true</Field>
                                        <Object name="font">
                                            <Object name="FontAttributes">
                                                <Field name="font" type="string">Arial</Field>
                                                <Field name="scale" type="double">1</Field>
                                                <Field name="useForegroundColor" type="bool">true</Field>
                                                <Object name="color">
                                                    <Object name="ColorAttribute">
                                                        <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                                                    </Object>
                                                </Object>
                                                <Field name="bold" type="bool">false</Field>
                                                <Field name="italic" type="bool">false</Field>
                                            </Object>
                                        </Object>
                                        <Field name="userTitle" type="bool">false</Field>
                                        <Field name="userUnits" type="bool">false</Field>
                                        <Field name="title" type="string">Z-Axis</Field>
                                        <Field name="units" type="string"></Field>
                                    </Object>
                                </Object>
                                <Object name="label">
                                    <Object name="AxisLabels">
                                        <Field name="visible" type="bool">true</Field>
                                        <Object name="font">
                                            <Object name="FontAttributes">
                                                <Field name="font" type="string">Arial</Field>
                                                <Field name="scale" type="double">1</Field>
                                                <Field name="useForegroundColor" type="bool">true</Field>
                                                <Object name="color">
                                                    <Object name="ColorAttribute">
                                                        <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                                                    </Object>
                                                </Object>
                                                <Field name="bold" type="bool">false</Field>
                                                <Field name="italic" type="bool">false</Field>
                                            </Object>
                                        </Object>
                                        <Field name="scaling" type="int">0</Field>
                                    </Object>
                                </Object>
                                <Object name="tickMarks">
                                    <Object name="AxisTickMarks">
                                        <Field name="visible" type="bool">true</Field>
                                        <Field name="majorMinimum" type="double">0</Field>
                                        <Field name="majorMaximum" type="double">1</Field>
                                        <Field name="minorSpacing" type="double">0.02</Field>
                                        <Field name="majorSpacing" type="double">0.2</Field>
                                    </Object>
                                </Object>
                                <Field name="grid" type="bool">false</Field>
                            </Object>
                        </Object>
                        <Field name="setBBoxLocation" type="bool">false</Field>
                        <Field name="bboxLocation" type="doubleArray" length="6">0 1 0 1 0 1 </Field>
                    </Object>
                </Object>
                <Field name="userInfoFlag" type="bool">true</Field>
                <Object name="userInfoFont">
                    <Object name="FontAttributes">
                        <Field name="font" type="string">Arial</Field>
                        <Field name="scale" type="double">1</Field>
                        <Field name="useForegroundColor" type="bool">true</Field>
                        <Object name="color">
                            <Object name="ColorAttribute">
                                <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                            </Object>
                        </Object>
                        <Field name="bold" type="bool">false</Field>
                        <Field name="italic" type="bool">false</Field>
                    </Object>
                </Object>
                <Field name="databaseInfoFlag" type="bool">true</Field>
                <Field name="timeInfoFlag" type="bool">true</Field>
                <Object name="databaseInfoFont">
                    <Object name="FontAttributes">
                        <Field name="font" type="string">Arial</Field>
                        <Field name="scale" type="double">1</Field>
                        <Field name="useForegroundColor" type="bool">true</Field>
                        <Object name="color">
                            <Object name="ColorAttribute">
                                <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                            </Object>
                        </Object>
                        <Field name="bold" type="bool">false</Field>
                        <Field name="italic" type="bool">false</Field>
                    </Object>
                </Object>
                <Field name="databaseInfoExpansionMode" type="string">File</Field>
                <Field name="databaseInfoTimeScale" type="double">1</Field>
                <Field name="databaseInfoTimeOffset" type="double">0</Field>
                <Field name="legendInfoFlag" type="bool">true</Field>
                <Object name="backgroundColor">
                    <Object name="ColorAttribute">
                        <Field name="color" type="unsignedCharArray" length="4">255 255 255 255 </Field>
                    </Object>
                </Object>
                <Object name="foregroundColor">
                    <Object name="ColorAttribute">
                        <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                    </Object>
                </Object>
                <Field name="gradientBackgroundStyle" type="string">Radial</Field>
                <Object name="gradientColor1">
                    <Object name="ColorAttribute">
                        <Field name="color" type="unsignedCharArray" length="4">0 0 255 255 </Field>
                    </Object>
                </Object>
                <Object name="gradientColor2">
                    <Object name="ColorAttribute">
                        <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                    </Object>
                </Object>
                <Field name="backgroundMode" type="string">Solid</Field>
                <Field name="backgroundImage" type="string"></Field>
                <Field name="imageRepeatX" type="int">1</Field>
                <Field name="imageRepeatY" type="int">1</Field>
                <Object name="axesArray">
                    <Object name="AxesArray">
                        <Field name="visible" type="bool">true</Field>
                        <Field name="ticksVisible" type="bool">true</Field>
                        <Field name="autoSetTicks" type="bool">true</Field>
                        <Field name="autoSetScaling" type="bool">true</Field>
                        <Field name="lineWidth" type="int">0</Field>
                        <Object name="axes">
                            <Object name="AxisAttributes">
                                <Object name="title">
                                    <Object name="AxisTitles">
                                        <Field name="visible" type="bool">true</Field>
                                        <Object name="font">
                                            <Object name="FontAttributes">
                                                <Field name="font" type="string">Arial</Field>
                                                <Field name="scale" type="double">1</Field>
                                                <Field name="useForegroundColor" type="bool">true</Field>
                                                <Object name="color">
                                                    <Object name="ColorAttribute">
                                                        <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                                                    </Object>
                                                </Object>
                                                <Field name="bold" type="bool">false</Field>
                                                <Field name="italic" type="bool">false</Field>
                                            </Object>
                                        </Object>
                                        <Field name="userTitle" type="bool">false</Field>
                                        <Field name="userUnits" type="bool">false</Field>
                                        <Field name="title" type="string"></Field>
                                        <Field name="units" type="string"></Field>
                                    </Object>
                                </Object>
                                <Object name="label">
                                    <Object name="AxisLabels">
                                        <Field name="visible" type="bool">true</Field>
                                        <Object name="font">
                                            <Object name="FontAttributes">
                                                <Field name="font" type="string">Arial</Field>
                                                <Field name="scale" type="double">1</Field>
                                                <Field name="useForegroundColor" type="bool">true</Field>
                                                <Object name="color">
                                                    <Object name="ColorAttribute">
                                                        <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                                                    </Object>
                                                </Object>
                                                <Field name="bold" type="bool">false</Field>
                                                <Field name="italic" type="bool">false</Field>
                                            </Object>
                                        </Object>
                                        <Field name="scaling" type="int">0</Field>
                                    </Object>
                                </Object>
                                <Object name="tickMarks">
                                    <Object name="AxisTickMarks">
                                        <Field name="visible" type="bool">true</Field>
                                        <Field name="majorMinimum" type="double">0</Field>
                                        <Field name="majorMaximum" type="double">1</Field>
                                        <Field name="minorSpacing" type="double">0.02</Field>
                                        <Field name="majorSpacing" type="double">0.2</Field>
                                    </Object>
                                </Object>
                                <Field name="grid" type="bool">false</Field>
                            </Object>
                        </Object>
                    </Object>
                </Object>
            </Object>
            <Object name="ViewCurveAttributes">
                <Field name="domainCoords" type="doubleArray" length="2">0 1 </Field>
                <Field name="rangeCoords" type="doubleArray" length="2">0 1 </Field>
                <Field name="viewportCoords" type="doubleArray" length="4">0.2 0.95 0.15 0.95 </Field>
                <Field name="domainScale" type="int">0</Field>
                <Field name="rangeScale" type="int">0</Field>
            </Object>
            <Object name="View2DAttributes">
                <Field name="windowCoords" type="doubleArray" length="4">0 1 0 1 </Field>
                <Field name="viewportCoords" type="doubleArray" length="4">0.2 0.95 0.15 0.95 </Field>
                <Field name="fullFrameActivationMode" type="string">Auto</Field>
                <Field name="fullFrameAutoThreshold" type="double">100</Field>
                <Field name="xScale" type="int">0</Field>
                <Field name="yScale" type="int">0</Field>
                <Field name="windowValid" type="bool">false</Field>
            </Object>
            <Object name="View3DAttributes">
                <Field name="viewNormal" type="doubleArray" length="3">0 0 1 </Field>
                <Field name="focus" type="doubleArray" length="3">14.8 7.1 0 </Field>
                <Field name="viewUp" type="doubleArray" length="3">0 1 0 </Field>
                <Field name="viewAngle" type="double">30</Field>
                <Field name="parallelScale" type="double">16.5363</Field>
                <Field name="nearPlane" type="double">-33.0726</Field>
                <Field name="farPlane" type="double">33.0726</Field>
                <Field name="imagePan" type="doubleArray" length="2">0 0 </Field>
                <Field name="imageZoom" type="double">1</Field>
                <Field name="perspective" type="bool">true</Field>
                <Field name="eyeAngle" type="double">2</Field>
                <Field name="centerOfRotationSet" type="bool">false</Field>
                <Field name="centerOfRotation" type="doubleArray" length="3">14.8 7.1 0 </Field>
                <Field name="axis3DScaleFlag" type="bool">false</Field>
                <Field name="axis3DScales" type="doubleArray" length="3">1 1 1 </Field>
                <Field name="shear" type="doubleArray" length="3">0 0 1 </Field>
            </Object>
            <Object name="LightList">
                <Object name="light0">
                    <Object name="LightAttributes">
                        <Field name="enabledFlagCanBeToggled" type="bool">false</Field>
                        <Field name="enabledFlag" type="bool">true</Field>
                        <Field name="type" type="string">Camera</Field>
                        <Field name="direction" type="doubleArray" length="3">0 0 -1 </Field>
                        <Object name="color">
                            <Object name="ColorAttribute">
                                <Field name="color" type="unsignedCharArray" length="4">255 255 255 255 </Field>
                            </Object>
                        </Object>
                        <Field name="brightness" type="double">1</Field>
                    </Object>
                </Object>
                <Object name="light1">
                    <Object name="LightAttributes">
                        <Field name="enabledFlagCanBeToggled" type="bool">true</Field>
                        <Field name="enabledFlag" type="bool">false</Field>
                        <Field name="type" type="string">Camera</Field>
                        <Field name="direction" type="doubleArray" length="3">0 0 -1 </Field>
                        <Object name="color">
                            <Object name="ColorAttribute">
                                <Field name="color" type="unsignedCharArray" length="4">255 255 255 255 </Field>
                            </Object>
                        </Object>
                        <Field name="brightness" type="double">1</Field>
                    </Object>
                </Object>
                <Object name="light2">
                    <Object name="LightAttributes">
                        <Field name="enabledFlagCanBeToggled" type="bool">true</Field>
                        <Field name="enabledFlag" type="bool">false</Field>
                        <Field name="type" type="string">Camera</Field>
                        <Field name="direction" type="doubleArray" length="3">0 0 -1 </Field>
                        <Object name="color">
                            <Object name="ColorAttribute">
                                <Field name="color" type="unsignedCharArray" length="4">255 255 255 255 </Field>
                            </Object>
                        </Object>
                        <Field name="brightness" type="double">1</Field>
                    </Object>
                </Object>
                <Object name="light3">
                    <Object name="LightAttributes">
                        <Field name="enabledFlagCanBeToggled" type="bool">true</Field>
                        <Field name="enabledFlag" type="bool">false</Field>
                        <Field name="type" type="string">Camera</Field>
                        <Field name="direction" type="doubleArray" length="3">0 0 -1 </Field>
                        <Object name="color">
                            <Object name="ColorAttribute">
                                <Field name="color" type="unsignedCharArray" length="4">255 255 255 255 </Field>
                            </Object>
                        </Object>
                        <Field name="brightness" type="double">1</Field>
                    </Object>
                </Object>
                <Object name="light4">
                    <Object name="LightAttributes">
                        <Field name="enabledFlagCanBeToggled" type="bool">true</Field>
                        <Field name="enabledFlag" type="bool">false</Field>
                        <Field name="type" type="string">Camera</Field>
                        <Field name="direction" type="doubleArray" length="3">0 0 -1 </Field>
                        <Object name="color">
                            <Object name="ColorAttribute">
                                <Field name="color" type="unsignedCharArray" length="4">255 255 255 255 </Field>
                            </Object>
                        </Object>
                        <Field name="brightness" type="double">1</Field>
                    </Object>
                </Object>
                <Object name="light5">
                    <Object name="LightAttributes">
                        <Field name="enabledFlagCanBeToggled" type="bool">true</Field>
                        <Field name="enabledFlag" type="bool">false</Field>
                        <Field name="type" type="string">Camera</Field>
                        <Field name="direction" type="doubleArray" length="3">0 0 -1 </Field>
                        <Object name="color">
                            <Object name="ColorAttribute">
                                <Field name="color" type="unsignedCharArray" length="4">255 255 255 255 </Field>
                            </Object>
                        </Object>
                        <Field name="brightness" type="double">1</Field>
                    </Object>
                </Object>
                <Object name="light6">
                    <Object name="LightAttributes">
                        <Field name="enabledFlagCanBeToggled" type="bool">true</Field>
                        <Field name="enabledFlag" type="bool">false</Field>
                        <Field name="type" type="string">Camera</Field>
                        <Field name="direction" type="doubleArray" length="3">0 0 -1 </Field>
                        <Object name="color">
                            <Object name="ColorAttribute">
                                <Field name="color" type="unsignedCharArray" length="4">255 255 255 255 </Field>
                            </Object>
                        </Object>
                        <Field name="brightness" type="double">1</Field>
                    </Object>
                </Object>
                <Object name="light7">
                    <Object name="LightAttributes">
                        <Field name="enabledFlagCanBeToggled" type="bool">true</Field>
                        <Field name="enabledFlag" type="bool">false</Field>
                        <Field name="type" type="string">Camera</Field>
                        <Field name="direction" type="doubleArray" length="3">0 0 -1 </Field>
                        <Object name="color">
                            <Object name="ColorAttribute">
                                <Field name="color" type="unsignedCharArray" length="4">255 255 255 255 </Field>
                            </Object>
                        </Object>
                        <Field name="brightness" type="double">1</Field>
                    </Object>
                </Object>
            </Object>
            <Object name="ViewerWindowManagerAttributes">
                <Object name="ActionConfigurations">
                    <Object name="ActionGroupDescription">
                        <Field name="name" type="string">Mode</Field>
                        <Field name="actions" type="stringVector"></Field>
                        <Field name="visible" type="bool">true</Field>
                    </Object>
                    <Object name="ActionGroupDescription">
                        <Field name="name" type="string">Tools</Field>
                        <Field name="actions" type="stringVector"></Field>
                        <Field name="visible" type="bool">true</Field>
                    </Object>
                    <Object name="ActionGroupDescription">
                        <Field name="name" type="string">Window</Field>
                        <Field name="actions" type="stringVector">"SetActiveWindowRPC" "AddWindowRPC" "CloneWindowRPC" "DeleteWindowRPC" "SetWindowLayoutRPC" "ToggleSpinModeRPC" "InvertBackgroundRPC" </Field>
                        <Field name="visible" type="bool">true</Field>
                    </Object>
                    <Object name="ActionGroupDescription">
                        <Field name="name" type="string">View</Field>
                        <Field name="actions" type="stringVector">"TogglePerspectiveViewRPC" "ResetViewRPC" "RecenterViewRPC" "UndoViewRPC" "RedoViewRPC" "ToggleFullFrameRPC" "SaveViewRPC" "ChooseCenterOfRotationRPC" </Field>
                        <Field name="visible" type="bool">true</Field>
                    </Object>
                    <Object name="ActionGroupDescription">
                        <Field name="name" type="string">Animation</Field>
                        <Field name="actions" type="stringVector">"TimeSliderPreviousStateRPC" "AnimationReversePlayRPC" "AnimationStopRPC" "AnimationPlayRPC" "TimeSliderNextStateRPC" </Field>
                        <Field name="visible" type="bool">true</Field>
                    </Object>
                    <Object name="ActionGroupDescription">
                        <Field name="name" type="string">Operators</Field>
                        <Field name="actions" type="stringVector">"AddOperatorRPC" "RemoveLastOperatorRPC" "RemoveAllOperatorsRPC" </Field>
                        <Field name="visible" type="bool">false</Field>
                    </Object>
                    <Object name="ActionGroupDescription">
                        <Field name="name" type="string">Plots</Field>
                        <Field name="actions" type="stringVector">"AddPlotRPC" "DrawPlotsRPC" "HideActivePlotsRPC" "DeleteActivePlotsRPC" "CopyActivePlotsRPC" "SetPlotFollowsTimeRPC" </Field>
                        <Field name="visible" type="bool">false</Field>
                    </Object>
                    <Object name="ActionGroupDescription">
                        <Field name="name" type="string">Clear</Field>
                        <Field name="actions" type="stringVector">"ClearWindowRPC" "ClearAllWindowsRPC" "ClearPickPointsRPC" "ClearRefLinesRPC" </Field>
                        <Field name="visible" type="bool">true</Field>
                    </Object>
                    <Object name="ActionGroupDescription">
                        <Field name="name" type="string">Lock</Field>
                        <Field name="actions" type="stringVector">"ToggleLockViewModeRPC" "ToggleLockTimeRPC" "ToggleLockToolsRPC" "TurnOffAllLocksRPC" </Field>
                        <Field name="visible" type="bool">true</Field>
                    </Object>
                </Object>
                <Field name="toolbarsVisible" type="bool">true</Field>
                <Field name="largeIcons" type="bool">false</Field>
            </Object>
            <Object name="WindowInformation">
                <Field name="boundingBoxNavigate" type="bool">true</Field>
                <Field name="fullFrame" type="bool">false</Field>
                <Field name="perspective" type="bool">true</Field>
                <Field name="lockView" type="bool">false</Field>
                <Field name="lockTools" type="bool">false</Field>
                <Field name="lockTime" type="bool">false</Field>
                <Field name="viewExtentsType" type="int">0</Field>
            </Object>
            <Object name="PrinterAttributes">
                <Field name="printerName" type="string"></Field>
                <Field name="printProgram" type="string">lpr</Field>
                <Field name="documentName" type="string">untitled</Field>
                <Field name="creator" type="string"></Field>
                <Field name="numCopies" type="int">1</Field>
                <Field name="portrait" type="bool">true</Field>
                <Field name="printColor" type="bool">true</Field>
                <Field name="outputToFile" type="bool">false</Field>
                <Field name="outputToFileName" type="string">untitled</Field>
                <Field name="pageSize" type="int">2</Field>
            </Object>
            <Object name="RenderingAttributes">
                <Field name="antialiasing" type="bool">false</Field>
                <Field name="multiresolutionMode" type="bool">false</Field>
                <Field name="multiresolutionCellSize" type="float">0.002</Field>
                <Field name="geometryRepresentation" type="string">Surfaces</Field>
                <Field name="displayListMode" type="string">Auto</Field>
                <Field name="stereoRendering" type="bool">false</Field>
                <Field name="stereoType" type="string">CrystalEyes</Field>
                <Field name="notifyForEachRender" type="bool">false</Field>
                <Field name="scalableActivationMode" type="string">Auto</Field>
                <Field name="scalableAutoThreshold" type="int">2000000</Field>
                <Field name="specularFlag" type="bool">false</Field>
                <Field name="specularCoeff" type="float">0.6</Field>
                <Field name="specularPower" type="float">10</Field>
                <Object name="specularColor">
                    <Object name="ColorAttribute">
                        <Field name="color" type="unsignedCharArray" length="4">255 255 255 255 </Field>
                    </Object>
                </Object>
                <Field name="doShadowing" type="bool">false</Field>
                <Field name="shadowStrength" type="double">0.5</Field>
                <Field name="doDepthCueing" type="bool">false</Field>
                <Field name="depthCueingAutomatic" type="bool">true</Field>
                <Field name="startCuePoint" type="doubleArray" length="3">-10 0 0 </Field>
                <Field name="endCuePoint" type="doubleArray" length="3">10 0 0 </Field>
                <Field name="compressionActivationMode" type="string">Never</Field>
                <Field name="colorTexturingFlag" type="bool">true</Field>
                <Field name="compactDomainsActivationMode" type="string">Never</Field>
                <Field name="compactDomainsAutoThreshold" type="int">256</Field>
            </Object>
            <Object name="MaterialAttributes">
                <Field name="smoothing" type="bool">false</Field>
                <Field name="forceMIR" type="bool">false</Field>
                <Field name="cleanZonesOnly" type="bool">false</Field>
                <Field name="needValidConnectivity" type="bool">false</Field>
                <Field name="algorithm" type="string">EquiZ</Field>
                <Field name="iterationEnabled" type="bool">false</Field>
                <Field name="numIterations" type="int">5</Field>
                <Field name="iterationDamping" type="float">0.4</Field>
                <Field name="simplifyHeavilyMixedZones" type="bool">false</Field>
                <Field name="maxMaterialsPerZone" type="int">3</Field>
                <Field name="isoVolumeFraction" type="float">0.5</Field>
                <Field name="annealingTime" type="int">10</Field>
            </Object>
            <Object name="MeshManagementAttributes">
                <Field name="discretizationTolerance" type="doubleVector">0.02 0.025 0.05 </Field>
                <Field name="discretizationToleranceX" type="doubleVector"></Field>
                <Field name="discretizationToleranceY" type="doubleVector"></Field>
                <Field name="discretizationToleranceZ" type="doubleVector"></Field>
                <Field name="discretizationMode" type="string">Uniform</Field>
                <Field name="discretizeBoundaryOnly" type="bool">false</Field>
                <Field name="passNativeCSG" type="bool">false</Field>
            </Object>
            <Object name="AnnotationObjectList">
            </Object>
            <Object name="PickAttributes">
                <Field name="variables" type="stringVector">"default" </Field>
                <Field name="displayIncidentElements" type="bool">true</Field>
                <Field name="showNodeId" type="bool">true</Field>
                <Field name="showNodeDomainLogicalCoords" type="bool">false</Field>
                <Field name="showNodeBlockLogicalCoords" type="bool">false</Field>
                <Field name="showNodePhysicalCoords" type="bool">false</Field>
                <Field name="showZoneId" type="bool">true</Field>
                <Field name="showZoneDomainLogicalCoords" type="bool">false</Field>
                <Field name="showZoneBlockLogicalCoords" type="bool">false</Field>
                <Field name="doTimeCurve" type="bool">false</Field>
                <Field name="conciseOutput" type="bool">false</Field>
                <Field name="showTimeStep" type="bool">true</Field>
                <Field name="showMeshName" type="bool">true</Field>
                <Field name="displayGlobalIds" type="bool">false</Field>
                <Field name="displayPickLetter" type="bool">true</Field>
                <Field name="createSpreadsheet" type="bool">false</Field>
                <Field name="floatFormat" type="string">%g</Field>
                <Field name="timePreserveCoord" type="bool">true</Field>
            </Object>
            <Object name="QueryOverTimeAttributes">
                <Field name="timeType" type="string">Cycle</Field>
                <Field name="startTimeFlag" type="bool">false</Field>
                <Field name="startTime" type="int">0</Field>
                <Field name="endTimeFlag" type="bool">false</Field>
                <Field name="endTime" type="int">1</Field>
                <Field name="stride" type="int">1</Field>
                <Field name="createWindow" type="bool">true</Field>
                <Field name="windowId" type="int">2</Field>
            </Object>
            <Object name="InteractorAttributes">
                <Field name="showGuidelines" type="bool">true</Field>
                <Field name="clampSquare" type="bool">false</Field>
                <Field name="fillViewportOnZoom" type="bool">true</Field>
                <Field name="navigationMode" type="string">Trackball</Field>
                <Field name="axisArraySnap" type="bool">true</Field>
                <Field name="boundingBoxMode" type="string">Auto</Field>
            </Object>
            <Object name="MovieAttributes">
                <Field name="generationMethod" type="string">NowCurrentInstance</Field>
                <Field name="movieType" type="string">Simple</Field>
                <Field name="outputDirectory" type="string">.</Field>
                <Field name="outputName" type="string">movie</Field>
                <Field name="fileFormats" type="stringVector"></Field>
                <Field name="useCurrentSize" type="unsignedCharVector"></Field>
                <Field name="widths" type="intVector"></Field>
                <Field name="heights" type="intVector"></Field>
                <Field name="scales" type="doubleVector"></Field>
                <Field name="stereoFlags" type="intVector"></Field>
                <Field name="templateFile" type="string"></Field>
                <Field name="sendEmailNotification" type="bool">false</Field>
                <Field name="emailAddress" type="string"></Field>
                <Field name="fps" type="int">10</Field>
                <Field name="startIndex" type="int">0</Field>
                <Field name="endIndex" type="int">1000000000</Field>
                <Field name="stride" type="int">1</Field>
            </Object>
            <Object name="FileOpenOptions">
                <Field name="typeNames" type="stringVector">"ADIOS" "AMR" "ANALYZE" "ANSYS" "AUXFile" "Adventure" "AugDecomp" "BOV" "BOW" "Boxlib2D" "Boxlib3D" "CCM" "CEAucd" "CGNS" "CMAT" "CTRL" "Cale" "CaleHDF5" "Chombo" "Claw" "Cosmos" "CosmosPP" "Cube" "Curve2D" "DDCMD" "Dyna3D" "EnSight" "Enzo" "Exodus" "ExtrudedVol" "FITS" "FLASH" "Fluent" "GDAL" "GGCM" "GMV" "GTC" "GULP" "Gadget" "Geqdsk" "H5Nimrod" "H5Part" "Image" "KullLite" "LAMMPS" "Lines" "M3DC1" "M3D" "MFIX" "MM5" "Mili" "Miranda" "NASTRAN" "NETCDF" "Nek5000" "OVERFLOW" "OpenFOAM" "PATRAN" "PDB" "PFLOTRAN" "PLOT2D" "PLOT3D" "Pixie" "PlainText" "Point3D" "ProteinDataBank" "PuReMD" "RAW" "S3D" "SAMI" "SAMRAI" "SAR" "SAS" "STAR" "STL" "Shapefile" "Silo" "SimV1" "SimV1Writer" "SimV2" "Spheral" "TFT" "TSurf" "Tecplot" "Tetrad" "TimeVaryingExodus" "UNIC" "VASP" "VCellMTMD" "VTK" "Velodyne" "Vis5D" "Vista" "Vs" "WavefrontOBJ" "XSF" "XYZ" "Xdmf" "Xmdv" "ZeusMP" "ZipWrapper" "lata" "paraDIS" "paraDIS_tecplot" "volimage" </Field>
                <Field name="typeIDs" type="stringVector">"ADIOS_1.0" "AMR_1.0" "ANALYZE_1.0" "ANSYS_1.0" "AUXFile_1.0" "Adventure_1.0" "AugDecomp_1.0" "BOV_1.0" "BOW_1.0" "Boxlib2D_1.0" "Boxlib3D_1.0" "CCM_1.0" "CEAucd_1.0" "CGNS_1.0" "CMAT_1.0" "CTRL_1.0" "Cale_1.1" "CaleHDF5_1.1" "Chombo_1.0" "Claw_1.0" "Cosmos_1.0" "CosmosPP_1.0" "Cube_1.0" "Curve2D_1.0" "DDCMD_1.0" "Dyna3D_1.0" "EnSight_1.0" "Enzo_1.0" "Exodus_1.0" "ExtrudedVol_1.0" "FITS_1.0" "FLASH_1.0" "Fluent_1.0" "GDAL_1.0" "GGCM_1.0" "GMV_1.0" "GTC_1.0" "GULP_1.0" "Gadget_2.0a" "Geqdsk_1.0" "H5Nimrod_1.0" "H5Part_1.0" "Image_1.0" "KullLite_1.0" "LAMMPS_1.0" "Lines_1.0" "M3DC1_1.0" "M3D_1.0" "MFIX_1.0" "MM5_1.0" "Mili_1.0" "Miranda_1.0" "NASTRAN_1.0" "NETCDF_1.0" "Nek5000_1.0" "OVERFLOW_1.0" "OpenFOAM_1.0" "PATRAN_1.0" "PDB_1.1" "PFLOTRAN_1.0" "PLOT2D_1.0" "PLOT3D_1.0" "Pixie_1.0" "PlainText_1.0" "Point3D_1.0" "ProteinDataBank_1.0" "PuReMD_1.0" "RAW_1.0" "S3D_1.0" "SAMI_1.0" "SAMRAI_1.0" "SAR_1.0" "SAS_1.0" "STAR_1.0" "STL_1.0" "Shapefile_1.0" "Silo_1.0" "SimV1_1.0" "SimV1Writer_1.0" "SimV2_1.0" "Spheral_1.0" "TFT_1.0" "TSurf_1.0" "Tecplot_1.0" "Tetrad_1.0" "TimeVaryingExodus_1.0" "UNIC_1.0" "VASP_1.0" "VCellMTMD_1.0" "VTK_1.0" "Velodyne_1.0" "Vis5D_1.0" "Vista_1.0" "Vs_3.0.0" "WavefrontOBJ_1.0" "XSF_1.0" "XYZ_1.0" "Xdmf_1.0" "Xmdv_1.0" "ZeusMP_1.0" "ZipWrapper_1.0" "lata_1.0" "paraDIS_2.0" "paraDIS_tecplot_1.0a1" "volimage_1.0" </Field>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector">0 0 0 0 0 0 </Field>
                    <Field name="names" type="stringVector">"Use ghost data (if present)" "Enable only root level by default" "Enable only explicitly defined materials by default" "Check for mapping file and import coordinates if available" "Use particle_nid and polymer_id to connect particles" "Always compute domain boundaries (hack for AMR stitch cells)" </Field>
                    <Field name="optBools" type="intVector">1 0 0 1 0 0 </Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector">0 0 0 </Field>
                    <Field name="names" type="stringVector">"Show generating processor instead of refinement level" "Use new style curve generation" "Set up patch abutment information" </Field>
                    <Field name="optBools" type="intVector">0 1 1 </Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector">0 0 </Field>
                    <Field name="names" type="stringVector">"Use FastBit index" "Disable domain decomposition" </Field>
                    <Field name="optBools" type="intVector">1 0 </Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector">5 5 0 </Field>
                    <Field name="names" type="stringVector">"Mesh refinement" "Linear mesh data location" "Process Data Selections in the Reader" </Field>
                    <Field name="optBools" type="intVector">0 </Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector">1 0 </Field>
                    <Field name="enumStrings" type="stringVector">"1" "2" "3" "4" "5" "6" "7" "8" "9" "10" "Node" "Element" </Field>
                    <Field name="enumStringsSizes" type="intVector">10 2 </Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector">0 1 </Field>
                    <Field name="names" type="stringVector">"Big Endian" "Target number of domains per MPI process" </Field>
                    <Field name="optBools" type="intVector">1 </Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector">3 </Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector">1 </Field>
                    <Field name="names" type="stringVector">"Num Materials (-1==costly search)" </Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector">0 </Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector">1 </Field>
                    <Field name="names" type="stringVector">"LEOS try harder level [set to 0, 1 or 2]" </Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector">0 </Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector">5 1 0 1 1 1 </Field>
                    <Field name="names" type="stringVector">"Data layout" "Lines to skip at beginning of file" "First row has variable names" "Column for X coordinate (or -1 for none)" "Column for Y coordinate (or -1 for none)" "Column for Z coordinate (or -1 for none)" </Field>
                    <Field name="optBools" type="intVector">0 </Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector">0 -1 -1 -1 </Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector">0 </Field>
                    <Field name="enumStrings" type="stringVector">"1D Columns" "2D Array" </Field>
                    <Field name="enumStringsSizes" type="intVector">2 </Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector">0 0 0 0 </Field>
                    <Field name="names" type="stringVector">"Polygons as lines" "Tessellate polygons" "ESRI Logging" "DBF Logging" </Field>
                    <Field name="optBools" type="intVector">0 1 0 0 </Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector">5 5 0 0 </Field>
                    <Field name="names" type="stringVector">"Ignore spatial extents" "Ignore data extents" "Force Single" "Search For ANNOTATION_INT (!!Slow!!)" </Field>
                    <Field name="optBools" type="intVector">1 0 </Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector">3 3 </Field>
                    <Field name="enumStrings" type="stringVector">"Always" "Auto" "Never" "Undef" "Always" "Auto" "Never" "Undef" </Field>
                    <Field name="enumStringsSizes" type="intVector">4 4 </Field>
                    <Field name="obsoleteNames" type="stringVector">"Ignore Spatial Extents" "Ignore Data Extents" </Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector">5 1 1 1 </Field>
                    <Field name="names" type="stringVector">"Method to determine coordinate axes" "X axis variable index (or -1 for none)" "Y axis variable index (or -1 for none)" "Z axis variable index (or -1 for none)" </Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector">-1 -1 -1 </Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector">0 </Field>
                    <Field name="enumStrings" type="stringVector">"Guess from variable names" "Specify explicitly (below)" </Field>
                    <Field name="enumStringsSizes" type="intVector">2 </Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector">0 </Field>
                    <Field name="names" type="stringVector">"Process Data Selections in the Reader" </Field>
                    <Field name="optBools" type="intVector">0 </Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector">4 4 1 4 0 </Field>
                    <Field name="names" type="stringVector">"TMPDIR for decompressed files" "Unique moniker for dirs made in $TMPDIR" "Max. # decompressed files" "Decompression command" "Don't atexit()" </Field>
                    <Field name="optBools" type="intVector">0 </Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector">50 </Field>
                    <Field name="optStrings" type="stringVector">"$TMPDIR" "$USER" "" </Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector">5 3 1 4 0 </Field>
                    <Field name="names" type="stringVector">"Material Set To Use" "NN arm threshold (-1.0 means no threshold)" "ParaDIS reader verbosity (0-5)" "Debug file name" "Create special debug output files" </Field>
                    <Field name="optBools" type="intVector">0 </Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector">-1 </Field>
                    <Field name="optInts" type="intVector">0 </Field>
                    <Field name="optStrings" type="stringVector">"paradis_debug_output.log" </Field>
                    <Field name="optEnums" type="intVector">0 </Field>
                    <Field name="enumStrings" type="stringVector">"Burgers type" "MN type" </Field>
                    <Field name="enumStringsSizes" type="intVector">2 </Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Object name="DBOptionsAttributes">
                    <Field name="types" type="intVector"></Field>
                    <Field name="names" type="stringVector"></Field>
                    <Field name="optBools" type="intVector"></Field>
                    <Field name="optFloats" type="doubleVector"></Field>
                    <Field name="optDoubles" type="doubleVector"></Field>
                    <Field name="optInts" type="intVector"></Field>
                    <Field name="optStrings" type="stringVector"></Field>
                    <Field name="optEnums" type="intVector"></Field>
                    <Field name="enumStrings" type="stringVector"></Field>
                    <Field name="enumStringsSizes" type="intVector"></Field>
                    <Field name="obsoleteNames" type="stringVector"></Field>
                </Object>
                <Field name="Enabled" type="intVector">1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 </Field>
                <Field name="preferredIDs" type="stringVector">"PDB_1.1" "Silo_1.0" </Field>
            </Object>
            <Object name="BoundaryAttributes">
                <Field name="colorType" type="string">ColorByMultipleColors</Field>
                <Field name="colorTableName" type="string">Default</Field>
                <Field name="invertColorTable" type="bool">false</Field>
                <Field name="filledFlag" type="bool">true</Field>
                <Field name="legendFlag" type="bool">true</Field>
                <Field name="lineStyle" type="int">0</Field>
                <Field name="lineWidth" type="int">0</Field>
                <Object name="singleColor">
                    <Object name="ColorAttribute">
                        <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                    </Object>
                </Object>
                <Object name="multiColor">
                    <Object name="ColorAttributeList">
                    </Object>
                </Object>
                <Field name="boundaryNames" type="stringVector"></Field>
                <Field name="boundaryType" type="string">Unknown</Field>
                <Field name="opacity" type="double">1</Field>
                <Field name="wireframe" type="bool">false</Field>
                <Field name="smoothingLevel" type="int">0</Field>
                <Field name="pointSize" type="double">0.05</Field>
                <Field name="pointType" type="string">Point</Field>
                <Field name="pointSizeVarEnabled" type="bool">false</Field>
                <Field name="pointSizeVar" type="string">default</Field>
                <Field name="pointSizePixels" type="int">2</Field>
            </Object>
            <Object name="ContourAttributes">
                <Object name="defaultPalette">
                    <Object name="ColorControlPointList">
                        <Field name="compactColors" type="unsignedCharVector">255 0 0 255 0 255 0 255 0 0 255 255 0 255 255 255 255 0 255 255 255 255 0 255 255 135 0 255 255 0 135 255 168 168 168 255 255 68 68 255 99 255 99 255 99 99 255 255 40 165 165 255 255 99 255 255 255 255 99 255 255 170 99 255 170 79 255 255 150 0 0 255 0 150 0 255 0 0 150 255 0 109 109 255 150 0 150 255 150 150 0 255 150 84 0 255 160 0 79 255 255 104 28 255 0 170 81 255 68 255 124 255 0 130 255 255 130 0 255 255 </Field>
                        <Field name="compactPositions" type="floatVector">0 0.034 0.069 0.103 0.138 0.172 0.207 0.241 0.276 0.31 0.345 0.379 0.414 0.448 0.483 0.517 0.552 0.586 0.621 0.655 0.69 0.724 0.759 0.793 0.828 0.862 0.897 0.931 0.966 1 </Field>
                        <Field name="smoothingFlag" type="bool">false</Field>
                        <Field name="equalSpacingFlag" type="bool">true</Field>
                        <Field name="discreteFlag" type="bool">true</Field>
                        <Field name="externalFlag" type="bool">false</Field>
                    </Object>
                </Object>
                <Field name="colorType" type="string">ColorByMultipleColors</Field>
                <Field name="colorTableName" type="string">Default</Field>
                <Field name="legendFlag" type="bool">true</Field>
                <Field name="lineStyle" type="int">0</Field>
                <Field name="lineWidth" type="int">0</Field>
                <Object name="singleColor">
                    <Object name="ColorAttribute">
                        <Field name="color" type="unsignedCharArray" length="4">255 0 0 255 </Field>
                    </Object>
                </Object>
                <Field name="contourNLevels" type="int">10</Field>
                <Field name="contourValue" type="doubleVector"></Field>
                <Field name="contourPercent" type="doubleVector"></Field>
                <Field name="contourMethod" type="string">Level</Field>
                <Field name="minFlag" type="bool">false</Field>
                <Field name="maxFlag" type="bool">false</Field>
                <Field name="min" type="double">0</Field>
                <Field name="max" type="double">1</Field>
                <Field name="scaling" type="string">Linear</Field>
                <Field name="wireframe" type="bool">false</Field>
            </Object>
            <Object name="CurveAttributes">
                <Field name="showLines" type="bool">true</Field>
                <Field name="lineStyle" type="int">0</Field>
                <Field name="lineWidth" type="int">0</Field>
                <Field name="showPoints" type="bool">false</Field>
                <Field name="symbol" type="string">Point</Field>
                <Field name="pointSize" type="double">5</Field>
                <Field name="pointFillMode" type="string">Static</Field>
                <Field name="pointStride" type="int">1</Field>
                <Field name="symbolDensity" type="int">50</Field>
                <Field name="curveColorSource" type="string">Cycle</Field>
                <Object name="curveColor">
                    <Object name="ColorAttribute">
                        <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                    </Object>
                </Object>
                <Field name="showLegend" type="bool">true</Field>
                <Field name="showLabels" type="bool">true</Field>
                <Field name="designator" type="string"></Field>
                <Field name="doBallTimeCue" type="bool">false</Field>
                <Object name="ballTimeCueColor">
                    <Object name="ColorAttribute">
                        <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                    </Object>
                </Object>
                <Field name="timeCueBallSize" type="double">0.01</Field>
                <Field name="doLineTimeCue" type="bool">false</Field>
                <Object name="lineTimeCueColor">
                    <Object name="ColorAttribute">
                        <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                    </Object>
                </Object>
                <Field name="lineTimeCueWidth" type="int">0</Field>
                <Field name="doCropTimeCue" type="bool">false</Field>
                <Field name="timeForTimeCue" type="double">0</Field>
            </Object>
            <Object name="FilledBoundaryAttributes">
                <Field name="colorType" type="string">ColorByMultipleColors</Field>
                <Field name="colorTableName" type="string">Default</Field>
                <Field name="invertColorTable" type="bool">false</Field>
                <Field name="filledFlag" type="bool">true</Field>
                <Field name="legendFlag" type="bool">true</Field>
                <Field name="lineStyle" type="int">0</Field>
                <Field name="lineWidth" type="int">0</Field>
                <Object name="singleColor">
                    <Object name="ColorAttribute">
                        <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                    </Object>
                </Object>
                <Object name="multiColor">
                    <Object name="ColorAttributeList">
                    </Object>
                </Object>
                <Field name="boundaryNames" type="stringVector"></Field>
                <Field name="boundaryType" type="string">Unknown</Field>
                <Field name="opacity" type="double">1</Field>
                <Field name="wireframe" type="bool">false</Field>
                <Field name="drawInternal" type="bool">false</Field>
                <Field name="smoothingLevel" type="int">0</Field>
                <Field name="cleanZonesOnly" type="bool">false</Field>
                <Object name="mixedColor">
                    <Object name="ColorAttribute">
                        <Field name="color" type="unsignedCharArray" length="4">255 255 255 255 </Field>
                    </Object>
                </Object>
                <Field name="pointSize" type="double">0.05</Field>
                <Field name="pointType" type="string">Point</Field>
                <Field name="pointSizeVarEnabled" type="bool">false</Field>
                <Field name="pointSizeVar" type="string">default</Field>
                <Field name="pointSizePixels" type="int">2</Field>
            </Object>
            <Object name="HistogramAttributes">
                <Field name="basedOn" type="string">ManyZonesForSingleVar</Field>
                <Field name="histogramType" type="string">Frequency</Field>
                <Field name="weightVariable" type="string">default</Field>
                <Field name="limitsMode" type="string">OriginalData</Field>
                <Field name="minFlag" type="bool">false</Field>
                <Field name="maxFlag" type="bool">false</Field>
                <Field name="min" type="double">0</Field>
                <Field name="max" type="double">1</Field>
                <Field name="numBins" type="int">32</Field>
                <Field name="domain" type="int">0</Field>
                <Field name="zone" type="int">0</Field>
                <Field name="useBinWidths" type="bool">true</Field>
                <Field name="outputType" type="string">Block</Field>
                <Field name="lineStyle" type="int">0</Field>
                <Field name="lineWidth" type="int">0</Field>
                <Object name="color">
                    <Object name="ColorAttribute">
                        <Field name="color" type="unsignedCharArray" length="4">200 80 40 255 </Field>
                    </Object>
                </Object>
                <Field name="dataScale" type="string">Linear</Field>
                <Field name="binScale" type="string">Linear</Field>
            </Object>
            <Object name="LabelAttributes">
                <Field name="varType" type="string">LABEL_VT_UNKNOWN_TYPE</Field>
                <Field name="legendFlag" type="bool">true</Field>
                <Field name="showNodes" type="bool">false</Field>
                <Field name="showCells" type="bool">true</Field>
                <Field name="restrictNumberOfLabels" type="bool">true</Field>
                <Field name="drawLabelsFacing" type="string">Front</Field>
                <Field name="labelDisplayFormat" type="string">Natural</Field>
                <Field name="numberOfLabels" type="int">200</Field>
                <Field name="specifyTextColor1" type="bool">false</Field>
                <Object name="textColor1">
                    <Object name="ColorAttribute">
                        <Field name="color" type="unsignedCharArray" length="4">255 0 0 0 </Field>
                    </Object>
                </Object>
                <Field name="textHeight1" type="float">0.02</Field>
                <Field name="specifyTextColor2" type="bool">false</Field>
                <Object name="textColor2">
                    <Object name="ColorAttribute">
                        <Field name="color" type="unsignedCharArray" length="4">0 0 255 0 </Field>
                    </Object>
                </Object>
                <Field name="textHeight2" type="float">0.02</Field>
                <Field name="horizontalJustification" type="string">HCenter</Field>
                <Field name="verticalJustification" type="string">VCenter</Field>
                <Field name="depthTestMode" type="string">LABEL_DT_AUTO</Field>
                <Field name="formatTemplate" type="string">%g</Field>
            </Object>
            <Object name="MeshAttributes">
                <Field name="legendFlag" type="bool">true</Field>
                <Field name="lineStyle" type="int">0</Field>
                <Field name="lineWidth" type="int">0</Field>
                <Object name="meshColor">
                    <Object name="ColorAttribute">
                        <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                    </Object>
                </Object>
                <Field name="outlineOnlyFlag" type="bool">false</Field>
                <Field name="errorTolerance" type="double">0.01</Field>
                <Field name="meshColorSource" type="string">Foreground</Field>
                <Field name="opaqueColorSource" type="string">Background</Field>
                <Field name="opaqueMode" type="string">Auto</Field>
                <Field name="pointSize" type="double">0.05</Field>
                <Object name="opaqueColor">
                    <Object name="ColorAttribute">
                        <Field name="color" type="unsignedCharArray" length="4">255 255 255 255 </Field>
                    </Object>
                </Object>
                <Field name="smoothingLevel" type="string">None</Field>
                <Field name="pointSizeVarEnabled" type="bool">false</Field>
                <Field name="pointSizeVar" type="string">default</Field>
                <Field name="pointType" type="string">Point</Field>
                <Field name="opaqueMeshIsAppropriate" type="bool">true</Field>
                <Field name="showInternal" type="bool">false</Field>
                <Field name="pointSizePixels" type="int">2</Field>
                <Field name="opacity" type="double">1</Field>
            </Object>
            <Object name="MoleculeAttributes">
                <Field name="drawAtomsAs" type="string">SphereAtoms</Field>
                <Field name="scaleRadiusBy" type="string">Fixed</Field>
                <Field name="drawBondsAs" type="string">CylinderBonds</Field>
                <Field name="colorBonds" type="string">ColorByAtom</Field>
                <Object name="bondSingleColor">
                    <Object name="ColorAttribute">
                        <Field name="color" type="unsignedCharArray" length="4">128 128 128 255 </Field>
                    </Object>
                </Object>
                <Field name="radiusVariable" type="string">Default</Field>
                <Field name="radiusScaleFactor" type="float">1</Field>
                <Field name="radiusFixed" type="float">0.3</Field>
                <Field name="atomSphereQuality" type="string">Medium</Field>
                <Field name="bondCylinderQuality" type="string">Medium</Field>
                <Field name="bondRadius" type="float">0.12</Field>
                <Field name="bondLineWidth" type="int">0</Field>
                <Field name="bondLineStyle" type="int">0</Field>
                <Field name="elementColorTable" type="string">cpk_jmol</Field>
                <Field name="residueTypeColorTable" type="string">amino_shapely</Field>
                <Field name="residueSequenceColorTable" type="string">Default</Field>
                <Field name="continuousColorTable" type="string">Default</Field>
                <Field name="legendFlag" type="bool">true</Field>
                <Field name="minFlag" type="bool">false</Field>
                <Field name="scalarMin" type="float">0</Field>
                <Field name="maxFlag" type="bool">false</Field>
                <Field name="scalarMax" type="float">1</Field>
            </Object>
            <Object name="MultiCurveAttributes">
                <Object name="defaultPalette">
                    <Object name="ColorControlPointList">
                        <Object name="ColorControlPoint">
                            <Field name="colors" type="unsignedCharArray" length="4">255 0 0 255 </Field>
                            <Field name="position" type="float">0</Field>
                        </Object>
                        <Object name="ColorControlPoint">
                            <Field name="colors" type="unsignedCharArray" length="4">0 255 0 255 </Field>
                            <Field name="position" type="float">0.034</Field>
                        </Object>
                        <Object name="ColorControlPoint">
                            <Field name="colors" type="unsignedCharArray" length="4">0 0 255 255 </Field>
                            <Field name="position" type="float">0.069</Field>
                        </Object>
                        <Object name="ColorControlPoint">
                            <Field name="colors" type="unsignedCharArray" length="4">0 255 255 255 </Field>
                            <Field name="position" type="float">0.103</Field>
                        </Object>
                        <Object name="ColorControlPoint">
                            <Field name="colors" type="unsignedCharArray" length="4">255 0 255 255 </Field>
                            <Field name="position" type="float">0.138</Field>
                        </Object>
                        <Object name="ColorControlPoint">
                            <Field name="colors" type="unsignedCharArray" length="4">255 255 0 255 </Field>
                            <Field name="position" type="float">0.172</Field>
                        </Object>
                        <Object name="ColorControlPoint">
                            <Field name="colors" type="unsignedCharArray" length="4">255 135 0 255 </Field>
                            <Field name="position" type="float">0.207</Field>
                        </Object>
                        <Object name="ColorControlPoint">
                            <Field name="colors" type="unsignedCharArray" length="4">255 0 135 255 </Field>
                            <Field name="position" type="float">0.241</Field>
                        </Object>
                        <Object name="ColorControlPoint">
                            <Field name="colors" type="unsignedCharArray" length="4">168 168 168 255 </Field>
                            <Field name="position" type="float">0.276</Field>
                        </Object>
                        <Object name="ColorControlPoint">
                            <Field name="colors" type="unsignedCharArray" length="4">255 68 68 255 </Field>
                            <Field name="position" type="float">0.31</Field>
                        </Object>
                        <Object name="ColorControlPoint">
                            <Field name="colors" type="unsignedCharArray" length="4">99 255 99 255 </Field>
                            <Field name="position" type="float">0.345</Field>
                        </Object>
                        <Object name="ColorControlPoint">
                            <Field name="colors" type="unsignedCharArray" length="4">99 99 255 255 </Field>
                            <Field name="position" type="float">0.379</Field>
                        </Object>
                        <Object name="ColorControlPoint">
                            <Field name="colors" type="unsignedCharArray" length="4">40 165 165 255 </Field>
                            <Field name="position" type="float">0.414</Field>
                        </Object>
                        <Object name="ColorControlPoint">
                            <Field name="colors" type="unsignedCharArray" length="4">255 99 255 255 </Field>
                            <Field name="position" type="float">0.448</Field>
                        </Object>
                        <Object name="ColorControlPoint">
                            <Field name="colors" type="unsignedCharArray" length="4">255 255 99 255 </Field>
                            <Field name="position" type="float">0.483</Field>
                        </Object>
                        <Object name="ColorControlPoint">
                            <Field name="colors" type="unsignedCharArray" length="4">255 170 99 255 </Field>
                            <Field name="position" type="float">0.517</Field>
                        </Object>
                        <Object name="ColorControlPoint">
                            <Field name="colors" type="unsignedCharArray" length="4">170 79 255 255 </Field>
                            <Field name="position" type="float">0.552</Field>
                        </Object>
                        <Object name="ColorControlPoint">
                            <Field name="colors" type="unsignedCharArray" length="4">150 0 0 255 </Field>
                            <Field name="position" type="float">0.586</Field>
                        </Object>
                        <Object name="ColorControlPoint">
                            <Field name="colors" type="unsignedCharArray" length="4">0 150 0 255 </Field>
                            <Field name="position" type="float">0.621</Field>
                        </Object>
                        <Object name="ColorControlPoint">
                            <Field name="colors" type="unsignedCharArray" length="4">0 0 150 255 </Field>
                            <Field name="position" type="float">0.655</Field>
                        </Object>
                        <Object name="ColorControlPoint">
                            <Field name="colors" type="unsignedCharArray" length="4">0 109 109 255 </Field>
                            <Field name="position" type="float">0.69</Field>
                        </Object>
                        <Object name="ColorControlPoint">
                            <Field name="colors" type="unsignedCharArray" length="4">150 0 150 255 </Field>
                            <Field name="position" type="float">0.724</Field>
                        </Object>
                        <Object name="ColorControlPoint">
                            <Field name="colors" type="unsignedCharArray" length="4">150 150 0 255 </Field>
                            <Field name="position" type="float">0.759</Field>
                        </Object>
                        <Object name="ColorControlPoint">
                            <Field name="colors" type="unsignedCharArray" length="4">150 84 0 255 </Field>
                            <Field name="position" type="float">0.793</Field>
                        </Object>
                        <Object name="ColorControlPoint">
                            <Field name="colors" type="unsignedCharArray" length="4">160 0 79 255 </Field>
                            <Field name="position" type="float">0.828</Field>
                        </Object>
                        <Object name="ColorControlPoint">
                            <Field name="colors" type="unsignedCharArray" length="4">255 104 28 255 </Field>
                            <Field name="position" type="float">0.862</Field>
                        </Object>
                        <Object name="ColorControlPoint">
                            <Field name="colors" type="unsignedCharArray" length="4">0 170 81 255 </Field>
                            <Field name="position" type="float">0.897</Field>
                        </Object>
                        <Object name="ColorControlPoint">
                            <Field name="colors" type="unsignedCharArray" length="4">68 255 124 255 </Field>
                            <Field name="position" type="float">0.931</Field>
                        </Object>
                        <Object name="ColorControlPoint">
                            <Field name="colors" type="unsignedCharArray" length="4">0 130 255 255 </Field>
                            <Field name="position" type="float">0.966</Field>
                        </Object>
                        <Object name="ColorControlPoint">
                            <Field name="colors" type="unsignedCharArray" length="4">130 0 255 255 </Field>
                            <Field name="position" type="float">1</Field>
                        </Object>
                        <Field name="smoothingFlag" type="bool">false</Field>
                        <Field name="equalSpacingFlag" type="bool">true</Field>
                        <Field name="discreteFlag" type="bool">true</Field>
                        <Field name="externalFlag" type="bool">false</Field>
                    </Object>
                </Object>
                <Field name="changedColors" type="unsignedCharVector"></Field>
                <Field name="colorType" type="string">ColorByMultipleColors</Field>
                <Object name="singleColor">
                    <Object name="ColorAttribute">
                        <Field name="color" type="unsignedCharArray" length="4">255 0 0 255 </Field>
                    </Object>
                </Object>
                <Object name="multiColor">
                    <Object name="ColorAttributeList">
                        <Object name="ColorAttribute">
                            <Field name="color" type="unsignedCharArray" length="4">255 0 0 255 </Field>
                        </Object>
                        <Object name="ColorAttribute">
                            <Field name="color" type="unsignedCharArray" length="4">0 255 0 255 </Field>
                        </Object>
                        <Object name="ColorAttribute">
                            <Field name="color" type="unsignedCharArray" length="4">0 0 255 255 </Field>
                        </Object>
                        <Object name="ColorAttribute">
                            <Field name="color" type="unsignedCharArray" length="4">0 255 255 255 </Field>
                        </Object>
                        <Object name="ColorAttribute">
                            <Field name="color" type="unsignedCharArray" length="4">255 0 255 255 </Field>
                        </Object>
                        <Object name="ColorAttribute">
                            <Field name="color" type="unsignedCharArray" length="4">255 255 0 255 </Field>
                        </Object>
                        <Object name="ColorAttribute">
                            <Field name="color" type="unsignedCharArray" length="4">255 135 0 255 </Field>
                        </Object>
                        <Object name="ColorAttribute">
                            <Field name="color" type="unsignedCharArray" length="4">255 0 135 255 </Field>
                        </Object>
                        <Object name="ColorAttribute">
                            <Field name="color" type="unsignedCharArray" length="4">168 168 168 255 </Field>
                        </Object>
                        <Object name="ColorAttribute">
                            <Field name="color" type="unsignedCharArray" length="4">255 68 68 255 </Field>
                        </Object>
                        <Object name="ColorAttribute">
                            <Field name="color" type="unsignedCharArray" length="4">99 255 99 255 </Field>
                        </Object>
                        <Object name="ColorAttribute">
                            <Field name="color" type="unsignedCharArray" length="4">99 99 255 255 </Field>
                        </Object>
                        <Object name="ColorAttribute">
                            <Field name="color" type="unsignedCharArray" length="4">40 165 165 255 </Field>
                        </Object>
                        <Object name="ColorAttribute">
                            <Field name="color" type="unsignedCharArray" length="4">255 99 255 255 </Field>
                        </Object>
                        <Object name="ColorAttribute">
                            <Field name="color" type="unsignedCharArray" length="4">255 255 99 255 </Field>
                        </Object>
                        <Object name="ColorAttribute">
                            <Field name="color" type="unsignedCharArray" length="4">255 170 99 255 </Field>
                        </Object>
                    </Object>
                </Object>
                <Field name="lineStyle" type="int">0</Field>
                <Field name="lineWidth" type="int">0</Field>
                <Field name="yAxisTitleFormat" type="string">%g</Field>
                <Field name="useYAxisTickSpacing" type="bool">false</Field>
                <Field name="yAxisTickSpacing" type="double">1</Field>
                <Field name="displayMarkers" type="bool">true</Field>
                <Field name="markerVariable" type="string">default</Field>
                <Field name="displayIds" type="bool">false</Field>
                <Field name="idVariable" type="string">default</Field>
                <Field name="legendFlag" type="bool">true</Field>
            </Object>
            <Object name="ParallelCoordinatesAttributes">
                <Field name="scalarAxisNames" type="stringVector"></Field>
                <Field name="visualAxisNames" type="stringVector"></Field>
                <Field name="extentMinima" type="doubleVector"></Field>
                <Field name="extentMaxima" type="doubleVector"></Field>
                <Field name="drawLines" type="bool">true</Field>
                <Object name="linesColor">
                    <Object name="ColorAttribute">
                        <Field name="color" type="unsignedCharArray" length="4">128 0 0 255 </Field>
                    </Object>
                </Object>
                <Field name="drawContext" type="bool">true</Field>
                <Field name="contextGamma" type="float">2</Field>
                <Field name="contextNumPartitions" type="int">128</Field>
                <Object name="contextColor">
                    <Object name="ColorAttribute">
                        <Field name="color" type="unsignedCharArray" length="4">0 220 0 255 </Field>
                    </Object>
                </Object>
                <Field name="drawLinesOnlyIfExtentsOn" type="bool">true</Field>
                <Field name="unifyAxisExtents" type="bool">false</Field>
                <Field name="linesNumPartitions" type="int">512</Field>
                <Field name="focusGamma" type="float">4</Field>
                <Field name="drawFocusAs" type="string">BinsOfConstantColor</Field>
            </Object>
            <Object name="PoincareAttributes">
                <Field name="opacityType" type="string">Explicit</Field>
                <Field name="opacity" type="double">1</Field>
                <Field name="minPunctures" type="int">50</Field>
                <Field name="maxPunctures" type="int">500</Field>
                <Field name="puncturePlane" type="string">Poloidal</Field>
                <Field name="sourceType" type="string">SpecifiedPoint</Field>
                <Field name="pointSource" type="doubleArray" length="3">0 0 0 </Field>
                <Field name="lineStart" type="doubleArray" length="3">0 0 0 </Field>
                <Field name="lineEnd" type="doubleArray" length="3">1 0 0 </Field>
                <Field name="pointDensity" type="int">1</Field>
                <Field name="fieldType" type="string">Default</Field>
                <Field name="fieldConstant" type="double">1</Field>
                <Field name="velocitySource" type="doubleArray" length="3">0 0 0 </Field>
                <Field name="integrationType" type="string">AdamsBashforth</Field>
                <Field name="coordinateSystem" type="string">Cartesian</Field>
                <Field name="maxStepLength" type="double">0.1</Field>
                <Field name="limitMaximumTimestep" type="bool">false</Field>
                <Field name="maxTimeStep" type="double">0.1</Field>
                <Field name="relTol" type="double">0.0001</Field>
                <Field name="absTolSizeType" type="string">FractionOfBBox</Field>
                <Field name="absTolAbsolute" type="double">1e-05</Field>
                <Field name="absTolBBox" type="double">1e-06</Field>
                <Field name="analysis" type="string">Normal</Field>
                <Field name="maximumToroidalWinding" type="int">0</Field>
                <Field name="overrideToroidalWinding" type="int">0</Field>
                <Field name="overridePoloidalWinding" type="int">0</Field>
                <Field name="windingPairConfidence" type="double">0.9</Field>
                <Field name="rationalSurfaceFactor" type="double">0.1</Field>
                <Field name="adjustPlane" type="int">-1</Field>
                <Field name="overlaps" type="string">Remove</Field>
                <Field name="meshType" type="string">Curves</Field>
                <Field name="numberPlanes" type="int">1</Field>
                <Field name="singlePlane" type="double">0</Field>
                <Field name="min" type="double">0</Field>
                <Field name="max" type="double">0</Field>
                <Field name="minFlag" type="bool">false</Field>
                <Field name="maxFlag" type="bool">false</Field>
                <Field name="colorType" type="string">ColorByColorTable</Field>
                <Object name="singleColor">
                    <Object name="ColorAttribute">
                        <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                    </Object>
                </Object>
                <Field name="colorTableName" type="string">Default</Field>
                <Field name="dataValue" type="string">SafetyFactorQ</Field>
                <Field name="showOPoints" type="bool">false</Field>
                <Field name="OPointMaxIterations" type="int">2</Field>
                <Field name="showXPoints" type="bool">false</Field>
                <Field name="XPointMaxIterations" type="int">2</Field>
                <Field name="showChaotic" type="bool">false</Field>
                <Field name="showIslands" type="bool">false</Field>
                <Field name="verboseFlag" type="bool">true</Field>
                <Field name="show1DPlots" type="bool">false</Field>
                <Field name="showLines" type="bool">true</Field>
                <Field name="lineWidth" type="int">0</Field>
                <Field name="lineStyle" type="int">0</Field>
                <Field name="showPoints" type="bool">false</Field>
                <Field name="pointSize" type="double">1</Field>
                <Field name="pointSizePixels" type="int">1</Field>
                <Field name="pointType" type="string">Point</Field>
                <Field name="legendFlag" type="bool">true</Field>
                <Field name="lightingFlag" type="bool">true</Field>
                <Field name="streamlineAlgorithmType" type="string">LoadOnDemand</Field>
                <Field name="maxStreamlineProcessCount" type="int">10</Field>
                <Field name="maxDomainCacheSize" type="int">3</Field>
                <Field name="workGroupSize" type="int">32</Field>
                <Field name="forceNodeCenteredData" type="bool">false</Field>
            </Object>
            <Object name="PseudocolorAttributes">
                <Field name="legendFlag" type="bool">true</Field>
                <Field name="lightingFlag" type="bool">true</Field>
                <Field name="minFlag" type="bool">false</Field>
                <Field name="maxFlag" type="bool">false</Field>
                <Field name="centering" type="string">Natural</Field>
                <Field name="scaling" type="string">Linear</Field>
                <Field name="limitsMode" type="string">OriginalData</Field>
                <Field name="min" type="double">0</Field>
                <Field name="max" type="double">1</Field>
                <Field name="pointSize" type="double">0.05</Field>
                <Field name="pointType" type="string">Point</Field>
                <Field name="skewFactor" type="double">1</Field>
                <Field name="opacity" type="double">1</Field>
                <Field name="colorTableName" type="string">hot</Field>
                <Field name="invertColorTable" type="bool">false</Field>
                <Field name="smoothingLevel" type="int">0</Field>
                <Field name="pointSizeVarEnabled" type="bool">false</Field>
                <Field name="pointSizeVar" type="string">default</Field>
                <Field name="pointSizePixels" type="int">2</Field>
                <Field name="lineStyle" type="int">0</Field>
                <Field name="lineWidth" type="int">0</Field>
                <Field name="opacityType" type="string">Explicit</Field>
            </Object>
            <Object name="ScatterAttributes">
                <Field name="var1" type="string">default</Field>
                <Field name="var1Role" type="string">Coordinate0</Field>
                <Field name="var1MinFlag" type="bool">false</Field>
                <Field name="var1MaxFlag" type="bool">false</Field>
                <Field name="var1Min" type="double">0</Field>
                <Field name="var1Max" type="double">1</Field>
                <Field name="var1Scaling" type="string">Linear</Field>
                <Field name="var1SkewFactor" type="double">1</Field>
                <Field name="var2Role" type="string">Coordinate1</Field>
                <Field name="var2" type="string">default</Field>
                <Field name="var2MinFlag" type="bool">false</Field>
                <Field name="var2MaxFlag" type="bool">false</Field>
                <Field name="var2Min" type="double">0</Field>
                <Field name="var2Max" type="double">1</Field>
                <Field name="var2Scaling" type="string">Linear</Field>
                <Field name="var2SkewFactor" type="double">1</Field>
                <Field name="var3Role" type="string">None</Field>
                <Field name="var3" type="string">default</Field>
                <Field name="var3MinFlag" type="bool">false</Field>
                <Field name="var3MaxFlag" type="bool">false</Field>
                <Field name="var3Min" type="double">0</Field>
                <Field name="var3Max" type="double">1</Field>
                <Field name="var3Scaling" type="string">Linear</Field>
                <Field name="var3SkewFactor" type="double">1</Field>
                <Field name="var4Role" type="string">None</Field>
                <Field name="var4" type="string">default</Field>
                <Field name="var4MinFlag" type="bool">false</Field>
                <Field name="var4MaxFlag" type="bool">false</Field>
                <Field name="var4Min" type="double">0</Field>
                <Field name="var4Max" type="double">1</Field>
                <Field name="var4Scaling" type="string">Linear</Field>
                <Field name="var4SkewFactor" type="double">1</Field>
                <Field name="pointSize" type="double">0.05</Field>
                <Field name="pointSizePixels" type="int">1</Field>
                <Field name="pointType" type="string">Point</Field>
                <Field name="scaleCube" type="bool">true</Field>
                <Field name="colorType" type="string">ColorByForegroundColor</Field>
                <Object name="singleColor">
                    <Object name="ColorAttribute">
                        <Field name="color" type="unsignedCharArray" length="4">255 0 0 255 </Field>
                    </Object>
                </Object>
                <Field name="colorTableName" type="string">Default</Field>
                <Field name="invertColorTable" type="bool">false</Field>
                <Field name="legendFlag" type="bool">true</Field>
            </Object>
            <Object name="SpreadsheetAttributes">
                <Field name="subsetName" type="string">Whole</Field>
                <Field name="formatString" type="string">%1.6f</Field>
                <Field name="useColorTable" type="bool">false</Field>
                <Field name="colorTableName" type="string">Default</Field>
                <Field name="showTracerPlane" type="bool">true</Field>
                <Object name="tracerColor">
                    <Object name="ColorAttribute">
                        <Field name="color" type="unsignedCharArray" length="4">255 0 0 150 </Field>
                    </Object>
                </Object>
                <Field name="normal" type="string">Z</Field>
                <Field name="sliceIndex" type="int">0</Field>
                <Field name="spreadsheetFont" type="string">Courier,12,-1,5,50,0,0,0,0,0</Field>
                <Field name="showPatchOutline" type="bool">true</Field>
                <Field name="showCurrentCellOutline" type="bool">false</Field>
            </Object>
            <Object name="StreamlineAttributes">
                <Field name="sourceType" type="string">SpecifiedPoint</Field>
                <Field name="pointSource" type="doubleArray" length="3">0 0 0 </Field>
                <Field name="lineStart" type="doubleArray" length="3">0 0 0 </Field>
                <Field name="lineEnd" type="doubleArray" length="3">1 0 0 </Field>
                <Field name="planeOrigin" type="doubleArray" length="3">0 0 0 </Field>
                <Field name="planeNormal" type="doubleArray" length="3">0 0 1 </Field>
                <Field name="planeUpAxis" type="doubleArray" length="3">0 1 0 </Field>
                <Field name="radius" type="double">1</Field>
                <Field name="sphereOrigin" type="doubleArray" length="3">0 0 0 </Field>
                <Field name="boxExtents" type="doubleArray" length="6">0 1 0 1 0 1 </Field>
                <Field name="useWholeBox" type="bool">true</Field>
                <Field name="pointList" type="doubleVector">0 0 0 1 0 0 0 1 0 </Field>
                <Field name="sampleDensity0" type="int">2</Field>
                <Field name="sampleDensity1" type="int">2</Field>
                <Field name="sampleDensity2" type="int">2</Field>
                <Field name="coloringMethod" type="string">ColorByTime</Field>
                <Field name="colorTableName" type="string">Default</Field>
                <Object name="singleColor">
                    <Object name="ColorAttribute">
                        <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                    </Object>
                </Object>
                <Field name="legendFlag" type="bool">true</Field>
                <Field name="lightingFlag" type="bool">true</Field>
                <Field name="streamlineDirection" type="string">Forward</Field>
                <Field name="maxSteps" type="int">1000</Field>
                <Field name="terminateByDistance" type="bool">false</Field>
                <Field name="termDistance" type="double">10</Field>
                <Field name="terminateByTime" type="bool">false</Field>
                <Field name="termTime" type="double">10</Field>
                <Field name="maxStepLength" type="double">0.1</Field>
                <Field name="limitMaximumTimestep" type="bool">false</Field>
                <Field name="maxTimeStep" type="double">0.1</Field>
                <Field name="relTol" type="double">0.0001</Field>
                <Field name="absTolSizeType" type="string">FractionOfBBox</Field>
                <Field name="absTolAbsolute" type="double">1e-06</Field>
                <Field name="absTolBBox" type="double">1e-06</Field>
                <Field name="fieldType" type="string">Default</Field>
                <Field name="fieldConstant" type="double">1</Field>
                <Field name="velocitySource" type="doubleArray" length="3">0 0 0 </Field>
                <Field name="integrationType" type="string">DormandPrince</Field>
                <Field name="streamlineAlgorithmType" type="string">VisItSelects</Field>
                <Field name="maxStreamlineProcessCount" type="int">10</Field>
                <Field name="maxDomainCacheSize" type="int">3</Field>
                <Field name="workGroupSize" type="int">32</Field>
                <Field name="pathlines" type="bool">false</Field>
                <Field name="pathlinesOverrideStartingTimeFlag" type="bool">false</Field>
                <Field name="pathlinesOverrideStartingTime" type="double">0</Field>
                <Field name="pathlinesCMFE" type="string">POS_CMFE</Field>
                <Field name="coordinateSystem" type="string">AsIs</Field>
                <Field name="phiScalingFlag" type="bool">false</Field>
                <Field name="phiScaling" type="double">1</Field>
                <Field name="coloringVariable" type="string"></Field>
                <Field name="legendMinFlag" type="bool">false</Field>
                <Field name="legendMaxFlag" type="bool">false</Field>
                <Field name="legendMin" type="double">0</Field>
                <Field name="legendMax" type="double">1</Field>
                <Field name="displayBegin" type="double">0</Field>
                <Field name="displayEnd" type="double">1</Field>
                <Field name="displayBeginFlag" type="bool">false</Field>
                <Field name="displayEndFlag" type="bool">false</Field>
                <Field name="referenceTypeForDisplay" type="string">Distance</Field>
                <Field name="displayMethod" type="string">Lines</Field>
                <Field name="tubeSizeType" type="string">FractionOfBBox</Field>
                <Field name="tubeRadiusAbsolute" type="double">0.125</Field>
                <Field name="tubeRadiusBBox" type="double">0.005</Field>
                <Field name="ribbonWidthSizeType" type="string">FractionOfBBox</Field>
                <Field name="ribbonWidthAbsolute" type="double">0.125</Field>
                <Field name="ribbonWidthBBox" type="double">0.01</Field>
                <Field name="lineWidth" type="int">2</Field>
                <Field name="showSeeds" type="bool">true</Field>
                <Field name="seedRadiusSizeType" type="string">FractionOfBBox</Field>
                <Field name="seedRadiusAbsolute" type="double">1</Field>
                <Field name="seedRadiusBBox" type="double">0.015</Field>
                <Field name="showHeads" type="bool">false</Field>
                <Field name="headDisplayType" type="string">Sphere</Field>
                <Field name="headRadiusSizeType" type="string">FractionOfBBox</Field>
                <Field name="headRadiusAbsolute" type="double">0.25</Field>
                <Field name="headRadiusBBox" type="double">0.02</Field>
                <Field name="headHeightRatio" type="double">2</Field>
                <Field name="opacityType" type="string">FullyOpaque</Field>
                <Field name="opacityVariable" type="string"></Field>
                <Field name="opacity" type="double">1</Field>
                <Field name="opacityVarMin" type="double">0</Field>
                <Field name="opacityVarMax" type="double">1</Field>
                <Field name="opacityVarMinFlag" type="bool">false</Field>
                <Field name="opacityVarMaxFlag" type="bool">false</Field>
                <Field name="tubeDisplayDensity" type="int">10</Field>
                <Field name="geomDisplayQuality" type="string">Medium</Field>
                <Field name="sampleDistance0" type="double">10</Field>
                <Field name="sampleDistance1" type="double">10</Field>
                <Field name="sampleDistance2" type="double">10</Field>
                <Field name="fillInterior" type="bool">true</Field>
                <Field name="randomSamples" type="bool">false</Field>
                <Field name="randomSeed" type="int">0</Field>
                <Field name="numberOfRandomSamples" type="int">1</Field>
                <Field name="forceNodeCenteredData" type="bool">false</Field>
                <Field name="issueTerminationWarnings" type="bool">true</Field>
                <Field name="issueStiffnessWarnings" type="bool">true</Field>
                <Field name="issueCriticalPointsWarnings" type="bool">true</Field>
                <Field name="criticalPointThreshold" type="double">0.001</Field>
                <Field name="varyTubeRadius" type="string">None</Field>
                <Field name="varyTubeRadiusFactor" type="double">10</Field>
                <Field name="varyTubeRadiusVariable" type="string"></Field>
                <Field name="correlationDistanceAngTol" type="double">5</Field>
                <Field name="correlationDistanceMinDistAbsolute" type="double">1</Field>
                <Field name="correlationDistanceMinDistBBox" type="double">0.005</Field>
                <Field name="correlationDistanceMinDistType" type="string">FractionOfBBox</Field>
            </Object>
            <Object name="SubsetAttributes">
                <Field name="colorType" type="string">ColorByMultipleColors</Field>
                <Field name="colorTableName" type="string">Default</Field>
                <Field name="invertColorTable" type="bool">false</Field>
                <Field name="filledFlag" type="bool">true</Field>
                <Field name="legendFlag" type="bool">true</Field>
                <Field name="lineStyle" type="int">0</Field>
                <Field name="lineWidth" type="int">0</Field>
                <Object name="singleColor">
                    <Object name="ColorAttribute">
                        <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                    </Object>
                </Object>
                <Object name="multiColor">
                    <Object name="ColorAttributeList">
                    </Object>
                </Object>
                <Field name="subsetNames" type="stringVector"></Field>
                <Field name="subsetType" type="string">Unknown</Field>
                <Field name="opacity" type="double">1</Field>
                <Field name="wireframe" type="bool">false</Field>
                <Field name="drawInternal" type="bool">false</Field>
                <Field name="smoothingLevel" type="int">0</Field>
                <Field name="pointSize" type="double">0.05</Field>
                <Field name="pointType" type="string">Point</Field>
                <Field name="pointSizeVarEnabled" type="bool">false</Field>
                <Field name="pointSizeVar" type="string">default</Field>
                <Field name="pointSizePixels" type="int">2</Field>
            </Object>
            <Object name="TensorAttributes">
                <Field name="useStride" type="bool">false</Field>
                <Field name="stride" type="int">1</Field>
                <Field name="nTensors" type="int">400</Field>
                <Field name="scale" type="double">0.25</Field>
                <Field name="scaleByMagnitude" type="bool">true</Field>
                <Field name="autoScale" type="bool">true</Field>
                <Field name="colorByEigenvalues" type="bool">true</Field>
                <Field name="useLegend" type="bool">true</Field>
                <Object name="tensorColor">
                    <Object name="ColorAttribute">
                        <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                    </Object>
                </Object>
                <Field name="colorTableName" type="string">Default</Field>
                <Field name="invertColorTable" type="bool">false</Field>
            </Object>
            <Object name="TruecolorAttributes">
                <Field name="opacity" type="double">1</Field>
                <Field name="lightingFlag" type="bool">true</Field>
            </Object>
            <Object name="VectorAttributes">
                <Field name="glyphLocation" type="string">AdaptsToMeshResolution</Field>
                <Field name="useStride" type="bool">false</Field>
                <Field name="stride" type="int">1</Field>
                <Field name="nVectors" type="int">400</Field>
                <Field name="lineStyle" type="int">0</Field>
                <Field name="lineWidth" type="int">0</Field>
                <Field name="scale" type="double">0.25</Field>
                <Field name="scaleByMagnitude" type="bool">true</Field>
                <Field name="autoScale" type="bool">true</Field>
                <Field name="headSize" type="double">0.25</Field>
                <Field name="headOn" type="bool">true</Field>
                <Field name="colorByMag" type="bool">true</Field>
                <Field name="useLegend" type="bool">true</Field>
                <Object name="vectorColor">
                    <Object name="ColorAttribute">
                        <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                    </Object>
                </Object>
                <Field name="colorTableName" type="string">Default</Field>
                <Field name="invertColorTable" type="bool">false</Field>
                <Field name="vectorOrigin" type="string">Tail</Field>
                <Field name="minFlag" type="bool">false</Field>
                <Field name="maxFlag" type="bool">false</Field>
                <Field name="limitsMode" type="string">OriginalData</Field>
                <Field name="min" type="double">0</Field>
                <Field name="max" type="double">1</Field>
                <Field name="lineStem" type="bool">true</Field>
                <Field name="geometryQuality" type="string">Fast</Field>
                <Field name="stemWidth" type="double">0.08</Field>
                <Field name="origOnly" type="bool">true</Field>
                <Field name="glyphType" type="string">Arrow</Field>
            </Object>
            <Object name="VolumeAttributes">
                <Field name="legendFlag" type="bool">true</Field>
                <Field name="lightingFlag" type="bool">true</Field>
                <Object name="colorControlPoints">
                    <Object name="ColorControlPointList">
                        <Object name="ColorControlPoint">
                            <Field name="colors" type="unsignedCharArray" length="4">0 0 255 255 </Field>
                            <Field name="position" type="float">0</Field>
                        </Object>
                        <Object name="ColorControlPoint">
                            <Field name="colors" type="unsignedCharArray" length="4">0 255 255 255 </Field>
                            <Field name="position" type="float">0.25</Field>
                        </Object>
                        <Object name="ColorControlPoint">
                            <Field name="colors" type="unsignedCharArray" length="4">0 255 0 255 </Field>
                            <Field name="position" type="float">0.5</Field>
                        </Object>
                        <Object name="ColorControlPoint">
                            <Field name="colors" type="unsignedCharArray" length="4">255 255 0 255 </Field>
                            <Field name="position" type="float">0.75</Field>
                        </Object>
                        <Object name="ColorControlPoint">
                            <Field name="colors" type="unsignedCharArray" length="4">255 0 0 255 </Field>
                            <Field name="position" type="float">1</Field>
                        </Object>
                        <Field name="smoothingFlag" type="bool">true</Field>
                        <Field name="equalSpacingFlag" type="bool">false</Field>
                        <Field name="discreteFlag" type="bool">false</Field>
                        <Field name="externalFlag" type="bool">false</Field>
                    </Object>
                </Object>
                <Field name="opacityAttenuation" type="float">1</Field>
                <Field name="opacityMode" type="string">FreeformMode</Field>
                <Object name="opacityControlPoints">
                    <Object name="GaussianControlPointList">
                    </Object>
                </Object>
                <Field name="resampleTarget" type="int">50000</Field>
                <Field name="opacityVariable" type="string">default</Field>
                <Field name="freeformOpacity" type="unsignedCharArray" length="256">0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59 60 61 62 63 64 65 66 67 68 69 70 71 72 73 74 75 76 77 78 79 80 81 82 83 84 85 86 87 88 89 90 91 92 93 94 95 96 97 98 99 100 101 102 103 104 105 106 107 108 109 110 111 112 113 114 115 116 117 118 119 120 121 122 123 124 125 126 127 128 129 130 131 132 133 134 135 136 137 138 139 140 141 142 143 144 145 146 147 148 149 150 151 152 153 154 155 156 157 158 159 160 161 162 163 164 165 166 167 168 169 170 171 172 173 174 175 176 177 178 179 180 181 182 183 184 185 186 187 188 189 190 191 192 193 194 195 196 197 198 199 200 201 202 203 204 205 206 207 208 209 210 211 212 213 214 215 216 217 218 219 220 221 222 223 224 225 226 227 228 229 230 231 232 233 234 235 236 237 238 239 240 241 242 243 244 245 246 247 248 249 250 251 252 253 254 255 </Field>
                <Field name="useColorVarMin" type="bool">false</Field>
                <Field name="colorVarMin" type="float">0</Field>
                <Field name="useColorVarMax" type="bool">false</Field>
                <Field name="colorVarMax" type="float">0</Field>
                <Field name="useOpacityVarMin" type="bool">false</Field>
                <Field name="opacityVarMin" type="float">0</Field>
                <Field name="useOpacityVarMax" type="bool">false</Field>
                <Field name="opacityVarMax" type="float">0</Field>
                <Field name="smoothData" type="bool">false</Field>
                <Field name="samplesPerRay" type="int">500</Field>
                <Field name="rendererType" type="string">Splatting</Field>
                <Field name="gradientType" type="string">SobelOperator</Field>
                <Field name="num3DSlices" type="int">200</Field>
                <Field name="scaling" type="string">Linear</Field>
                <Field name="skewFactor" type="double">1</Field>
                <Field name="limitsMode" type="string">OriginalData</Field>
                <Field name="sampling" type="string">Rasterization</Field>
                <Field name="rendererSamples" type="float">3</Field>
                <Field name="transferFunctionDim" type="int">1</Field>
                <Field name="lowGradientLightingReduction" type="string">Lower</Field>
                <Field name="lowGradientLightingClampFlag" type="bool">false</Field>
                <Field name="lowGradientLightingClampValue" type="double">1</Field>
            </Object>
            <Object name="BoundaryOpAttributes">
                <Field name="smoothingLevel" type="int">0</Field>
            </Object>
            <Object name="BoxAttributes">
                <Field name="amount" type="string">Some</Field>
                <Field name="minx" type="double">0</Field>
                <Field name="maxx" type="double">1</Field>
                <Field name="miny" type="double">0</Field>
                <Field name="maxy" type="double">1</Field>
                <Field name="minz" type="double">0</Field>
                <Field name="maxz" type="double">1</Field>
            </Object>
            <Object name="ClipAttributes">
                <Field name="quality" type="string">Fast</Field>
                <Field name="funcType" type="string">Plane</Field>
                <Field name="plane1Status" type="bool">true</Field>
                <Field name="plane2Status" type="bool">false</Field>
                <Field name="plane3Status" type="bool">false</Field>
                <Field name="plane1Origin" type="doubleArray" length="3">0 0 0 </Field>
                <Field name="plane2Origin" type="doubleArray" length="3">0 0 0 </Field>
                <Field name="plane3Origin" type="doubleArray" length="3">0 0 0 </Field>
                <Field name="plane1Normal" type="doubleArray" length="3">1 0 0 </Field>
                <Field name="plane2Normal" type="doubleArray" length="3">0 1 0 </Field>
                <Field name="plane3Normal" type="doubleArray" length="3">0 0 1 </Field>
                <Field name="planeInverse" type="bool">false</Field>
                <Field name="planeToolControlledClipPlane" type="string">Plane1</Field>
                <Field name="center" type="doubleArray" length="3">0 0 0 </Field>
                <Field name="radius" type="double">1</Field>
                <Field name="sphereInverse" type="bool">false</Field>
            </Object>
            <Object name="ConeAttributes">
                <Field name="angle" type="double">45</Field>
                <Field name="origin" type="doubleArray" length="3">0 0 0 </Field>
                <Field name="normal" type="doubleArray" length="3">0 0 1 </Field>
                <Field name="representation" type="string">Flattened</Field>
                <Field name="upAxis" type="doubleArray" length="3">0 1 0 </Field>
                <Field name="cutByLength" type="bool">false</Field>
                <Field name="length" type="double">1</Field>
            </Object>
            <Object name="CoordSwapAttributes">
                <Field name="newCoord1" type="string">Coord1</Field>
                <Field name="newCoord2" type="string">Coord2</Field>
                <Field name="newCoord3" type="string">Coord3</Field>
            </Object>
            <Object name="CreateBondsAttributes">
                <Field name="elementVariable" type="string">element</Field>
                <Field name="atomicNumber1" type="intVector">1 -1 </Field>
                <Field name="atomicNumber2" type="intVector">-1 -1 </Field>
                <Field name="minDist" type="doubleVector">0.4 0.4 </Field>
                <Field name="maxDist" type="doubleVector">1.2 1.9 </Field>
                <Field name="maxBondsClamp" type="int">10</Field>
                <Field name="addPeriodicBonds" type="bool">false</Field>
                <Field name="useUnitCellVectors" type="bool">true</Field>
                <Field name="periodicInX" type="bool">true</Field>
                <Field name="periodicInY" type="bool">true</Field>
                <Field name="periodicInZ" type="bool">true</Field>
                <Field name="xVector" type="doubleArray" length="3">1 0 0 </Field>
                <Field name="yVector" type="doubleArray" length="3">0 1 0 </Field>
                <Field name="zVector" type="doubleArray" length="3">0 0 1 </Field>
            </Object>
            <Object name="CylinderAttributes">
                <Field name="point1" type="doubleArray" length="3">0 0 0 </Field>
                <Field name="point2" type="doubleArray" length="3">1 0 0 </Field>
                <Field name="radius" type="double">1</Field>
            </Object>
            <Object name="DataBinningAttributes">
                <Field name="numDimensions" type="string">One</Field>
                <Field name="dim1BinBasedOn" type="string">Variable</Field>
                <Field name="dim1Var" type="string">default</Field>
                <Field name="dim1SpecifyRange" type="bool">false</Field>
                <Field name="dim1MinRange" type="double">0</Field>
                <Field name="dim1MaxRange" type="double">1</Field>
                <Field name="dim1NumBins" type="int">50</Field>
                <Field name="dim2BinBasedOn" type="string">Variable</Field>
                <Field name="dim2Var" type="string">default</Field>
                <Field name="dim2SpecifyRange" type="bool">false</Field>
                <Field name="dim2MinRange" type="double">0</Field>
                <Field name="dim2MaxRange" type="double">1</Field>
                <Field name="dim2NumBins" type="int">50</Field>
                <Field name="dim3BinBasedOn" type="string">Variable</Field>
                <Field name="dim3Var" type="string">default</Field>
                <Field name="dim3SpecifyRange" type="bool">false</Field>
                <Field name="dim3MinRange" type="double">0</Field>
                <Field name="dim3MaxRange" type="double">1</Field>
                <Field name="dim3NumBins" type="int">50</Field>
                <Field name="outOfBoundsBehavior" type="string">Clamp</Field>
                <Field name="reductionOperator" type="string">Average</Field>
                <Field name="varForReduction" type="string">default</Field>
                <Field name="emptyVal" type="double">0</Field>
            </Object>
            <Object name="DeferExpressionAttributes">
                <Field name="exprs" type="stringVector"></Field>
            </Object>
            <Object name="DisplaceAttributes">
                <Field name="factor" type="double">1</Field>
                <Field name="variable" type="string">default</Field>
            </Object>
            <Object name="DualMeshAttributes">
                <Field name="mode" type="string">Auto</Field>
            </Object>
            <Object name="EdgeAttributes">
                <Field name="dummy" type="bool">true</Field>
            </Object>
            <Object name="ElevateAttributes">
                <Field name="useXYLimits" type="bool">false</Field>
                <Field name="limitsMode" type="string">OriginalData</Field>
                <Field name="scaling" type="string">Linear</Field>
                <Field name="skewFactor" type="double">1</Field>
                <Field name="minFlag" type="bool">false</Field>
                <Field name="min" type="double">0</Field>
                <Field name="maxFlag" type="bool">false</Field>
                <Field name="max" type="double">1</Field>
                <Field name="zeroFlag" type="bool">false</Field>
                <Field name="variable" type="string">default</Field>
            </Object>
            <Object name="ExternalSurfaceAttributes">
                <Field name="removeGhosts" type="bool">false</Field>
                <Field name="edgesIn2D" type="bool">true</Field>
            </Object>
            <Object name="ExtrudeAttributes">
                <Field name="axis" type="doubleArray" length="3">0 0 1 </Field>
                <Field name="length" type="double">1</Field>
                <Field name="steps" type="int">30</Field>
                <Field name="preserveOriginalCellNumbers" type="bool">true</Field>
            </Object>
            <Object name="FFTAttributes">
                <Field name="dummy" type="int">0</Field>
            </Object>
            <Object name="IndexSelectAttributes">
                <Field name="maxDim" type="string">ThreeD</Field>
                <Field name="dim" type="string">TwoD</Field>
                <Field name="xAbsMax" type="int">-1</Field>
                <Field name="xMin" type="int">0</Field>
                <Field name="xMax" type="int">-1</Field>
                <Field name="xIncr" type="int">1</Field>
                <Field name="xWrap" type="bool">false</Field>
                <Field name="yAbsMax" type="int">-1</Field>
                <Field name="yMin" type="int">0</Field>
                <Field name="yMax" type="int">-1</Field>
                <Field name="yIncr" type="int">1</Field>
                <Field name="yWrap" type="bool">false</Field>
                <Field name="zAbsMax" type="int">-1</Field>
                <Field name="zMin" type="int">0</Field>
                <Field name="zMax" type="int">-1</Field>
                <Field name="zIncr" type="int">1</Field>
                <Field name="zWrap" type="bool">false</Field>
                <Field name="useWholeCollection" type="bool">true</Field>
                <Field name="categoryName" type="string">Whole</Field>
                <Field name="subsetName" type="string">Whole</Field>
            </Object>
            <Object name="InverseGhostZoneAttributes">
                <Field name="requestGhostZones" type="bool">true</Field>
                <Field name="showDuplicated" type="bool">true</Field>
                <Field name="showEnhancedConnectivity" type="bool">true</Field>
                <Field name="showReducedConnectivity" type="bool">true</Field>
                <Field name="showAMRRefined" type="bool">true</Field>
                <Field name="showExterior" type="bool">true</Field>
                <Field name="showNotApplicable" type="bool">true</Field>
            </Object>
            <Object name="IsosurfaceAttributes">
                <Field name="contourNLevels" type="int">10</Field>
                <Field name="contourValue" type="doubleVector"></Field>
                <Field name="contourPercent" type="doubleVector"></Field>
                <Field name="contourMethod" type="string">Level</Field>
                <Field name="minFlag" type="bool">false</Field>
                <Field name="min" type="double">0</Field>
                <Field name="maxFlag" type="bool">false</Field>
                <Field name="max" type="double">1</Field>
                <Field name="scaling" type="string">Linear</Field>
                <Field name="variable" type="string">default</Field>
            </Object>
            <Object name="IsovolumeAttributes">
                <Field name="lbound" type="double">-1e+37</Field>
                <Field name="ubound" type="double">1e+37</Field>
                <Field name="variable" type="string">default</Field>
            </Object>
            <Object name="LineoutAttributes">
                <Field name="point1" type="doubleArray" length="3">0 0 0 </Field>
                <Field name="point2" type="doubleArray" length="3">1 1 0 </Field>
                <Field name="interactive" type="bool">false</Field>
                <Field name="ignoreGlobal" type="bool">false</Field>
                <Field name="samplingOn" type="bool">false</Field>
                <Field name="numberOfSamplePoints" type="int">50</Field>
                <Field name="reflineLabels" type="bool">false</Field>
                <Field name="designator" type="string"></Field>
            </Object>
            <Object name="MultiresControlAttributes">
                <Field name="resolution" type="int">0</Field>
                <Field name="maxResolution" type="int">1</Field>
                <Field name="info" type="string"></Field>
            </Object>
            <Object name="OnionPeelAttributes">
                <Field name="adjacencyType" type="string">Node</Field>
                <Field name="useGlobalId" type="bool">false</Field>
                <Field name="categoryName" type="string">Whole</Field>
                <Field name="subsetName" type="string">Whole</Field>
                <Field name="index" type="intVector">1 </Field>
                <Field name="logical" type="bool">false</Field>
                <Field name="requestedLayer" type="int">0</Field>
                <Field name="seedType" type="string">SeedCell</Field>
            </Object>
            <Object name="PersistentParticlesAttributes">
                <Field name="startIndex" type="int">0</Field>
                <Field name="stopIndex" type="int">1</Field>
                <Field name="stride" type="int">1</Field>
                <Field name="startPathType" type="string">Absolute</Field>
                <Field name="stopPathType" type="string">Absolute</Field>
                <Field name="traceVariableX" type="string">default</Field>
                <Field name="traceVariableY" type="string">default</Field>
                <Field name="traceVariableZ" type="string">default</Field>
                <Field name="connectParticles" type="bool">false</Field>
                <Field name="showPoints" type="bool">false</Field>
                <Field name="indexVariable" type="string">default</Field>
            </Object>
            <Object name="ProjectAttributes">
                <Field name="projectionType" type="string">XYCartesian</Field>
                <Field name="vectorTransformMethod" type="string">AsDirection</Field>
            </Object>
            <Object name="ReflectAttributes">
                <Field name="octant" type="string">PXPYPZ</Field>
                <Field name="useXBoundary" type="bool">true</Field>
                <Field name="specifiedX" type="double">0</Field>
                <Field name="useYBoundary" type="bool">true</Field>
                <Field name="specifiedY" type="double">0</Field>
                <Field name="useZBoundary" type="bool">true</Field>
                <Field name="specifiedZ" type="double">0</Field>
                <Field name="reflections" type="intArray" length="8">1 0 1 0 0 0 0 0 </Field>
            </Object>
            <Object name="ReplicateAttributes">
                <Field name="useUnitCellVectors" type="bool">false</Field>
                <Field name="xVector" type="doubleArray" length="3">1 0 0 </Field>
                <Field name="yVector" type="doubleArray" length="3">0 1 0 </Field>
                <Field name="zVector" type="doubleArray" length="3">0 0 1 </Field>
                <Field name="xReplications" type="int">1</Field>
                <Field name="yReplications" type="int">1</Field>
                <Field name="zReplications" type="int">1</Field>
                <Field name="mergeResults" type="bool">true</Field>
                <Field name="replicateUnitCellAtoms" type="bool">false</Field>
                <Field name="shiftPeriodicAtomOrigin" type="bool">false</Field>
                <Field name="newPeriodicOrigin" type="doubleArray" length="3">0 0 0 </Field>
            </Object>
            <Object name="ResampleAttributes">
                <Field name="useExtents" type="bool">true</Field>
                <Field name="startX" type="double">0</Field>
                <Field name="endX" type="double">1</Field>
                <Field name="samplesX" type="int">10</Field>
                <Field name="startY" type="double">0</Field>
                <Field name="endY" type="double">1</Field>
                <Field name="samplesY" type="int">10</Field>
                <Field name="is3D" type="bool">true</Field>
                <Field name="startZ" type="double">0</Field>
                <Field name="endZ" type="double">1</Field>
                <Field name="samplesZ" type="int">10</Field>
                <Field name="tieResolver" type="string">random</Field>
                <Field name="tieResolverVariable" type="string">default</Field>
                <Field name="defaultValue" type="double">0</Field>
                <Field name="distributedResample" type="bool">true</Field>
                <Field name="cellCenteredOutput" type="bool">false</Field>
            </Object>
            <Object name="RevolveAttributes">
                <Field name="meshType" type="string">Auto</Field>
                <Field name="autoAxis" type="bool">true</Field>
                <Field name="axis" type="doubleArray" length="3">1 0 0 </Field>
                <Field name="startAngle" type="double">0</Field>
                <Field name="stopAngle" type="double">360</Field>
                <Field name="steps" type="int">30</Field>
            </Object>
            <Object name="SliceAttributes">
                <Field name="originType" type="string">Intercept</Field>
                <Field name="originPoint" type="doubleArray" length="3">0 0 0 </Field>
                <Field name="originIntercept" type="double">0</Field>
                <Field name="originPercent" type="double">0</Field>
                <Field name="originZone" type="int">0</Field>
                <Field name="originNode" type="int">0</Field>
                <Field name="normal" type="doubleArray" length="3">0 -1 0 </Field>
                <Field name="axisType" type="string">YAxis</Field>
                <Field name="upAxis" type="doubleArray" length="3">0 0 1 </Field>
                <Field name="project2d" type="bool">true</Field>
                <Field name="interactive" type="bool">true</Field>
                <Field name="flip" type="bool">false</Field>
                <Field name="originZoneDomain" type="int">0</Field>
                <Field name="originNodeDomain" type="int">0</Field>
                <Field name="meshName" type="string">default</Field>
                <Field name="theta" type="double">0</Field>
                <Field name="phi" type="double">0</Field>
            </Object>
            <Object name="SmoothOperatorAttributes">
                <Field name="numIterations" type="int">20</Field>
                <Field name="relaxationFactor" type="double">0.01</Field>
                <Field name="convergence" type="double">0</Field>
                <Field name="maintainFeatures" type="bool">true</Field>
                <Field name="featureAngle" type="double">45</Field>
                <Field name="edgeAngle" type="double">15</Field>
                <Field name="smoothBoundaries" type="bool">false</Field>
            </Object>
            <Object name="SphereSliceAttributes">
                <Field name="origin" type="doubleArray" length="3">0 0 0 </Field>
                <Field name="radius" type="double">1</Field>
            </Object>
            <Object name="ThreeSliceAttributes">
                <Field name="x" type="float">0</Field>
                <Field name="y" type="float">0</Field>
                <Field name="z" type="float">0</Field>
                <Field name="interactive" type="bool">true</Field>
            </Object>
            <Object name="ThresholdAttributes">
                <Field name="outputMeshType" type="int">0</Field>
                <Field name="listedVarNames" type="stringVector">"default" </Field>
                <Field name="zonePortions" type="intVector"></Field>
                <Field name="lowerBounds" type="doubleVector"></Field>
                <Field name="upperBounds" type="doubleVector"></Field>
                <Field name="defaultVarName" type="string">default</Field>
                <Field name="defaultVarIsScalar" type="bool">false</Field>
            </Object>
            <Object name="TransformAttributes">
                <Field name="doRotate" type="bool">false</Field>
                <Field name="rotateOrigin" type="floatArray" length="3">0 0 0 </Field>
                <Field name="rotateAxis" type="floatArray" length="3">0 0 1 </Field>
                <Field name="rotateAmount" type="float">0</Field>
                <Field name="rotateType" type="string">Deg</Field>
                <Field name="doScale" type="bool">false</Field>
                <Field name="scaleOrigin" type="floatArray" length="3">0 0 0 </Field>
                <Field name="scaleX" type="float">1</Field>
                <Field name="scaleY" type="float">1</Field>
                <Field name="scaleZ" type="float">1</Field>
                <Field name="doTranslate" type="bool">false</Field>
                <Field name="translateX" type="float">0</Field>
                <Field name="translateY" type="float">0</Field>
                <Field name="translateZ" type="float">0</Field>
                <Field name="transformType" type="string">Similarity</Field>
                <Field name="inputCoordSys" type="string">Cartesian</Field>
                <Field name="outputCoordSys" type="string">Spherical</Field>
                <Field name="m00" type="double">1</Field>
                <Field name="m01" type="double">0</Field>
                <Field name="m02" type="double">0</Field>
                <Field name="m03" type="double">0</Field>
                <Field name="m10" type="double">0</Field>
                <Field name="m11" type="double">1</Field>
                <Field name="m12" type="double">0</Field>
                <Field name="m13" type="double">0</Field>
                <Field name="m20" type="double">0</Field>
                <Field name="m21" type="double">0</Field>
                <Field name="m22" type="double">1</Field>
                <Field name="m23" type="double">0</Field>
                <Field name="m30" type="double">0</Field>
                <Field name="m31" type="double">0</Field>
                <Field name="m32" type="double">0</Field>
                <Field name="m33" type="double">1</Field>
                <Field name="invertLinearTransform" type="bool">false</Field>
                <Field name="vectorTransformMethod" type="string">AsDirection</Field>
                <Field name="transformVectors" type="bool">true</Field>
            </Object>
            <Object name="TriangulateRegularPointsAttributes">
                <Field name="useXGridSpacing" type="bool">false</Field>
                <Field name="xGridSpacing" type="double">1</Field>
                <Field name="useYGridSpacing" type="bool">false</Field>
                <Field name="yGridSpacing" type="double">1</Field>
            </Object>
            <Object name="TubeAttributes">
                <Field name="scaleByVarFlag" type="bool">false</Field>
                <Field name="tubeRadiusType" type="string">FractionOfBBox</Field>
                <Field name="radiusFractionBBox" type="double">0.01</Field>
                <Field name="radiusAbsolute" type="double">1</Field>
                <Field name="scaleVariable" type="string">default</Field>
                <Field name="fineness" type="int">5</Field>
                <Field name="capping" type="bool">false</Field>
            </Object>
            <Object name="AppearanceAttributes">
                <Field name="useSystemDefault" type="bool">true</Field>
                <Field name="background" type="string">#c0c0c0</Field>
                <Field name="foreground" type="string">#000000</Field>
                <Field name="fontName" type="string">Helvetica,12,-1,5,50,0,0,0,0,0</Field>
                <Field name="style" type="string">macintosh</Field>
                <Field name="orientation" type="int">0</Field>
                <Field name="defaultForeground" type="string">#000000</Field>
                <Field name="defaultBackground" type="string">#e8e8e8</Field>
                <Field name="defaultFontName" type="string">"Lucida Grande,13,-1,5,50,0,0,0,0,0"</Field>
                <Field name="defaultStyle" type="string">macintosh</Field>
                <Field name="defaultOrientation" type="int">0</Field>
            </Object>
            <Object name="PluginManagerAttributes">
                <Field name="name" type="stringVector">"Boundary" "Contour" "Curve" "FilledBoundary" "Histogram" "Label" "Mesh" "Molecule" "MultiCurve" "ParallelCoordinates" "Poincare" "Pseudocolor" "Scatter" "Spreadsheet" "Streamline" "Subset" "Surface" "Tensor" "Truecolor" "Vector" "Volume" "WellBore" "AMRStitchCell" "BoundaryOp" "Box" "Clip" "Cone" "ConnectedComponents" "CoordSwap" "CracksClipper" "CreateBonds" "Cylinder" "DataBinning" "Decimate" "DeferExpression" "Delaunay" "Displace" "DualMesh" "Edge" "Elevate" "ExternalSurface" "Extrude" "FFT" "FiveFoldTetSubdivision" "Flux" "IndexSelect" "InverseGhostZone" "Isosurface" "Isovolume" "LineSampler" "Lineout" "Merge" "MultiresControl" "OnionPeel" "PDF" "PersistentParticles" "Project" "Reflect" "Replicate" "Resample" "Revolve" "Slice" "Smooth" "SphereSlice" "SurfaceNormal" "ThreeSlice" "Threshold" "ToroidalPoloidalProjection" "Transform" "TriangulateRegularPoints" "Tube" "ZoneDump" </Field>
                <Field name="type" type="stringVector">"plot" "plot" "plot" "plot" "plot" "plot" "plot" "plot" "plot" "plot" "plot" "plot" "plot" "plot" "plot" "plot" "plot" "plot" "plot" "plot" "plot" "plot" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" "operator" </Field>
                <Field name="version" type="stringVector">"1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "2.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.1" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "2.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" "1.0" </Field>
                <Field name="id" type="stringVector">"Boundary_1.0" "Contour_1.0" "Curve_1.0" "FilledBoundary_1.0" "Histogram_1.0" "Label_1.0" "Mesh_1.0" "Molecule_1.0" "MultiCurve_1.0" "ParallelCoordinates_1.0" "Poincare_2.0" "Pseudocolor_1.0" "Scatter_1.0" "Spreadsheet_1.0" "Streamline_1.0" "Subset_1.0" "Surface_1.0" "Tensor_1.0" "Truecolor_1.0" "Vector_1.0" "Volume_1.1" "WellBore_1.0" "AMRStitchCell_1.0" "BoundaryOp_1.0" "Box_1.0" "Clip_1.0" "Cone_1.0" "ConnectedComponents_1.0" "CoordSwap_1.0" "CracksClipper_1.0" "CreateBonds_1.0" "Cylinder_1.0" "DataBinning_1.0" "Decimate_1.0" "DeferExpression_1.0" "Delaunay_1.0" "Displace_1.0" "DualMesh_1.0" "Edge_1.0" "Elevate_1.0" "ExternalSurface_1.0" "Extrude_1.0" "FFT_1.0" "FiveFoldTetSubdivision_1.0" "Flux_1.0" "IndexSelect_1.0" "InverseGhostZone_1.0" "Isosurface_1.0" "Isovolume_1.0" "LineSampler_1.0" "Lineout_1.0" "Merge_1.0" "MultiresControl_1.0" "OnionPeel_1.0" "PDF_1.0" "PersistentParticles_2.0" "Project_1.0" "Reflect_1.0" "Replicate_1.0" "Resample_1.0" "Revolve_1.0" "Slice_1.0" "Smooth_1.0" "SphereSlice_1.0" "SurfaceNormal_1.0" "ThreeSlice_1.0" "Threshold_1.0" "ToroidalPoloidalProjection_1.0" "Transform_1.0" "TriangulateRegularPoints_1.0" "Tube_1.0" "ZoneDump_1.0" </Field>
                <Field name="category" type="stringVector">"?" "?" "?" "?" "?" "?" "?" "?" "?" "?" "?" "?" "?" "?" "?" "?" "?" "?" "?" "?" "?" "?" "Geometry" "Slicing" "Selection" "Selection" "Slicing" "Analysis" "Geometry" "Analysis" "Molecular" "Selection" "Analysis" "Geometry" "Analysis" "Geometry" "Transforms" "Geometry" "Geometry" "Transforms" "Geometry" "Geometry" "Transforms" "Geometry" "Analysis" "Selection" "Debugging" "Slicing" "Selection" "Slicing" "Analysis" "Geometry" "Selection" "Selection" "Analysis" "Analysis" "Transforms" "Transforms" "Transforms" "Geometry" "Geometry" "Slicing" "Geometry" "Slicing" "Geometry" "Slicing" "Selection" "Transforms" "Transforms" "Geometry" "Geometry" "Debugging" </Field>
                <Field name="enabled" type="intVector">1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 0 1 1 1 1 0 0 1 1 1 1 1 1 0 1 1 1 0 1 0 1 1 1 1 1 1 1 0 1 1 1 1 1 0 1 0 1 1 0 1 1 1 1 1 1 1 1 1 1 1 1 0 1 1 1 0 </Field>
            </Object>
        </Object>
        <Object name="ViewerSubject">
            <Object name="SourceMap">
};
print OUT "                <Field name=\"SOURCE00\" type=\"string\">\"localhost:$dpath/silo_* database\"</Field>
            </Object>
            <Object name=\"SourcePlugins\">
                <Field name=\"localhost:$dpath/silo_* database\" type=\"string\">Silo_1.0</Field>
";
print OUT q{            </Object>
            <Object name="DatabaseCorrelationList">
                <Field name="needPermission" type="bool">true</Field>
                <Field name="defaultCorrelationMethod" type="int">0</Field>
                <Field name="whenToCorrelate" type="string">CorrelateOnlyIfSameLength</Field>
            </Object>
            <Object name="ViewerWindowManager">
                <Object name="SelectionList">
                    <Field name="autoApplyUpdates" type="bool">false</Field>
                </Object>
                <Field name="activeWindow" type="int">0</Field>
                <Field name="lineoutWindow" type="int">-1</Field>
                <Field name="timeQueryWindow" type="int">-1</Field>
                <Field name="cameraView" type="bool">false</Field>
                <Field name="viewExtentsType" type="string">AVT_ORIGINAL_EXTENTS</Field>
                <Object name="Windows">
                    <Object name="ViewerWindow">
                        <Field name="windowSize" type="intArray" length="2">856 856 </Field>
                        <Field name="windowImageSize" type="intArray" length="2">856 792 </Field>
                        <Field name="windowLocation" type="intArray" length="2">414 22 </Field>
                        <Field name="cameraView" type="bool">false</Field>
                        <Field name="maintainView" type="bool">false</Field>
                        <Field name="viewExtentsType" type="string">AVT_ORIGINAL_EXTENTS</Field>
                        <Field name="viewIsLocked" type="bool">false</Field>
                        <Field name="timeLocked" type="bool">false</Field>
                        <Field name="toolsLocked" type="bool">false</Field>
                        <Field name="interactionMode" type="string">NAVIGATE</Field>
                        <Field name="toolUpdateMode" type="string">ONRELEASE</Field>
                        <Object name="AnnotationAttributes">
                            <Object name="axes2D">
                                <Object name="Axes2D">
                                    <Field name="visible" type="bool">true</Field>
                                    <Field name="autoSetTicks" type="bool">true</Field>
                                    <Field name="autoSetScaling" type="bool">true</Field>
                                    <Field name="lineWidth" type="int">0</Field>
                                    <Field name="tickLocation" type="string">Outside</Field>
                                    <Field name="tickAxes" type="string">BottomLeft</Field>
                                    <Object name="xAxis">
                                        <Object name="AxisAttributes">
                                            <Object name="title">
                                                <Object name="AxisTitles">
                                                    <Field name="visible" type="bool">true</Field>
                                                    <Object name="font">
                                                        <Object name="FontAttributes">
                                                            <Field name="font" type="string">Courier</Field>
                                                            <Field name="scale" type="double">1</Field>
                                                            <Field name="useForegroundColor" type="bool">true</Field>
                                                            <Object name="color">
                                                                <Object name="ColorAttribute">
                                                                    <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                                                                </Object>
                                                            </Object>
                                                            <Field name="bold" type="bool">true</Field>
                                                            <Field name="italic" type="bool">true</Field>
                                                        </Object>
                                                    </Object>
                                                    <Field name="userTitle" type="bool">false</Field>
                                                    <Field name="userUnits" type="bool">false</Field>
                                                    <Field name="title" type="string">X-Axis</Field>
                                                    <Field name="units" type="string"></Field>
                                                </Object>
                                            </Object>
                                            <Object name="label">
                                                <Object name="AxisLabels">
                                                    <Field name="visible" type="bool">true</Field>
                                                    <Object name="font">
                                                        <Object name="FontAttributes">
                                                            <Field name="font" type="string">Courier</Field>
                                                            <Field name="scale" type="double">1</Field>
                                                            <Field name="useForegroundColor" type="bool">true</Field>
                                                            <Object name="color">
                                                                <Object name="ColorAttribute">
                                                                    <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                                                                </Object>
                                                            </Object>
                                                            <Field name="bold" type="bool">true</Field>
                                                            <Field name="italic" type="bool">true</Field>
                                                        </Object>
                                                    </Object>
                                                    <Field name="scaling" type="int">0</Field>
                                                </Object>
                                            </Object>
                                            <Object name="tickMarks">
                                                <Object name="AxisTickMarks">
                                                    <Field name="visible" type="bool">true</Field>
                                                    <Field name="majorMinimum" type="double">0</Field>
                                                    <Field name="majorMaximum" type="double">1</Field>
                                                    <Field name="minorSpacing" type="double">0.02</Field>
                                                    <Field name="majorSpacing" type="double">0.2</Field>
                                                </Object>
                                            </Object>
                                            <Field name="grid" type="bool">false</Field>
                                        </Object>
                                    </Object>
                                    <Object name="yAxis">
                                        <Object name="AxisAttributes">
                                            <Object name="title">
                                                <Object name="AxisTitles">
                                                    <Field name="visible" type="bool">true</Field>
                                                    <Object name="font">
                                                        <Object name="FontAttributes">
                                                            <Field name="font" type="string">Courier</Field>
                                                            <Field name="scale" type="double">1</Field>
                                                            <Field name="useForegroundColor" type="bool">true</Field>
                                                            <Object name="color">
                                                                <Object name="ColorAttribute">
                                                                    <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                                                                </Object>
                                                            </Object>
                                                            <Field name="bold" type="bool">true</Field>
                                                            <Field name="italic" type="bool">true</Field>
                                                        </Object>
                                                    </Object>
                                                    <Field name="userTitle" type="bool">false</Field>
                                                    <Field name="userUnits" type="bool">false</Field>
                                                    <Field name="title" type="string">Y-Axis</Field>
                                                    <Field name="units" type="string"></Field>
                                                </Object>
                                            </Object>
                                            <Object name="label">
                                                <Object name="AxisLabels">
                                                    <Field name="visible" type="bool">true</Field>
                                                    <Object name="font">
                                                        <Object name="FontAttributes">
                                                            <Field name="font" type="string">Courier</Field>
                                                            <Field name="scale" type="double">1</Field>
                                                            <Field name="useForegroundColor" type="bool">true</Field>
                                                            <Object name="color">
                                                                <Object name="ColorAttribute">
                                                                    <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                                                                </Object>
                                                            </Object>
                                                            <Field name="bold" type="bool">true</Field>
                                                            <Field name="italic" type="bool">true</Field>
                                                        </Object>
                                                    </Object>
                                                    <Field name="scaling" type="int">0</Field>
                                                </Object>
                                            </Object>
                                            <Object name="tickMarks">
                                                <Object name="AxisTickMarks">
                                                    <Field name="visible" type="bool">true</Field>
                                                    <Field name="majorMinimum" type="double">0</Field>
                                                    <Field name="majorMaximum" type="double">1</Field>
                                                    <Field name="minorSpacing" type="double">0.02</Field>
                                                    <Field name="majorSpacing" type="double">0.2</Field>
                                                </Object>
                                            </Object>
                                            <Field name="grid" type="bool">false</Field>
                                        </Object>
                                    </Object>
                                </Object>
                            </Object>
                            <Object name="axes3D">
                                <Object name="Axes3D">
                                    <Field name="visible" type="bool">true</Field>
                                    <Field name="autoSetTicks" type="bool">true</Field>
                                    <Field name="autoSetScaling" type="bool">true</Field>
                                    <Field name="lineWidth" type="int">0</Field>
                                    <Field name="tickLocation" type="string">Inside</Field>
                                    <Field name="axesType" type="string">ClosestTriad</Field>
                                    <Field name="triadFlag" type="bool">true</Field>
                                    <Field name="bboxFlag" type="bool">true</Field>
                                    <Object name="xAxis">
                                        <Object name="AxisAttributes">
                                            <Object name="title">
                                                <Object name="AxisTitles">
                                                    <Field name="visible" type="bool">true</Field>
                                                    <Object name="font">
                                                        <Object name="FontAttributes">
                                                            <Field name="font" type="string">Arial</Field>
                                                            <Field name="scale" type="double">1</Field>
                                                            <Field name="useForegroundColor" type="bool">true</Field>
                                                            <Object name="color">
                                                                <Object name="ColorAttribute">
                                                                    <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                                                                </Object>
                                                            </Object>
                                                            <Field name="bold" type="bool">false</Field>
                                                            <Field name="italic" type="bool">false</Field>
                                                        </Object>
                                                    </Object>
                                                    <Field name="userTitle" type="bool">false</Field>
                                                    <Field name="userUnits" type="bool">false</Field>
                                                    <Field name="title" type="string">X-Axis</Field>
                                                    <Field name="units" type="string"></Field>
                                                </Object>
                                            </Object>
                                            <Object name="label">
                                                <Object name="AxisLabels">
                                                    <Field name="visible" type="bool">true</Field>
                                                    <Object name="font">
                                                        <Object name="FontAttributes">
                                                            <Field name="font" type="string">Arial</Field>
                                                            <Field name="scale" type="double">1</Field>
                                                            <Field name="useForegroundColor" type="bool">true</Field>
                                                            <Object name="color">
                                                                <Object name="ColorAttribute">
                                                                    <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                                                                </Object>
                                                            </Object>
                                                            <Field name="bold" type="bool">false</Field>
                                                            <Field name="italic" type="bool">false</Field>
                                                        </Object>
                                                    </Object>
                                                    <Field name="scaling" type="int">0</Field>
                                                </Object>
                                            </Object>
                                            <Object name="tickMarks">
                                                <Object name="AxisTickMarks">
                                                    <Field name="visible" type="bool">true</Field>
                                                    <Field name="majorMinimum" type="double">0</Field>
                                                    <Field name="majorMaximum" type="double">1</Field>
                                                    <Field name="minorSpacing" type="double">0.02</Field>
                                                    <Field name="majorSpacing" type="double">0.2</Field>
                                                </Object>
                                            </Object>
                                            <Field name="grid" type="bool">false</Field>
                                        </Object>
                                    </Object>
                                    <Object name="yAxis">
                                        <Object name="AxisAttributes">
                                            <Object name="title">
                                                <Object name="AxisTitles">
                                                    <Field name="visible" type="bool">true</Field>
                                                    <Object name="font">
                                                        <Object name="FontAttributes">
                                                            <Field name="font" type="string">Arial</Field>
                                                            <Field name="scale" type="double">1</Field>
                                                            <Field name="useForegroundColor" type="bool">true</Field>
                                                            <Object name="color">
                                                                <Object name="ColorAttribute">
                                                                    <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                                                                </Object>
                                                            </Object>
                                                            <Field name="bold" type="bool">false</Field>
                                                            <Field name="italic" type="bool">false</Field>
                                                        </Object>
                                                    </Object>
                                                    <Field name="userTitle" type="bool">false</Field>
                                                    <Field name="userUnits" type="bool">false</Field>
                                                    <Field name="title" type="string">Y-Axis</Field>
                                                    <Field name="units" type="string"></Field>
                                                </Object>
                                            </Object>
                                            <Object name="label">
                                                <Object name="AxisLabels">
                                                    <Field name="visible" type="bool">true</Field>
                                                    <Object name="font">
                                                        <Object name="FontAttributes">
                                                            <Field name="font" type="string">Arial</Field>
                                                            <Field name="scale" type="double">1</Field>
                                                            <Field name="useForegroundColor" type="bool">true</Field>
                                                            <Object name="color">
                                                                <Object name="ColorAttribute">
                                                                    <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                                                                </Object>
                                                            </Object>
                                                            <Field name="bold" type="bool">false</Field>
                                                            <Field name="italic" type="bool">false</Field>
                                                        </Object>
                                                    </Object>
                                                    <Field name="scaling" type="int">0</Field>
                                                </Object>
                                            </Object>
                                            <Object name="tickMarks">
                                                <Object name="AxisTickMarks">
                                                    <Field name="visible" type="bool">true</Field>
                                                    <Field name="majorMinimum" type="double">0</Field>
                                                    <Field name="majorMaximum" type="double">1</Field>
                                                    <Field name="minorSpacing" type="double">0.02</Field>
                                                    <Field name="majorSpacing" type="double">0.2</Field>
                                                </Object>
                                            </Object>
                                            <Field name="grid" type="bool">false</Field>
                                        </Object>
                                    </Object>
                                    <Object name="zAxis">
                                        <Object name="AxisAttributes">
                                            <Object name="title">
                                                <Object name="AxisTitles">
                                                    <Field name="visible" type="bool">true</Field>
                                                    <Object name="font">
                                                        <Object name="FontAttributes">
                                                            <Field name="font" type="string">Arial</Field>
                                                            <Field name="scale" type="double">1</Field>
                                                            <Field name="useForegroundColor" type="bool">true</Field>
                                                            <Object name="color">
                                                                <Object name="ColorAttribute">
                                                                    <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                                                                </Object>
                                                            </Object>
                                                            <Field name="bold" type="bool">false</Field>
                                                            <Field name="italic" type="bool">false</Field>
                                                        </Object>
                                                    </Object>
                                                    <Field name="userTitle" type="bool">false</Field>
                                                    <Field name="userUnits" type="bool">false</Field>
                                                    <Field name="title" type="string">Z-Axis</Field>
                                                    <Field name="units" type="string"></Field>
                                                </Object>
                                            </Object>
                                            <Object name="label">
                                                <Object name="AxisLabels">
                                                    <Field name="visible" type="bool">true</Field>
                                                    <Object name="font">
                                                        <Object name="FontAttributes">
                                                            <Field name="font" type="string">Arial</Field>
                                                            <Field name="scale" type="double">1</Field>
                                                            <Field name="useForegroundColor" type="bool">true</Field>
                                                            <Object name="color">
                                                                <Object name="ColorAttribute">
                                                                    <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                                                                </Object>
                                                            </Object>
                                                            <Field name="bold" type="bool">false</Field>
                                                            <Field name="italic" type="bool">false</Field>
                                                        </Object>
                                                    </Object>
                                                    <Field name="scaling" type="int">0</Field>
                                                </Object>
                                            </Object>
                                            <Object name="tickMarks">
                                                <Object name="AxisTickMarks">
                                                    <Field name="visible" type="bool">true</Field>
                                                    <Field name="majorMinimum" type="double">0</Field>
                                                    <Field name="majorMaximum" type="double">1</Field>
                                                    <Field name="minorSpacing" type="double">0.02</Field>
                                                    <Field name="majorSpacing" type="double">0.2</Field>
                                                </Object>
                                            </Object>
                                            <Field name="grid" type="bool">false</Field>
                                        </Object>
                                    </Object>
                                    <Field name="setBBoxLocation" type="bool">false</Field>
                                    <Field name="bboxLocation" type="doubleArray" length="6">0 1 0 1 0 1 </Field>
                                </Object>
                            </Object>
                            <Field name="userInfoFlag" type="bool">true</Field>
                            <Object name="userInfoFont">
                                <Object name="FontAttributes">
                                    <Field name="font" type="string">Arial</Field>
                                    <Field name="scale" type="double">1</Field>
                                    <Field name="useForegroundColor" type="bool">true</Field>
                                    <Object name="color">
                                        <Object name="ColorAttribute">
                                            <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                                        </Object>
                                    </Object>
                                    <Field name="bold" type="bool">false</Field>
                                    <Field name="italic" type="bool">false</Field>
                                </Object>
                            </Object>
                            <Field name="databaseInfoFlag" type="bool">true</Field>
                            <Field name="timeInfoFlag" type="bool">true</Field>
                            <Object name="databaseInfoFont">
                                <Object name="FontAttributes">
                                    <Field name="font" type="string">Arial</Field>
                                    <Field name="scale" type="double">1</Field>
                                    <Field name="useForegroundColor" type="bool">true</Field>
                                    <Object name="color">
                                        <Object name="ColorAttribute">
                                            <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                                        </Object>
                                    </Object>
                                    <Field name="bold" type="bool">false</Field>
                                    <Field name="italic" type="bool">false</Field>
                                </Object>
                            </Object>
                            <Field name="databaseInfoExpansionMode" type="string">File</Field>
                            <Field name="databaseInfoTimeScale" type="double">1</Field>
                            <Field name="databaseInfoTimeOffset" type="double">0</Field>
                            <Field name="legendInfoFlag" type="bool">true</Field>
                            <Object name="backgroundColor">
                                <Object name="ColorAttribute">
                                    <Field name="color" type="unsignedCharArray" length="4">255 255 255 255 </Field>
                                </Object>
                            </Object>
                            <Object name="foregroundColor">
                                <Object name="ColorAttribute">
                                    <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                                </Object>
                            </Object>
                            <Field name="gradientBackgroundStyle" type="string">Radial</Field>
                            <Object name="gradientColor1">
                                <Object name="ColorAttribute">
                                    <Field name="color" type="unsignedCharArray" length="4">0 0 255 255 </Field>
                                </Object>
                            </Object>
                            <Object name="gradientColor2">
                                <Object name="ColorAttribute">
                                    <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                                </Object>
                            </Object>
                            <Field name="backgroundMode" type="string">Solid</Field>
                            <Field name="backgroundImage" type="string"></Field>
                            <Field name="imageRepeatX" type="int">1</Field>
                            <Field name="imageRepeatY" type="int">1</Field>
                            <Object name="axesArray">
                                <Object name="AxesArray">
                                    <Field name="visible" type="bool">true</Field>
                                    <Field name="ticksVisible" type="bool">true</Field>
                                    <Field name="autoSetTicks" type="bool">true</Field>
                                    <Field name="autoSetScaling" type="bool">true</Field>
                                    <Field name="lineWidth" type="int">0</Field>
                                    <Object name="axes">
                                        <Object name="AxisAttributes">
                                            <Object name="title">
                                                <Object name="AxisTitles">
                                                    <Field name="visible" type="bool">true</Field>
                                                    <Object name="font">
                                                        <Object name="FontAttributes">
                                                            <Field name="font" type="string">Arial</Field>
                                                            <Field name="scale" type="double">1</Field>
                                                            <Field name="useForegroundColor" type="bool">true</Field>
                                                            <Object name="color">
                                                                <Object name="ColorAttribute">
                                                                    <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                                                                </Object>
                                                            </Object>
                                                            <Field name="bold" type="bool">false</Field>
                                                            <Field name="italic" type="bool">false</Field>
                                                        </Object>
                                                    </Object>
                                                    <Field name="userTitle" type="bool">false</Field>
                                                    <Field name="userUnits" type="bool">false</Field>
                                                    <Field name="title" type="string"></Field>
                                                    <Field name="units" type="string"></Field>
                                                </Object>
                                            </Object>
                                            <Object name="label">
                                                <Object name="AxisLabels">
                                                    <Field name="visible" type="bool">true</Field>
                                                    <Object name="font">
                                                        <Object name="FontAttributes">
                                                            <Field name="font" type="string">Arial</Field>
                                                            <Field name="scale" type="double">1</Field>
                                                            <Field name="useForegroundColor" type="bool">true</Field>
                                                            <Object name="color">
                                                                <Object name="ColorAttribute">
                                                                    <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                                                                </Object>
                                                            </Object>
                                                            <Field name="bold" type="bool">false</Field>
                                                            <Field name="italic" type="bool">false</Field>
                                                        </Object>
                                                    </Object>
                                                    <Field name="scaling" type="int">0</Field>
                                                </Object>
                                            </Object>
                                            <Object name="tickMarks">
                                                <Object name="AxisTickMarks">
                                                    <Field name="visible" type="bool">true</Field>
                                                    <Field name="majorMinimum" type="double">0</Field>
                                                    <Field name="majorMaximum" type="double">1</Field>
                                                    <Field name="minorSpacing" type="double">0.02</Field>
                                                    <Field name="majorSpacing" type="double">0.2</Field>
                                                </Object>
                                            </Object>
                                            <Field name="grid" type="bool">false</Field>
                                        </Object>
                                    </Object>
                                </Object>
                            </Object>
                        </Object>
                        <Object name="LightList">
                            <Object name="light0">
                                <Object name="LightAttributes">
                                    <Field name="enabledFlagCanBeToggled" type="bool">false</Field>
                                    <Field name="enabledFlag" type="bool">true</Field>
                                    <Field name="type" type="string">Camera</Field>
                                    <Field name="direction" type="doubleArray" length="3">0 0 -1 </Field>
                                    <Object name="color">
                                        <Object name="ColorAttribute">
                                            <Field name="color" type="unsignedCharArray" length="4">255 255 255 255 </Field>
                                        </Object>
                                    </Object>
                                    <Field name="brightness" type="double">1</Field>
                                </Object>
                            </Object>
                            <Object name="light1">
                                <Object name="LightAttributes">
                                    <Field name="enabledFlagCanBeToggled" type="bool">true</Field>
                                    <Field name="enabledFlag" type="bool">false</Field>
                                    <Field name="type" type="string">Camera</Field>
                                    <Field name="direction" type="doubleArray" length="3">0 0 -1 </Field>
                                    <Object name="color">
                                        <Object name="ColorAttribute">
                                            <Field name="color" type="unsignedCharArray" length="4">255 255 255 255 </Field>
                                        </Object>
                                    </Object>
                                    <Field name="brightness" type="double">1</Field>
                                </Object>
                            </Object>
                            <Object name="light2">
                                <Object name="LightAttributes">
                                    <Field name="enabledFlagCanBeToggled" type="bool">true</Field>
                                    <Field name="enabledFlag" type="bool">false</Field>
                                    <Field name="type" type="string">Camera</Field>
                                    <Field name="direction" type="doubleArray" length="3">0 0 -1 </Field>
                                    <Object name="color">
                                        <Object name="ColorAttribute">
                                            <Field name="color" type="unsignedCharArray" length="4">255 255 255 255 </Field>
                                        </Object>
                                    </Object>
                                    <Field name="brightness" type="double">1</Field>
                                </Object>
                            </Object>
                            <Object name="light3">
                                <Object name="LightAttributes">
                                    <Field name="enabledFlagCanBeToggled" type="bool">true</Field>
                                    <Field name="enabledFlag" type="bool">false</Field>
                                    <Field name="type" type="string">Camera</Field>
                                    <Field name="direction" type="doubleArray" length="3">0 0 -1 </Field>
                                    <Object name="color">
                                        <Object name="ColorAttribute">
                                            <Field name="color" type="unsignedCharArray" length="4">255 255 255 255 </Field>
                                        </Object>
                                    </Object>
                                    <Field name="brightness" type="double">1</Field>
                                </Object>
                            </Object>
                            <Object name="light4">
                                <Object name="LightAttributes">
                                    <Field name="enabledFlagCanBeToggled" type="bool">true</Field>
                                    <Field name="enabledFlag" type="bool">false</Field>
                                    <Field name="type" type="string">Camera</Field>
                                    <Field name="direction" type="doubleArray" length="3">0 0 -1 </Field>
                                    <Object name="color">
                                        <Object name="ColorAttribute">
                                            <Field name="color" type="unsignedCharArray" length="4">255 255 255 255 </Field>
                                        </Object>
                                    </Object>
                                    <Field name="brightness" type="double">1</Field>
                                </Object>
                            </Object>
                            <Object name="light5">
                                <Object name="LightAttributes">
                                    <Field name="enabledFlagCanBeToggled" type="bool">true</Field>
                                    <Field name="enabledFlag" type="bool">false</Field>
                                    <Field name="type" type="string">Camera</Field>
                                    <Field name="direction" type="doubleArray" length="3">0 0 -1 </Field>
                                    <Object name="color">
                                        <Object name="ColorAttribute">
                                            <Field name="color" type="unsignedCharArray" length="4">255 255 255 255 </Field>
                                        </Object>
                                    </Object>
                                    <Field name="brightness" type="double">1</Field>
                                </Object>
                            </Object>
                            <Object name="light6">
                                <Object name="LightAttributes">
                                    <Field name="enabledFlagCanBeToggled" type="bool">true</Field>
                                    <Field name="enabledFlag" type="bool">false</Field>
                                    <Field name="type" type="string">Camera</Field>
                                    <Field name="direction" type="doubleArray" length="3">0 0 -1 </Field>
                                    <Object name="color">
                                        <Object name="ColorAttribute">
                                            <Field name="color" type="unsignedCharArray" length="4">255 255 255 255 </Field>
                                        </Object>
                                    </Object>
                                    <Field name="brightness" type="double">1</Field>
                                </Object>
                            </Object>
                            <Object name="light7">
                                <Object name="LightAttributes">
                                    <Field name="enabledFlagCanBeToggled" type="bool">true</Field>
                                    <Field name="enabledFlag" type="bool">false</Field>
                                    <Field name="type" type="string">Camera</Field>
                                    <Field name="direction" type="doubleArray" length="3">0 0 -1 </Field>
                                    <Object name="color">
                                        <Object name="ColorAttribute">
                                            <Field name="color" type="unsignedCharArray" length="4">255 255 255 255 </Field>
                                        </Object>
                                    </Object>
                                    <Field name="brightness" type="double">1</Field>
                                </Object>
                            </Object>
                        </Object>
                        <Field name="scalableAutoThreshold" type="int">2000000</Field>
                        <Field name="scalableActivationMode" type="int">2</Field>
                        <Field name="compactDomainsAutoThreshold" type="int">256</Field>
                        <Field name="compactDomainsActivationMode" type="int">2</Field>
                        <Field name="notifyForEachRender" type="bool">false</Field>
                        <Field name="surfaceRepresentation" type="int">0</Field>
                        <Field name="displayListMode" type="int">2</Field>
                        <Field name="stereoRendering" type="bool">false</Field>
                        <Field name="stereoType" type="int">2</Field>
                        <Field name="antialiasing" type="bool">false</Field>
                        <Field name="multiresolutionMode" type="bool">false</Field>
                        <Field name="multiresolutionCellSize" type="double">0.002</Field>
                        <Field name="specularFlag" type="bool">false</Field>
                        <Field name="specularCoeff" type="double">0.6</Field>
                        <Field name="specularPower" type="double">10</Field>
                        <Object name="specularColor">
                            <Object name="ColorAttribute">
                                <Field name="color" type="unsignedCharArray" length="4">255 255 255 255 </Field>
                            </Object>
                        </Object>
                        <Field name="doShading" type="bool">false</Field>
                        <Field name="shadingStrength" type="double">0.5</Field>
                        <Field name="doDepthCueing" type="bool">false</Field>
                        <Field name="depthCueingAuto" type="bool">true</Field>
                        <Field name="startCuePoint" type="doubleArray" length="3">-10 0 0 </Field>
                        <Field name="endCuePoint" type="doubleArray" length="3">10 0 0 </Field>
                        <Field name="colorTexturingFlag" type="bool">true</Field>
                        <Object name="ViewCurveAttributes">
                            <Field name="domainCoords" type="doubleArray" length="2">0 1 </Field>
                            <Field name="rangeCoords" type="doubleArray" length="2">0 1 </Field>
                            <Field name="viewportCoords" type="doubleArray" length="4">0.2 0.95 0.15 0.95 </Field>
                            <Field name="domainScale" type="int">0</Field>
                            <Field name="rangeScale" type="int">0</Field>
                        </Object>
                        <Object name="View2DAttributes">
                            <Field name="windowCoords" type="doubleArray" length="4">0 1 0 1 </Field>
                            <Field name="viewportCoords" type="doubleArray" length="4">0.2 0.95 0.15 0.95 </Field>
                            <Field name="fullFrameActivationMode" type="string">Auto</Field>
                            <Field name="fullFrameAutoThreshold" type="double">100</Field>
                            <Field name="xScale" type="int">0</Field>
                            <Field name="yScale" type="int">0</Field>
                            <Field name="windowValid" type="bool">false</Field>
                        </Object>
                        <Object name="View3DAttributes">
                            <Field name="viewNormal" type="doubleArray" length="3">0 0 1 </Field>
                            <Field name="focus" type="doubleArray" length="3">14.8 7.1 0 </Field>
                            <Field name="viewUp" type="doubleArray" length="3">0 1 0 </Field>
                            <Field name="viewAngle" type="double">30</Field>
                            <Field name="parallelScale" type="double">16.5363</Field>
                            <Field name="nearPlane" type="double">-33.0726</Field>
                            <Field name="farPlane" type="double">33.0726</Field>
                            <Field name="imagePan" type="doubleArray" length="2">0 0 </Field>
                            <Field name="imageZoom" type="double">1</Field>
                            <Field name="perspective" type="bool">true</Field>
                            <Field name="eyeAngle" type="double">2</Field>
                            <Field name="centerOfRotationSet" type="bool">false</Field>
                            <Field name="centerOfRotation" type="doubleArray" length="3">14.8 7.1 0 </Field>
                            <Field name="axis3DScaleFlag" type="bool">false</Field>
                            <Field name="axis3DScales" type="doubleArray" length="3">1 1 1 </Field>
                            <Field name="shear" type="doubleArray" length="3">0 0 1 </Field>
                        </Object>
                        <Object name="ViewAxisArrayAttributes">
                            <Field name="domainCoords" type="doubleArray" length="2">0 1 </Field>
                            <Field name="rangeCoords" type="doubleArray" length="2">0 1 </Field>
                            <Field name="viewportCoords" type="doubleArray" length="4">0.15 0.9 0.1 0.85 </Field>
                        </Object>
                        <Object name="AnnotationObjectList">
                            <Object name="AnnotationObject">
                                <Field name="objectName" type="string">Plot0000</Field>
                                <Field name="objectType" type="string">LegendAttributes</Field>
                                <Field name="visible" type="bool">true</Field>
                                <Field name="active" type="bool">true</Field>
                                <Field name="position" type="doubleArray" length="3">0.05 0.9 0.0078125 </Field>
                                <Field name="position2" type="doubleArray" length="3">1 1 0.05 </Field>
                                <Object name="textColor">
                                    <Object name="ColorAttribute">
                                        <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                                    </Object>
                                </Object>
                                <Field name="useForegroundForTextColor" type="bool">true</Field>
                                <Object name="color1">
                                    <Object name="ColorAttribute">
                                        <Field name="color" type="unsignedCharArray" length="4">0 0 0 50 </Field>
                                    </Object>
                                </Object>
                                <Object name="color2">
                                    <Object name="ColorAttribute">
                                        <Field name="color" type="unsignedCharArray" length="4">0 0 0 255 </Field>
                                    </Object>
                                </Object>
                                <Field name="text" type="stringVector">"%# -9.4g" </Field>
                                <Field name="fontFamily" type="string">Arial</Field>
                                <Field name="fontBold" type="bool">false</Field>
                                <Field name="fontItalic" type="bool">false</Field>
                                <Field name="fontShadow" type="bool">false</Field>
                                <Field name="doubleAttribute1" type="double">0.015</Field>
                                <Field name="intAttribute1" type="int">993</Field>
                                <Field name="intAttribute2" type="int">5</Field>
                                <Field name="intAttribute3" type="int">0</Field>
                                <Field name="doubleVector1" type="doubleVector"></Field>
                                <Field name="stringVector1" type="stringVector"></Field>
                                <Field name="stringVector2" type="stringVector"></Field>
                            </Object>
                        </Object>
                        <Object name="InteractorAttributes">
                            <Field name="showGuidelines" type="bool">true</Field>
                            <Field name="clampSquare" type="bool">false</Field>
                            <Field name="fillViewportOnZoom" type="bool">true</Field>
                            <Field name="navigationMode" type="string">Trackball</Field>
                            <Field name="axisArraySnap" type="bool">true</Field>
                            <Field name="boundingBoxMode" type="string">Auto</Field>
                        </Object>
                        <Object name="ViewerPlotList">
                            <Object name="timeSliders">
                                <Field name="SOURCE00" type="int">0</Field>
                            </Object>
                            <Field name="activeTimeSlider" type="string">SOURCE00</Field>
                            <Object name="plot00">
                                <Field name="plotName" type="string">Plot0000</Field>
                                <Field name="pluginID" type="string">Pseudocolor_1.0</Field>
                                <Field name="sourceID" type="string">SOURCE00</Field>
                                <Field name="variableName" type="string">EdgeFields/VolumetricFlux</Field>
                                <Field name="active" type="bool">true</Field>
                                <Field name="hidden" type="bool">false</Field>
                                <Field name="realized" type="bool">true</Field>
                                <Object name="ViewerPlot">
                                    <Field name="plotDescription" type="string"></Field>
                                    <Field name="cacheIndex" type="int">0</Field>
                                    <Field name="spatialExtentsType" type="string">AVT_ORIGINAL_EXTENTS</Field>
                                    <Field name="bgColor" type="doubleArray" length="3">1 1 1 </Field>
                                    <Field name="fgColor" type="doubleArray" length="3">0 0 0 </Field>
                                    <Field name="expandedFlag" type="bool">true</Field>
                                    <Field name="followsTime" type="bool">true</Field>
                                    <Object name="PseudocolorAttributes">
                                        <Field name="legendFlag" type="bool">true</Field>
                                        <Field name="lightingFlag" type="bool">true</Field>
                                        <Field name="minFlag" type="bool">false</Field>
                                        <Field name="maxFlag" type="bool">false</Field>
                                        <Field name="centering" type="string">Natural</Field>
                                        <Field name="scaling" type="string">Linear</Field>
                                        <Field name="limitsMode" type="string">OriginalData</Field>
                                        <Field name="min" type="double">0</Field>
                                        <Field name="max" type="double">1</Field>
                                        <Field name="pointSize" type="double">0.05</Field>
                                        <Field name="pointType" type="string">Point</Field>
                                        <Field name="skewFactor" type="double">1</Field>
                                        <Field name="opacity" type="double">1</Field>
                                        <Field name="colorTableName" type="string">hot</Field>
                                        <Field name="invertColorTable" type="bool">false</Field>
                                        <Field name="smoothingLevel" type="int">0</Field>
                                        <Field name="pointSizeVarEnabled" type="bool">false</Field>
                                        <Field name="pointSizeVar" type="string">default</Field>
                                        <Field name="pointSizePixels" type="int">2</Field>
                                        <Field name="lineStyle" type="int">0</Field>
                                        <Field name="lineWidth" type="int">0</Field>
                                        <Field name="opacityType" type="string">Explicit</Field>
                                    </Object>
                                    <Object name="Operators">
                                        <Field name="activeOperatorIndex" type="int">0</Field>
                                        <Object name="operator00">
                                            <Field name="operatorType" type="string">Box_1.0</Field>
                                            <Object name="ViewerOperator">
                                                <Object name="BoxAttributes">
                                                    <Field name="amount" type="string">Some</Field>
};
    print OUT "                                                    <Field name=\"minx\" type=\"double\">$x0[0]</Field>
                                                    <Field name=\"maxx\" type=\"double\">$x1[0]</Field>
                                                    <Field name=\"miny\" type=\"double\">$x0[1]</Field>
                                                    <Field name=\"maxy\" type=\"double\">$x1[1]</Field>
                                                    <Field name=\"minz\" type=\"double\">$x0[2]</Field>
                                                    <Field name=\"maxz\" type=\"double\">$x1[2]</Field>
";
print OUT q{                                                </Object>
                                            </Object>
                                        </Object>
                                    </Object>
                                    <Object name="plotKeyframes">
                                        <Object name="AttributeSubjectMap">
                                            <Field name="indices" type="intVector">0 </Field>
                                            <Object name="attributes">
                                                <Object name="PseudocolorAttributes">
                                                    <Field name="legendFlag" type="bool">true</Field>
                                                    <Field name="lightingFlag" type="bool">true</Field>
                                                    <Field name="minFlag" type="bool">false</Field>
                                                    <Field name="maxFlag" type="bool">false</Field>
                                                    <Field name="centering" type="string">Natural</Field>
                                                    <Field name="scaling" type="string">Linear</Field>
                                                    <Field name="limitsMode" type="string">OriginalData</Field>
                                                    <Field name="min" type="double">0</Field>
                                                    <Field name="max" type="double">1</Field>
                                                    <Field name="pointSize" type="double">0.05</Field>
                                                    <Field name="pointType" type="string">Point</Field>
                                                    <Field name="skewFactor" type="double">1</Field>
                                                    <Field name="opacity" type="double">1</Field>
                                                    <Field name="colorTableName" type="string">hot</Field>
                                                    <Field name="invertColorTable" type="bool">false</Field>
                                                    <Field name="smoothingLevel" type="int">0</Field>
                                                    <Field name="pointSizeVarEnabled" type="bool">false</Field>
                                                    <Field name="pointSizeVar" type="string">default</Field>
                                                    <Field name="pointSizePixels" type="int">2</Field>
                                                    <Field name="lineStyle" type="int">0</Field>
                                                    <Field name="lineWidth" type="int">0</Field>
                                                    <Field name="opacityType" type="string">Explicit</Field>
                                                </Object>
                                            </Object>
                                        </Object>
                                    </Object>
                                    <Object name="databaseKeyframes">
                                        <Object name="AttributeSubjectMap">
                                            <Field name="indices" type="intVector">0 2 </Field>
                                            <Object name="attributes">
                                                <Object name="DatabaseAttributes">
                                                    <Field name="state" type="int">0</Field>
                                                </Object>
                                                <Object name="DatabaseAttributes">
                                                    <Field name="state" type="int">2</Field>
                                                </Object>
                                            </Object>
                                        </Object>
                                    </Object>
                                    <Object name="CompactSILRestrictionAttributes">
                                        <Field name="useSet" type="unsignedCharVector">2 2 </Field>
                                        <Field name="topSet" type="string">edge_mesh</Field>
                                    </Object>
                                    <Field name="namedSelection" type="string"></Field>
                                </Object>
                            </Object>
                            <Field name="activeSource" type="string">SOURCE00</Field>
                            <Field name="nPlots" type="int">1</Field>
                            <Field name="keyframeMode" type="bool">false</Field>
                            <Field name="nKeyframes" type="int">1</Field>
                            <Object name="AnimationAttributes">
                                <Field name="animationMode" type="string">StopMode</Field>
                                <Field name="pipelineCachingMode" type="bool">false</Field>
                                <Field name="frameIncrement" type="int">1</Field>
                                <Field name="timeout" type="int">1</Field>
                                <Field name="playbackMode" type="string">Looping</Field>
                            </Object>
                        </Object>
                    </Object>
                </Object>
            </Object>
            <Object name="ViewerQueryManager">
                <Field name="baseDesignator" type="char">A</Field>
                <Field name="cycleDesignator" type="bool">false</Field>
                <Field name="colorIndex" type="int">0</Field>
            </Object>
            <Object name="ViewerEngineManager">
                <Object name="MaterialAttributes">
                    <Field name="smoothing" type="bool">false</Field>
                    <Field name="forceMIR" type="bool">false</Field>
                    <Field name="cleanZonesOnly" type="bool">false</Field>
                    <Field name="needValidConnectivity" type="bool">false</Field>
                    <Field name="algorithm" type="string">EquiZ</Field>
                    <Field name="iterationEnabled" type="bool">false</Field>
                    <Field name="numIterations" type="int">5</Field>
                    <Field name="iterationDamping" type="float">0.4</Field>
                    <Field name="simplifyHeavilyMixedZones" type="bool">false</Field>
                    <Field name="maxMaterialsPerZone" type="int">3</Field>
                    <Field name="isoVolumeFraction" type="float">0.5</Field>
                    <Field name="annealingTime" type="int">10</Field>
                </Object>
                <Object name="MeshManagementAttributes">
                    <Field name="discretizationTolerance" type="doubleVector">0.02 0.025 0.05 </Field>
                    <Field name="discretizationToleranceX" type="doubleVector"></Field>
                    <Field name="discretizationToleranceY" type="doubleVector"></Field>
                    <Field name="discretizationToleranceZ" type="doubleVector"></Field>
                    <Field name="discretizationMode" type="string">Uniform</Field>
                    <Field name="discretizeBoundaryOnly" type="bool">false</Field>
                    <Field name="passNativeCSG" type="bool">false</Field>
                </Object>
                <Object name="RunningEngines">
                    <Object name="MachineProfile">
                        <Field name="hostNickname" type="string"></Field>
                        <Field name="host" type="string">scott-johnsons-macbook-pro.local</Field>
                        <Field name="userName" type="string">scottjohnson</Field>
                        <Field name="hostAliases" type="string"></Field>
                        <Field name="directory" type="string"></Field>
                        <Field name="shareOneBatchJob" type="bool">false</Field>
                        <Field name="sshPortSpecified" type="bool">false</Field>
                        <Field name="sshPort" type="int">22</Field>
                        <Field name="useGateway" type="bool">false</Field>
                        <Field name="gatewayHost" type="string"></Field>
                        <Field name="clientHostDetermination" type="string">MachineName</Field>
                        <Field name="manualClientHostName" type="string"></Field>
                        <Field name="tunnelSSH" type="bool">false</Field>
                        <Field name="maximumNodesValid" type="bool">false</Field>
                        <Field name="maximumNodes" type="int">1</Field>
                        <Field name="maximumProcessorsValid" type="bool">false</Field>
                        <Field name="maximumProcessors" type="int">1</Field>
                        <Field name="activeProfile" type="int">-1</Field>
                    </Object>
                </Object>
            </Object>
        </Object>
    </Object>
</Object>
};
}
